/* Generated from data/*.json — do not edit by hand */
window.MIRA_STUDY = {
  "project": {
    "studyId": "MIRA-ECOM-GATE00",
    "studyVersion": "RC2 — تصحيحات المرحلة الأولى لاكتشفي",
    "studyStatus": "بانتظار إعادة المراجعة",
    "gate": "GATE-00",
    "titleAr": "المتاجر الإلكترونية في ميرا",
    "updatedAt": "2026-09-24T06:11:28+03:00",
    "timezone": "Asia/Riyadh",
    "ownerDecisionStatus": "بانتظار إعادة المراجعة — DEC-0005 غير معتمد",
    "baseline": {
      "repoPath": "/Users/fayez/Desktop/mira",
      "branch": "mira/p5-strict-frontend-recovery-2026-09-14",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "workingTreeNote": "تغييرات غير ملتزمة في iOS/skin — خارج نطاق هذه الدراسة",
      "appVersionInPubspec": "1.0.0+2026092302",
      "sourceVsBuildVsDeviceVsProd": {
        "sourceExamined": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
        "buildExamined": "غير مربوط بهذه الدراسة",
        "deviceExamined": "غير مثبت لهذه الدراسة",
        "productionExamined": "SOURCE_ONLY"
      },
      "inspectedAt": "2026-09-23T03:43:29+03:00",
      "previousCommitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "deltaFromPreviousAr": "نفس commit. الفرق هو تصحيح الدراسة لا تغيير منتج. الشجرة المتسخة موثقة في EVD-0022."
    },
    "blockers": [
      "GATE-00 بانتظار إعادة المراجعة",
      "لا دليل تشغيل إنتاجي",
      "لا متغيرات ولا طلب داخل النطاق المبحوث",
      "تتبع الأحداث يقبل partnerId من العميل في المصدر",
      "أسعار الوسائط غير متحققة",
      "المرجع البصري للتصورات الثلاثة غير مرفق"
    ],
    "decisionsNeeded": [
      "DEC-0001",
      "DEC-0002",
      "DEC-0003",
      "DEC-0004",
      "DEC-0005",
      "DEC-0007"
    ],
    "brandTokens": {
      "primary": "#E86FA9",
      "primaryLight": "#FADAE9",
      "primaryDark": "#C95889",
      "secondary": "#C19EE0",
      "background": "#FFF7FA",
      "text": "#4A3A3A",
      "gold": "#D4AF37",
      "source": "lib/shared/theme/colors.dart"
    },
    "counts": {
      "requirements": 27,
      "gaps": 20,
      "evidence": 43,
      "capabilities": 15,
      "decisions": 7,
      "paused": 3,
      "gates": 10,
      "reviewFindings": 39,
      "scopeItems": 37
    },
    "previousStudyVersion": "RC1 — مراحل اكتشفي وشاشة العرض",
    "previousPackage": "MIRA_ECOMMERCE_MASTER_STUDY_REVIEW_20260923_032329.zip",
    "placesHandoff": {
      "package": "DAR_PLACES_TO_MIRA_SOURCE_HANDOFF_RC2_20260924_0125.zip",
      "sha256": "60a8d854eb609e1eef11513a1406fd1e262ac809922e889f2e7beecf76ec48e1"
    }
  },
  "repositories": [
    {
      "id": "REPO-0001",
      "path": "/Users/fayez/Desktop/mira",
      "roleAr": "مستودع موحّد Flutter + API + بوابات",
      "branch": "mira/p5-strict-frontend-recovery-2026-09-14",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "workingTree": "dirty (غير متعلق بالدراسة)",
      "inspectedAt": "2026-09-23T03:20:00+03:00",
      "dependencyFiles": [
        "pubspec.yaml",
        "mira-api/package.json",
        "mira-api/prisma/schema.prisma",
        "render.yaml"
      ],
      "envVarNamesOnly": [
        "DATABASE_URL",
        "MIRA_API_BASE_URL",
        "MIRA_MARKETPLACE_ENABLED",
        "PARTNER_AUTO_APPROVE",
        "AUTH_SKIP",
        "ADMIN_API_KEY"
      ],
      "runHints": [
        "flutter run",
        "cd mira-api && npm run start:dev"
      ],
      "subprojects": [
        {
          "id": "SP-FLUTTER",
          "path": "lib/",
          "role": "تطبيق العميل"
        },
        {
          "id": "SP-API",
          "path": "mira-api/",
          "role": "NestJS"
        },
        {
          "id": "SP-PARTNERS",
          "path": "partners-portal/",
          "role": "ويب الشركاء"
        },
        {
          "id": "SP-ADMIN",
          "path": "admin-portal/",
          "role": "لوحة الإدارة"
        },
        {
          "id": "SP-WEB",
          "path": "website/",
          "role": "تسويق"
        }
      ]
    },
    {
      "id": "REPO-0002",
      "path": "غير متاح للفحص",
      "roleAr": "مستودع تجارة منفصل",
      "note": "غير موجود ضمن نطاق Desktop المفحوص"
    }
  ],
  "capabilities": [
    {
      "id": "CAP-0001",
      "nameAr": "كتالوج الشركاء",
      "area": "marketplace",
      "existence": "EXISTING",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0005",
        "EVD-0006"
      ],
      "judgmentNoteAr": "الكود موجود. تفعيل الإنتاج غير مثبت لأن التحقق SOURCE_ONLY."
    },
    {
      "id": "CAP-0002",
      "nameAr": "مطابقة البشرة",
      "area": "marketplace",
      "existence": "EXISTING",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0006"
      ],
      "judgmentNoteAr": "مسار مطابقة في المتحكم العام. لا دليل تشغيل."
    },
    {
      "id": "CAP-0003",
      "nameAr": "واجهة Discover",
      "area": "flutter",
      "existence": "EXISTING",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0001",
        "EVD-0002"
      ],
      "judgmentNoteAr": "العلم الافتراضي false يخفي الواجهة في المصدر. وصول API الإنتاج UNKNOWN."
    },
    {
      "id": "CAP-0004",
      "nameAr": "شراء عبر رابط خارجي",
      "area": "flutter",
      "existence": "PARTIAL",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0004",
        "EVD-0007"
      ],
      "judgmentNoteAr": "الشراء في الشاشة رابط خارجي. SPEC وثيقة لا تثبت التفعيل."
    },
    {
      "id": "CAP-0005",
      "nameAr": "حجز خدمة",
      "area": "booking",
      "existence": "PARTIAL",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0003"
      ],
      "judgmentNoteAr": "الزر stub في المصدر. ليست خدمة مكتملة متوقفة."
    },
    {
      "id": "CAP-0006",
      "nameAr": "سلة/طلب منتجات",
      "area": "orders",
      "existence": "ABSENT_AFTER_SEARCH",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0018",
        "EVD-0010"
      ],
      "judgmentNoteAr": "الغياب محصور بنطاق البحث في EVD-0018. الملخص القديم EVD-0010 غير كافٍ وحده."
    },
    {
      "id": "CAP-0007",
      "nameAr": "بوابة الشركاء",
      "area": "partners-portal",
      "existence": "EXISTING",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0011",
        "EVD-0012",
        "EVD-0013",
        "EVD-0016",
        "EVD-0021",
        "EVD-0007"
      ],
      "judgmentNoteAr": "التنفيذ موجود في المصدر. EVD-0007 مواصفات فقط. التفعيل الإنتاجي غير مثبت."
    },
    {
      "id": "CAP-0008",
      "nameAr": "لوحة الإدارة",
      "area": "admin",
      "existence": "EXISTING",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0014",
        "EVD-0015",
        "EVD-0025"
      ],
      "judgmentNoteAr": "أُضيف دليل المتحكم والعميل. لا يُصنف مفعّلًا في الإنتاج من الشيفرة."
    },
    {
      "id": "CAP-0009",
      "nameAr": "كتالوج محلي احتياطي",
      "area": "marketplace",
      "existence": "EXISTING",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0008"
      ],
      "judgmentNoteAr": "بذرة محلية في المصدر عند غياب الشبكة. ليست كتالوج إنتاج."
    },
    {
      "id": "CAP-0010",
      "nameAr": "فيديو منتج متتابع",
      "area": "media",
      "existence": "ABSENT_AFTER_SEARCH",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0023",
        "EVD-0024"
      ],
      "judgmentNoteAr": "لا تطابق لأنماط الفيديو المتتابع داخل النطاق. ليس حكمًا على كل مستودع خارج الفحص."
    },
    {
      "id": "CAP-0011",
      "nameAr": "مشاهير/إعلانات منتج",
      "area": "creators",
      "existence": "ABSENT_AFTER_SEARCH",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0023",
        "EVD-0019"
      ],
      "judgmentNoteAr": "لا نموذج مشاهير في النطاق المبحوث."
    },
    {
      "id": "CAP-0012",
      "nameAr": "متغيرات منتج",
      "area": "catalog",
      "existence": "ABSENT_AFTER_SEARCH",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0017",
        "EVD-0019",
        "EVD-0005"
      ],
      "judgmentNoteAr": "العقد والمخطط المبحوثان بلا متغير. المقتطف وحده لا ينفي المشروع كله؛ البحث الأوسع في EVD-0019."
    },
    {
      "id": "CAP-0013",
      "nameAr": "فلاتر متخصصة",
      "area": "filters",
      "existence": "PARTIAL",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0017",
        "EVD-0006"
      ],
      "judgmentNoteAr": "concernTags وskinTypes موجودان. فلاتر المقاس واللون غير موجودة في العقد."
    },
    {
      "id": "CAP-0014",
      "nameAr": "اشتراكات رصيد (منفصل)",
      "area": "subscriptions",
      "existence": "EXISTING",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0020"
      ],
      "judgmentNoteAr": "مسار اشتراك رصيد منفصل عن المتجر. العلم الافتراضي false في المصدر. ليس دليل إيقاف إنتاجي مستقل."
    },
    {
      "id": "CAP-0015",
      "nameAr": "حزمة مصدر الأماكن للمراجعة",
      "area": "places-handoff",
      "existence": "PARTIAL",
      "activation": "UNKNOWN",
      "verification": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0028"
      ],
      "judgmentNoteAr": "الحزمة مصدر مراجعة وليست تطبيقًا مدمجًا في ميرا ولا بناءً مستقلًا."
    }
  ],
  "pausedServices": [
    {
      "id": "PAUSE-0001",
      "nameAr": "Discover في التطبيق",
      "previousClassificationAr": "خدمة متوقفة موثقة بسبب عبارة الانطلاق قريبًا، وAPI يمكن الوصول إليه",
      "correctedClassificationAr": "إخفاء واجهة في المصدر عبر علم بناء. سبب الإيقاف التاريخي غير موثق تشغيليًا.",
      "classification": "UI_FLAG_DEFAULT_OFF",
      "uiHidden": "true-in-source",
      "navigationBlocked": "true-in-client-routes",
      "serverFeatureGate": "UNKNOWN",
      "apiReachableDespiteUiHide": "UNKNOWN",
      "logicCompleteness": "PARTIAL",
      "externalDependencyMissing": "UNKNOWN",
      "documentedReason": "التعليق «الانطلاق قريبًا» نص واجهة. الآلية التقنية في المصدر هي MIRA_MARKETPLACE_ENABLED الافتراضي false. لا وثيقة تشغيل تشرح سبب الإيقاف. توجيه المالك اللاحق: الإبقاء للإعداد لتجربة العرض المرئي، مع التصريح الآن بنسخة اختبار منفصلة.",
      "reasonClass": "سبب تاريخي غير موثق؛ الآلية في المصدر موثقة",
      "evidenceIds": [
        "EVD-0001",
        "EVD-0002",
        "EVD-0006"
      ],
      "reactivationNeeds": [
        "قرار مالك",
        "معرفة قيمة العلم في البناء المنشور",
        "مراجعة الكتالوج قبل الإظهار"
      ],
      "reactivationRisks": [
        "إظهار بذرة محلية كأنها متجر حي"
      ],
      "ownerDirectiveAr": "توجيه المالك: أُبقيت مغلقة لتطويرها إلى تجربة العرض المرئي. هذا التوجيه منفصل عن استنتاج الكود بأن العلم الافتراضي false.",
      "testActivationAr": "صُرّح بتفعيل نسخة اختبار بالعلم دون تغيير الافتراضي."
    },
    {
      "id": "PAUSE-0002",
      "nameAr": "الحجز الإلكتروني",
      "previousClassificationAr": "خدمة متوقفة",
      "correctedClassificationAr": "مسار غير مكتمل في التصميم الحالي، وليس خدمة أُوقفت بعد اكتمالها.",
      "classification": "NEVER_COMPLETED_STUB",
      "uiHidden": "button-disabled-or-snackbar",
      "navigationBlocked": "UNKNOWN",
      "serverFeatureGate": "no-booking-model-in-searched-schema",
      "apiReachableDespiteUiHide": "UNKNOWN",
      "logicCompleteness": "STUB",
      "externalDependencyMissing": "UNKNOWN",
      "documentedReason": "الزر في الشاشة لا ينشئ حجزًا. لا يوجد model Booking في البحث EVD-0018. لا سبب تشغيلي تاريخي منفصل.",
      "reasonClass": "غير منفذ حتى الاكتمال",
      "evidenceIds": [
        "EVD-0003",
        "EVD-0018",
        "EVD-0017"
      ],
      "reactivationNeeds": [
        "عقد حجز",
        "مواعيد",
        "لا يكفي إعادة تشغيل خادم"
      ],
      "reactivationRisks": [
        "اعتبار الزر الحالي حجزًا حقيقيًا"
      ]
    },
    {
      "id": "PAUSE-0003",
      "nameAr": "شراء داخل ميرا",
      "previousClassificationAr": "خدمة متوقفة لأن SPEC يقول الدفع عند الشريك",
      "correctedClassificationAr": "غير منفذ في التصميم الحالي. ليس خدمة تحتاج إعادة تشغيل.",
      "classification": "NEVER_BUILT",
      "uiHidden": "buy-opens-external-url",
      "navigationBlocked": "not-applicable",
      "serverFeatureGate": "no-order-model-in-searched-scope",
      "apiReachableDespiteUiHide": "UNKNOWN",
      "logicCompleteness": "NOT_IMPLEMENTED",
      "externalDependencyMissing": "UNKNOWN",
      "documentedReason": "الشاشة تفتح externalUrl. المواصفات تقول الدفع عند الشريك. لا سجل تشغيلي يقول إن شراءً داخليًا كان يعمل ثم أُوقف.",
      "reasonClass": "تصميم خارجي وليس إيقافًا",
      "evidenceIds": [
        "EVD-0004",
        "EVD-0007",
        "EVD-0018"
      ],
      "reactivationNeeds": [
        "DEC-0001 قبل أي بناء"
      ],
      "reactivationRisks": [
        "بناء سلة فوق مسار رابط خارجي دون قرار"
      ]
    }
  ],
  "requirements": [
    {
      "id": "REQ-0001",
      "nameAr": "منتج أساسي بهوية ثابتة",
      "area": "catalog",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0001",
      "gapId": "GAP-0001",
      "acceptanceAr": "المعطى: منتج شريك موجود بهوية ثابتة. الإجراء: إنشاء منتج ثانٍ ثم تعديل سعر الأول. المتوقع: يبقى معرف المنتج الأول وتاريخه، ويتغير السعر المسجل دون إنشاء منتج جديد.",
      "acceptance": {
        "given": "منتج شريك موجود بهوية ثابتة",
        "action": "إنشاء منتج ثانٍ ثم تعديل سعر الأول",
        "expected": "يبقى معرف المنتج الأول وتاريخه، ويتغير السعر المسجل دون إنشاء منتج جديد",
        "failures": [
          "رفض اسم فارغ",
          "رفض سعر سالب"
        ],
        "testMethod": "اختبار خدمة على قاعدة اختبار",
        "evidenceRequired": "سجل المنتج قبل وبعد مع المعرف"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0002",
      "nameAr": "متغيرات مقاس/لون/مخزون",
      "area": "catalog",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0012",
      "gapId": "GAP-0002",
      "acceptanceAr": "المعطى: منتج له متغيران لون×مقاس. الإجراء: طلب المتغير الأزرق M المتوفر. المتوقع: يُختار متغير واحد تتطابق خصائصه كلها.",
      "acceptance": {
        "given": "منتج له متغيران لون×مقاس",
        "action": "طلب المتغير الأزرق M المتوفر",
        "expected": "يُختار متغير واحد تتطابق خصائصه كلها",
        "failures": [
          "متغير بلا مخزون لا يُباع",
          "دمج لون من متغير ومقاس من آخر"
        ],
        "testMethod": "اختبار استعلام المتغير",
        "evidenceRequired": "صف المتغير المطابق فقط"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0003",
      "nameAr": "خدمة + مقدم + فرع",
      "area": "catalog",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0001",
      "gapId": "GAP-0003",
      "acceptanceAr": "المعطى: طلب انضمام عيادة. الإجراء: اعتماد الإدارة ثم إضافة خدمة وفرع. المتوقع: الخدمة ترتبط بالمنشأة والفرع لا بمنتج عام.",
      "acceptance": {
        "given": "طلب انضمام عيادة",
        "action": "اعتماد الإدارة ثم إضافة خدمة وفرع",
        "expected": "الخدمة ترتبط بالمنشأة والفرع لا بمنتج عام",
        "failures": [
          "عيادة بلا ترخيص موثق تبقى قيد المراجعة"
        ],
        "testMethod": "اختبار الاعتماد ومسار الفرع",
        "evidenceRequired": "سجل الفرع والخدمة"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0004",
      "nameAr": "محتوى مرئي للمنتج",
      "area": "media",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0010",
      "gapId": "GAP-0004",
      "acceptanceAr": "المعطى: ملف فيديو ضمن الحدود. الإجراء: رفعه وربطه بمنتج. المتوقع: لا يُعرض قبل المراجعة، ويشير إلى المنتج الأصلي.",
      "acceptance": {
        "given": "ملف فيديو ضمن الحدود",
        "action": "رفعه وربطه بمنتج",
        "expected": "لا يُعرض قبل المراجعة، ويشير إلى المنتج الأصلي",
        "failures": [
          "رفض نوع غير مسموح",
          "فشل المعالجة يبقي الحالة فشل"
        ],
        "testMethod": "اختبار دورة الوسائط",
        "evidenceRequired": "حالات الوسيط"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0005",
      "nameAr": "تصفح فيديو متتابع",
      "area": "media",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0010",
      "gapId": "GAP-0005",
      "acceptanceAr": "المعطى: ثلاثة مقاطع منشورة. الإجراء: تمرير عمودي مع صوت. المتوقع: مقطع واحد مسموع، واستئناف الموضع عند العودة.",
      "acceptance": {
        "given": "ثلاثة مقاطع منشورة",
        "action": "تمرير عمودي مع صوت",
        "expected": "مقطع واحد مسموع، واستئناف الموضع عند العودة",
        "failures": [
          "تداخل صوت مقطعين",
          "اقتصاص خارج الإطار"
        ],
        "testMethod": "اختبار واجهة على جهاز",
        "evidenceRequired": "تسجيل شاشة ولقطات"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0006",
      "nameAr": "عرض متجر رسمي",
      "area": "partners",
      "priority": "should",
      "status": "proposed",
      "existingCapabilityId": "CAP-0007",
      "gapId": null,
      "acceptanceAr": "المعطى: شريك معتمد. الإجراء: فتح صفحته العامة من التطبيق. المتوقع: تظهر منتجاته النشطة فقط ورابط متجره.",
      "acceptance": {
        "given": "شريك معتمد",
        "action": "فتح صفحته العامة من التطبيق",
        "expected": "تظهر منتجاته النشطة فقط ورابط متجره",
        "failures": [
          "منتجات شريك آخر لا تُخلط"
        ],
        "testMethod": "اختبار عرض المتجر",
        "evidenceRequired": "قائمة المنتجات المعروضة"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0007",
      "nameAr": "إعلانات مشاهير بلا نسخ مخزون",
      "area": "creators",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0011",
      "gapId": "GAP-0006",
      "acceptanceAr": "المعطى: إعلان مشهور مربوط بمنتج. الإجراء: تغيير سعر المنتج ومخزونه. المتوقع: الإعلان يقرأ السعر والمخزون من المنتج ولا يخزن نسخة.",
      "acceptance": {
        "given": "إعلان مشهور مربوط بمنتج",
        "action": "تغيير سعر المنتج ومخزونه",
        "expected": "الإعلان يقرأ السعر والمخزون من المنتج ولا يخزن نسخة",
        "failures": [
          "رفض نشر إعلان بلا منتج"
        ],
        "testMethod": "اختبار عدم النسخ",
        "evidenceRequired": "مقارنة حقول الإعلان والمنتج"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0008",
      "nameAr": "فصل الناشر/البائع/المحتوى/الطلب",
      "area": "creators",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0011",
      "gapId": "GAP-0007",
      "acceptanceAr": "المعطى: أطراف الناشر والمعلن والبائع مختلفة. الإجراء: فتح الإعلان ثم الشراء. المتوقع: الطلب يُنسب للبائع والمحتوى للناشر.",
      "acceptance": {
        "given": "أطراف الناشر والمعلن والبائع مختلفة",
        "action": "فتح الإعلان ثم الشراء",
        "expected": "الطلب يُنسب للبائع والمحتوى للناشر",
        "failures": [
          "خلط هوية المعلن مع البائع"
        ],
        "testMethod": "اختبار الإسناد",
        "evidenceRequired": "سجل الأطراف"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0009",
      "nameAr": "حالات نشر المحتوى",
      "area": "media",
      "priority": "should",
      "status": "proposed",
      "existingCapabilityId": "CAP-0010",
      "gapId": "GAP-0008",
      "acceptanceAr": "المعطى: وسيط قيد المراجعة. الإجراء: محاولة تشغيله في التصفح. المتوقع: لا يظهر في الخلاصة العامة.",
      "acceptance": {
        "given": "وسيط قيد المراجعة",
        "action": "محاولة تشغيله في التصفح",
        "expected": "لا يظهر في الخلاصة العامة",
        "failures": [
          "نشر بلا مراجعة"
        ],
        "testMethod": "اختبار حالات النشر",
        "evidenceRequired": "حالة الوسيط قبل وبعد"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0010",
      "nameAr": "موافقة المتجر على الإعلان",
      "area": "creators",
      "priority": "should",
      "status": "proposed",
      "existingCapabilityId": "CAP-0011",
      "gapId": "GAP-0009",
      "acceptanceAr": "المعطى: إعلان بانتظار موافقة المتجر. الإجراء: المتجر يرفض الربط. المتوقع: يختفي من العرض ويبقى المنتج.",
      "acceptance": {
        "given": "إعلان بانتظار موافقة المتجر",
        "action": "المتجر يرفض الربط",
        "expected": "يختفي من العرض ويبقى المنتج",
        "failures": [
          "ربط بلا موافقة"
        ],
        "testMethod": "اختبار حالة الربط",
        "evidenceRequired": "سجل الموافقة"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0011",
      "nameAr": "حفظ مرجع المنتج عند الطلب",
      "area": "orders",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0006",
      "gapId": "GAP-0010",
      "acceptanceAr": "المعطى: طلب على متغير محدد. الإجراء: تغيير سعر المتغير لاحقًا. المتوقع: الطلب يحتفظ بسعر ونسخة المتغير وقت الإنشاء.",
      "acceptance": {
        "given": "طلب على متغير محدد",
        "action": "تغيير سعر المتغير لاحقًا",
        "expected": "الطلب يحتفظ بسعر ونسخة المتغير وقت الإنشاء",
        "failures": [
          "الطلب يتبع السعر الجديد صامتًا"
        ],
        "testMethod": "اختبار لقطة الطلب",
        "evidenceRequired": "لقطة السعر"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0012",
      "nameAr": "رحلة مشاهدة→طلب",
      "area": "journey",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0004",
      "gapId": "GAP-0011",
      "acceptanceAr": "المعطى: مستخدم على مقطع منتج. الإجراء: يختار شراء أو حجز أو استفسار. المتوقع: كل مسار يفتح وجهته دون تحويل الكل إلى الشراء.",
      "acceptance": {
        "given": "مستخدم على مقطع منتج",
        "action": "يختار شراء أو حجز أو استفسار",
        "expected": "كل مسار يفتح وجهته دون تحويل الكل إلى الشراء",
        "failures": [
          "زر واحد لكل المسارات"
        ],
        "testMethod": "اختبار الرحلة",
        "evidenceRequired": "سجل المسار المختار"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0013",
      "nameAr": "فلاتر AND على متغير واحد",
      "area": "filters",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0013",
      "gapId": "GAP-0012",
      "acceptanceAr": "المعطى: فستان أزرق M متوفر وفستان أزرق S غير متوفر. الإجراء: فلتر لون أزرق AND مقاس M AND متوفر. المتوقع: منتج واحد ومتغير واحد.",
      "acceptance": {
        "given": "فستان أزرق M متوفر وفستان أزرق S غير متوفر",
        "action": "فلتر لون أزرق AND مقاس M AND متوفر",
        "expected": "منتج واحد ومتغير واحد",
        "failures": [
          "مطابقة اللون من متغير والمقاس من آخر"
        ],
        "testMethod": "اختبار المثال المرجعي",
        "evidenceRequired": "هوية المتغير المطابق"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0014",
      "nameAr": "فلترة خادمية مع ترقيم",
      "area": "filters",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0013",
      "gapId": "GAP-0013",
      "acceptanceAr": "المعطى: كتالوج أكبر من صفحة. الإجراء: فلتر مع ترتيب وترقيم. المتوقع: العدد الكلي صحيح والصفحة لا تكرر صفًا.",
      "acceptance": {
        "given": "كتالوج أكبر من صفحة",
        "action": "فلتر مع ترتيب وترقيم",
        "expected": "العدد الكلي صحيح والصفحة لا تكرر صفًا",
        "failures": [
          "فلترة على العميل بعد جلب الكل"
        ],
        "testMethod": "اختبار الاستعلام",
        "evidenceRequired": "العد ورقم الصفحة"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0015",
      "nameAr": "أحداث تحليلات",
      "area": "analytics",
      "priority": "should",
      "status": "proposed",
      "existingCapabilityId": "CAP-0007",
      "gapId": "GAP-0014",
      "acceptanceAr": "المعطى: حدث نقرة على منتج. الإجراء: تسجيله ثم عرضه للشريك المالك. المتوقع: الحدث مرتبط بالشريك والهدف.",
      "acceptance": {
        "given": "حدث نقرة على منتج",
        "action": "تسجيله ثم عرضه للشريك المالك",
        "expected": "الحدث مرتبط بالشريك والهدف",
        "failures": [
          "شريك يسجل حدثًا لشريك آخر من جسم الطلب"
        ],
        "testMethod": "اختبار التتبع بعد سد الثغرة",
        "evidenceRequired": "سجل الحدث والمالك"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0016",
      "nameAr": "عزل بيانات المتاجر",
      "area": "security",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0007",
      "gapId": null,
      "acceptanceAr": "المعطى: رمزان لشريكين. الإجراء: الشريك أ يحاول تعديل منتج ب. المتوقع: الرفض دون تسريب وجود المنتج.",
      "acceptance": {
        "given": "رمزان لشريكين",
        "action": "الشريك أ يحاول تعديل منتج ب",
        "expected": "الرفض دون تسريب وجود المنتج",
        "failures": [
          "قبول partnerId من الجسم في الكتابة"
        ],
        "testMethod": "اختبار العزل على قاعدة اختبار",
        "evidenceRequired": "استدعاء assert والنتيجة"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0017",
      "nameAr": "فصل البشرة عن الإعلان المدفوع",
      "area": "privacy",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": null,
      "gapId": "GAP-0015",
      "acceptanceAr": "المعطى: نتيجة تحليل بشرة وإعلان مدفوع. الإجراء: عرض التوصية. المتوقع: الإعلان موسوم مدفوعًا ولا يُقدَّم كنتيجة تحليل.",
      "acceptance": {
        "given": "نتيجة تحليل بشرة وإعلان مدفوع",
        "action": "عرض التوصية",
        "expected": "الإعلان موسوم مدفوعًا ولا يُقدَّم كنتيجة تحليل",
        "failures": [
          "خلط الإعلان مع درجة البشرة"
        ],
        "testMethod": "اختبار العرض",
        "evidenceRequired": "لقطة التمييز"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0018",
      "nameAr": "إعادة استخدام الكتالوج الحالي",
      "area": "reuse",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0001",
      "gapId": null,
      "acceptanceAr": "المعطى: جداول Partner وProduct الحالية. الإجراء: إضافة متغير دون جدول منتج موازٍ. المتوقع: المنتجات القديمة تبقى قابلة للقراءة.",
      "acceptance": {
        "given": "جداول Partner وProduct الحالية",
        "action": "إضافة متغير دون جدول منتج موازٍ",
        "expected": "المنتجات القديمة تبقى قابلة للقراءة",
        "failures": [
          "نسخ الكتالوج إلى مخطط جديد"
        ],
        "testMethod": "مراجعة الترحيل",
        "evidenceRequired": "خطة الترحيل والاختبار"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0019",
      "nameAr": "تمييز شراء/حجز/استفسار/اتصال",
      "area": "journey",
      "priority": "must",
      "status": "proposed",
      "existingCapabilityId": "CAP-0005",
      "gapId": "GAP-0016",
      "acceptanceAr": "المعطى: منتج وخدمة. الإجراء: إظهار الأفعال المتاحة. المتوقع: الشراء والحجز والاستفسار والاتصال أزرار مختلفة حسب النوع.",
      "acceptance": {
        "given": "منتج وخدمة",
        "action": "إظهار الأفعال المتاحة",
        "expected": "الشراء والحجز والاستفسار والاتصال أزرار مختلفة حسب النوع",
        "failures": [
          "حجز على منتج مادي بلا خدمة"
        ],
        "testMethod": "اختبار الأفعال",
        "evidenceRequired": "مصفوفة الأزرار"
      },
      "planPlacement": "future-gate"
    },
    {
      "id": "REQ-0020",
      "nameAr": "قرار البث الحي",
      "area": "media",
      "priority": "decision",
      "status": "proposed",
      "existingCapabilityId": "CAP-0010",
      "gapId": "GAP-0017",
      "acceptanceAr": "المعطى: قرار نطاق البث الحي ما زال مفتوحًا. الإجراء: مراجع الدراسة. المتوقع: لا تُبنى شاشة بث ولا تُغلق الدراسة بانتظارها.",
      "acceptance": {
        "given": "قرار نطاق البث الحي ما زال مفتوحًا",
        "action": "مراجع الدراسة",
        "expected": "لا تُبنى شاشة بث ولا تُغلق الدراسة بانتظارها",
        "failures": [
          "اعتبار البث متطلب إطلاق"
        ],
        "testMethod": "مراجعة DEC-0002",
        "evidenceRequired": "نص القرار وحالته"
      },
      "planPlacement": "scope-decision"
    },
    {
      "id": "REQ-0021",
      "nameAr": "عداد مشاهدات صادق على العرض المنشور",
      "area": "analytics",
      "gapId": "GAP-0018",
      "acceptanceAr": "المعطى: عرض منشور بفيديو أو صور. الإجراء: تحميل البيانات ثم السحب بين صور العرض نفسه دون بقاء مؤهل. المتوقع: لا يزيد العدد بالتحميل المسبق ولا بالسحب الأفقي، ولا يظهر صفر عند فشل الجلب.",
      "acceptance": {
        "given": "عرض منشور بفيديو أو صور",
        "action": "تحميل البيانات ثم السحب بين صور العرض نفسه دون بقاء مؤهل",
        "expected": "لا يزيد العدد بالتحميل المسبق ولا بالسحب الأفقي، ولا يظهر صفر عند فشل الجلب",
        "failures": [
          "احتساب التحميل مشاهدة",
          "إظهار صفر عند التعذر",
          "استبدال العدد برقم تسويقي"
        ],
        "testMethod": "اختبار عقد الأحداث لاحقًا؛ هذه الجولة توثيق فقط",
        "evidenceRequired": "سجل حدث مؤهل وسجل فشل جلب"
      },
      "planPlacement": "future-gate",
      "existingCapabilityId": "CAP-0015",
      "priority": "must",
      "status": "متطلب معتمد"
    },
    {
      "id": "REQ-0022",
      "nameAr": "استيراد كتالوج خارجي دون نشر تلقائي",
      "area": "integration",
      "gapId": "GAP-0019",
      "acceptanceAr": "المعطى: تاجر لديه منتجات في متجر خارجي مربوط بصلاحيات مثبتة. الإجراء: استيراد البيانات والوسائط إلى مسودات. المتوقع: تبقى المسودات غير منشورة حتى الاعتماد، ويحتفظ كل منتج بهوية مصدره.",
      "acceptance": {
        "given": "تاجر لديه منتجات في متجر خارجي مربوط بصلاحيات مثبتة",
        "action": "استيراد البيانات والوسائط إلى مسودات",
        "expected": "تبقى المسودات غير منشورة حتى الاعتماد، ويحتفظ كل منتج بهوية مصدره",
        "failures": [
          "نشر تلقائي عند الاستيراد",
          "طلب فيديو لكل منتج قبل أي استفادة"
        ],
        "testMethod": "عقد ربط موثق؛ المنصة غير معتمدة الآن",
        "evidenceRequired": "سجل مسودة وحالة نشر"
      },
      "planPlacement": "future-gate",
      "existingCapabilityId": "CAP-0015",
      "priority": "must",
      "status": "متطلب معتمد"
    },
    {
      "id": "REQ-0023",
      "nameAr": "إحصاءات إعلان المشهور مستقلة",
      "area": "ads",
      "gapId": "GAP-0018",
      "acceptanceAr": "المعطى: إعلان مشهور مرتبط بعرض تاجر أصلي. الإجراء: تسجيل مشاهدة للإعلان وأخرى للأصل. المتوقع: العددان منفصلان مع رابط بين الكيانين، والسعر يبقى من المصدر الأصلي.",
      "acceptance": {
        "given": "إعلان مشهور مرتبط بعرض تاجر أصلي",
        "action": "تسجيل مشاهدة للإعلان وأخرى للأصل",
        "expected": "العددان منفصلان مع رابط بين الكيانين، والسعر يبقى من المصدر الأصلي",
        "failures": [
          "نسخ السعر إلى الإعلان كمصدر مستقل",
          "دمج العددين في رقم واحد"
        ],
        "testMethod": "اختبار لاحق بعد وجود الكيانين",
        "evidenceRequired": "سجل عرض أصلي وسجل إعلان"
      },
      "planPlacement": "future-gate",
      "existingCapabilityId": "CAP-0015",
      "priority": "must",
      "status": "متطلب معتمد"
    },
    {
      "id": "REQ-0024",
      "nameAr": "عرض كامل لكل منتج أو خدمة",
      "area": "experience",
      "gapId": "GAP-0020",
      "acceptanceAr": "المعطى: منتج أو خدمة له وسائط. الإجراء: فتح العرض في الاكتشاف أو داخل متجر. المتوقع: شاشة كاملة، وداخل المتجر تظهر عروضه المطابقة للفلاتر فقط.",
      "acceptance": {
        "given": "منتج أو خدمة له وسائط",
        "action": "فتح العرض في الاكتشاف أو داخل متجر",
        "expected": "شاشة كاملة، وداخل المتجر تظهر عروضه المطابقة للفلاتر فقط",
        "failures": [
          "قص المنتج بطريقة مضللة",
          "خلط عروض متجر آخر"
        ],
        "testMethod": "اختبار واجهة لاحق ببيانات اختبار",
        "evidenceRequired": "لقطات RTL وSafeArea"
      },
      "planPlacement": "future-gate",
      "existingCapabilityId": "CAP-0015",
      "priority": "must",
      "status": "متطلب معتمد"
    },
    {
      "id": "REQ-0025",
      "nameAr": "فصل السحب العمودي عن الأفقي",
      "area": "experience",
      "gapId": "GAP-0020",
      "acceptanceAr": "المعطى: عرض فيه أكثر من وسيط. الإجراء: سحب أفقي ثم عمودي. المتوقع: الأفقي يبدل وسيط العرض نفسه والعمودي ينتقل للعرض التالي دون فقدان سياق التفاصيل.",
      "acceptance": {
        "given": "عرض فيه أكثر من وسيط",
        "action": "سحب أفقي ثم عمودي",
        "expected": "الأفقي يبدل وسيط العرض نفسه والعمودي ينتقل للعرض التالي دون فقدان سياق التفاصيل",
        "failures": [
          "احتساب كل صورة مشاهدة جديدة",
          "فقدان موضع التصفح عند الرجوع"
        ],
        "testMethod": "اختبار إيماءات لاحق",
        "evidenceRequired": "سجل إيماءة ومشهد قبل وبعد"
      },
      "planPlacement": "future-gate",
      "existingCapabilityId": "CAP-0015",
      "priority": "must",
      "status": "متطلب معتمد"
    },
    {
      "id": "REQ-0026",
      "nameAr": "معيار وسائط بلا اختراع بصري",
      "area": "media",
      "gapId": "GAP-0020",
      "acceptanceAr": "المعطى: صورة مربعة أو أفقية منخفضة أو عالية الجودة. الإجراء: عرضها في الإطار العمودي. المتوقع: يظهر المنتج دون تشويه، وتُعلَّم الجودة الضعيفة للمراجعة، ولا يُولَّد لون غير موجود.",
      "acceptance": {
        "given": "صورة مربعة أو أفقية منخفضة أو عالية الجودة",
        "action": "عرضها في الإطار العمودي",
        "expected": "يظهر المنتج دون تشويه، وتُعلَّم الجودة الضعيفة للمراجعة، ولا يُولَّد لون غير موجود",
        "failures": [
          "BoxFit الذي يقص المنتج كمعيار ميرا",
          "نشر المحتوى المستورد تلقائيًا"
        ],
        "testMethod": "مراجعة بصرية لاحقة على أكثر من مقاس",
        "evidenceRequired": "عينات قبل وبعد دون قص مضلل"
      },
      "planPlacement": "future-gate",
      "existingCapabilityId": "CAP-0015",
      "priority": "must",
      "status": "متطلب معتمد"
    },
    {
      "id": "REQ-0027",
      "nameAr": "مسار التاجر بلا متجر خارجي",
      "area": "commerce",
      "gapId": "GAP-0019",
      "acceptanceAr": "المعطى: تاجر لا يملك متجرًا خارجيًا. الإجراء: محاولة افتراض شراء داخلي. المتوقع: يبقى المسار قرارًا مفتوحًا ولا يُعرض كقدرة جاهزة.",
      "acceptance": {
        "given": "تاجر لا يملك متجرًا خارجيًا",
        "action": "محاولة افتراض شراء داخلي",
        "expected": "يبقى المسار قرارًا مفتوحًا ولا يُعرض كقدرة جاهزة",
        "failures": [
          "إظهار زر شراء داخلي مؤكد",
          "اعتبار DEC-0001 مغلقًا"
        ],
        "testMethod": "قرار مالك لا تنفيذ",
        "evidenceRequired": "سجل DEC-0007"
      },
      "planPlacement": "future-gate",
      "existingCapabilityId": "CAP-0015",
      "priority": "must",
      "status": "يحتاج قرارًا"
    }
  ],
  "gaps": [
    {
      "id": "GAP-0001",
      "titleAr": "منتج بلا وسائط غنية",
      "severity": "high",
      "reqIds": [
        "REQ-0001"
      ],
      "impactAr": "عرض ضعيف",
      "reuseAr": "Product موجود",
      "proposalAr": "توسيع العقد",
      "evidenceIds": [
        "EVD-0005"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0002",
      "titleAr": "لا Variant",
      "severity": "critical",
      "reqIds": [
        "REQ-0002",
        "REQ-0013"
      ],
      "impactAr": "فلاتر مضللة",
      "reuseAr": "—",
      "proposalAr": "ProductVariant",
      "evidenceIds": [
        "EVD-0019",
        "EVD-0017",
        "EVD-0005"
      ],
      "verification": "SOURCE_ONLY",
      "limitationAr": "الغياب داخل نطاق البحث لا خارج المستودع."
    },
    {
      "id": "GAP-0003",
      "titleAr": "فروع/مواعيد ناقصة",
      "severity": "high",
      "reqIds": [
        "REQ-0003"
      ],
      "impactAr": "لا حجز",
      "reuseAr": "Service",
      "proposalAr": "Branch+Schedule",
      "evidenceIds": [
        "EVD-0003"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0004",
      "titleAr": "لا خط فيديو منتج",
      "severity": "critical",
      "reqIds": [
        "REQ-0004"
      ],
      "impactAr": "لا محتوى مرئي",
      "reuseAr": "—",
      "proposalAr": "MediaAsset",
      "evidenceIds": [
        "EVD-0024",
        "EVD-0019"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0005",
      "titleAr": "لا مشغل متتابع",
      "severity": "high",
      "reqIds": [
        "REQ-0005"
      ],
      "impactAr": "لا Feed",
      "reuseAr": "—",
      "proposalAr": "Vertical feed",
      "evidenceIds": [
        "EVD-0024",
        "EVD-0023"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0006",
      "titleAr": "لا كيان إعلان",
      "severity": "critical",
      "reqIds": [
        "REQ-0007"
      ],
      "impactAr": "لا مشاهير",
      "reuseAr": "—",
      "proposalAr": "Promotion→productId",
      "evidenceIds": [
        "EVD-0023",
        "EVD-0019"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0007",
      "titleAr": "لا فصل أدوار",
      "severity": "high",
      "reqIds": [
        "REQ-0008"
      ],
      "impactAr": "تضارب أسعار",
      "reuseAr": "Partner",
      "proposalAr": "أدوار صريحة",
      "evidenceIds": [
        "EVD-0023"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0008",
      "titleAr": "حالات محتوى ناقصة",
      "severity": "medium",
      "reqIds": [
        "REQ-0009"
      ],
      "impactAr": "مراجعة ضعيفة",
      "reuseAr": "Partner.status",
      "proposalAr": "Media states",
      "evidenceIds": [
        "EVD-0024"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0009",
      "titleAr": "لا موافقة ربط",
      "severity": "medium",
      "reqIds": [
        "REQ-0010"
      ],
      "impactAr": "امتثال",
      "reuseAr": "—",
      "proposalAr": "Approval flow",
      "evidenceIds": [
        "EVD-0023"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0010",
      "titleAr": "لا طلب داخلي",
      "severity": "critical",
      "reqIds": [
        "REQ-0011"
      ],
      "impactAr": "لا إثبات شراء",
      "reuseAr": "externalUrl",
      "proposalAr": "حسب DEC-0001",
      "evidenceIds": [
        "EVD-0010"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0011",
      "titleAr": "رحلة متوقفة",
      "severity": "high",
      "reqIds": [
        "REQ-0012"
      ],
      "impactAr": "لا تجربة",
      "reuseAr": "Discover screens",
      "proposalAr": "تفعيل مرحلي",
      "evidenceIds": [
        "EVD-0001"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0012",
      "titleAr": "فلاتر بلا متغير متسق",
      "severity": "critical",
      "reqIds": [
        "REQ-0013"
      ],
      "impactAr": "نتائج خاطئة",
      "reuseAr": "concernTags",
      "proposalAr": "فهرسة variants",
      "evidenceIds": [
        "EVD-0017"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0013",
      "titleAr": "فلترة خادمية غير مثبتة للخصائص المتقدمة",
      "severity": "medium",
      "reqIds": [
        "REQ-0014"
      ],
      "impactAr": "تصفية صفحة",
      "reuseAr": "listPartners",
      "proposalAr": "API filters",
      "evidenceIds": [
        "EVD-0006"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0014",
      "titleAr": "أحداث محدودة",
      "severity": "medium",
      "reqIds": [
        "REQ-0015"
      ],
      "impactAr": "إسناد ضعيف",
      "reuseAr": "PartnerEvent",
      "proposalAr": "توسيع الأحداث",
      "evidenceIds": [
        "EVD-0013"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0015",
      "titleAr": "سياسة إعلان×بشرة",
      "severity": "high",
      "reqIds": [
        "REQ-0017"
      ],
      "impactAr": "خصوصية",
      "reuseAr": "مطابقة غير مدفوعة",
      "proposalAr": "حظر استهداف",
      "evidenceIds": [],
      "verification": "UNVERIFIED",
      "limitationAr": "لا بحث يثبت غياب فصل الإعلان عن تحليل البشرة؛ المتطلب مقترح لأن المسار غير موصوف في الأدلة المرفقة."
    },
    {
      "id": "GAP-0016",
      "titleAr": "خلط أنواع التحويل",
      "severity": "medium",
      "reqIds": [
        "REQ-0019"
      ],
      "impactAr": "توقعات خاطئة",
      "reuseAr": "نصوص قريبًا",
      "proposalAr": "مفردات صارمة",
      "evidenceIds": [
        "EVD-0003"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0017",
      "titleAr": "بث حي غير محسوم",
      "severity": "low",
      "reqIds": [
        "REQ-0020"
      ],
      "impactAr": "نطاق",
      "reuseAr": "—",
      "proposalAr": "خارج المرحلة الأولى",
      "evidenceIds": [
        "EVD-0023"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0018",
      "titleAr": "لا قياس مشاهدات معتمد في تجربة ميرا",
      "severity": "high",
      "reqIds": [
        "REQ-0021",
        "REQ-0023"
      ],
      "impactAr": "لا عدد صادق على العرض",
      "reuseAr": "لا يُفترض وجوده في الأماكن",
      "proposalAr": "مواصفة ثم تنفيذ لاحق بعد المراجعة",
      "evidenceIds": [
        "EVD-0029"
      ],
      "verification": "SOURCE_ONLY"
    },
    {
      "id": "GAP-0019",
      "titleAr": "ربط المتجر الخارجي غير متحقق على منصة محددة",
      "severity": "high",
      "reqIds": [
        "REQ-0022"
      ],
      "impactAr": "لا ادعاء دعم زد أو غيرها",
      "reuseAr": "رابط الشراء الخارجي الحالي إن وُجد لا يكفي للمزامنة",
      "proposalAr": "عقد ربط بعد وثائق أو اختبار",
      "evidenceIds": [
        "EVD-0029"
      ],
      "verification": "UNVERIFIED"
    },
    {
      "id": "GAP-0020",
      "titleAr": "العرض العمودي متعدد الوسائط يحتاج تكييفًا",
      "severity": "medium",
      "reqIds": [
        "REQ-0024",
        "REQ-0025",
        "REQ-0026"
      ],
      "impactAr": "نسخ الأماكن كما هي يقص المنتج أو يحصر العرض في الفيديو",
      "reuseAr": "PageView ومعرض التفاصيل مرجع سلوك",
      "proposalAr": "معيار عرض ميرا",
      "evidenceIds": [
        "EVD-0028"
      ],
      "verification": "SOURCE_ONLY"
    }
  ],
  "decisions": [
    {
      "id": "DEC-0001",
      "titleAr": "الدفع عند الشريك أم داخل ميرا؟",
      "status": "يحتاج قرارًا",
      "owner": "مالك المشروع",
      "options": [
        "externalUrl الحالي",
        "طلب داخلي"
      ],
      "evidenceIds": [
        "EVD-0007"
      ]
    },
    {
      "id": "DEC-0002",
      "titleAr": "بث حي في المرحلة الأولى؟",
      "status": "يحتاج قرارًا",
      "owner": "مالك المشروع",
      "options": [
        "مسجّل فقط",
        "بث لاحقًا",
        "بث مبكر"
      ],
      "evidenceIds": []
    },
    {
      "id": "DEC-0003",
      "titleAr": "موافقة المتجر على إعلان المشهور؟",
      "status": "مقترح",
      "owner": "مالك المشروع",
      "options": [
        "إلزامي",
        "اختياري",
        "حسب الفئة"
      ],
      "evidenceIds": []
    },
    {
      "id": "DEC-0004",
      "titleAr": "تكرار إعلانات نفس المنتج",
      "status": "مقترح",
      "owner": "مالك المشروع",
      "options": [
        "واحد لكل جلسة",
        "تجميع",
        "تكرار مع شارة"
      ],
      "evidenceIds": []
    },
    {
      "id": "DEC-0005",
      "titleAr": "اعتماد هذه الدراسة",
      "status": "بانتظار إعادة المراجعة",
      "owner": "مالك المشروع",
      "options": [
        "اعتماد",
        "تعديل",
        "رفض"
      ],
      "evidenceIds": []
    },
    {
      "id": "DEC-0006",
      "titleAr": "تكييف مكونات الأماكن داخل ميرا دون نقل المشروع",
      "status": "متطلب معتمد",
      "owner": "مالك المشروع",
      "options": [
        "نقل المشروع كاملًا",
        "تكييف المكونات المناسبة",
        "إعادة البناء من الصفر"
      ],
      "evidenceIds": [
        "EVD-0028"
      ],
      "noteAr": "متطلب معتمد للدراسة. ليس تنفيذًا وليس إغلاقًا لـ DEC-0005."
    },
    {
      "id": "DEC-0007",
      "titleAr": "مسار التاجر الذي لا يملك متجرًا خارجيًا",
      "status": "يحتاج قرارًا",
      "owner": "مالك المشروع",
      "options": [
        "يبقى بلا شراء داخلي حتى قرار الدفع",
        "مسار لاحق بعد DEC-0001"
      ],
      "evidenceIds": [
        "EVD-0029"
      ]
    }
  ],
  "roadmap": [
    {
      "id": "GATE-00",
      "titleAr": "التدقيق والدراسة والموقع",
      "status": "in_progress",
      "goalAr": "دراسة مرجعية قابلة للمراجعة بلا تنفيذ منتج",
      "scopeAr": "المصدر والموقع والحزمة فقط",
      "reqIds": [],
      "decisionIds": [
        "DEC-0005"
      ],
      "dependsOn": [],
      "likelyUnits": [
        "docs/mira-commerce-reference"
      ],
      "reuseAr": "لا إعادة استخدام وظيفي في هذه المرحلة",
      "risksAr": [
        "إغلاق البوابة قبل كفاية الأدلة"
      ],
      "effortAr": "مكتمل كمسودة RC2؛ المراجعة البشرية خارج التقدير",
      "effortAssumptionsAr": "لا يشمل تنفيذ المتجر",
      "entryCriteriaAr": [
        "تكليف دراسة بلا تعديل منتج"
      ],
      "exitCriteriaAr": [
        "الموقع يعرض النتائج والأدلة والملاحظات داخل أقسامه",
        "الحزمة وSHA-256 متاحان للمراجع",
        "لم يُغلق GATE-00 ولم يُعتمد القرار DEC-0005 من هذه الدراسة",
        "لم يُعدَّل سلوك تطبيق أو خادم التجارة"
      ],
      "proofPackAr": [
        "الموقع",
        "ZIP",
        "سجل الاختبارات",
        "سجل الملاحظات"
      ],
      "rollbackAr": "حذف حزمة الدراسة لا يرجع منتجًا لأن المنتج لم يُمس"
    },
    {
      "id": "GATE-01",
      "titleAr": "هوية الكتالوج والعزل وإعادة الاستخدام",
      "status": "planned",
      "goalAr": "منتج وخدمة وفرع ومتغير فوق الجداول الحالية مع عزل الشريك",
      "scopeAr": "الخادم وويب الشركاء والبيانات ولوحة الإدارة. ليس واجهة الفيديو.",
      "reqIds": [
        "REQ-0001",
        "REQ-0002",
        "REQ-0003",
        "REQ-0006",
        "REQ-0016",
        "REQ-0018"
      ],
      "decisionIds": [
        "DEC-0003"
      ],
      "dependsOn": [
        "GATE-00"
      ],
      "likelyUnits": [
        "mira-api/prisma/schema.prisma",
        "mira-api/src/partners-portal",
        "partners-portal/web",
        "mira-api/src/admin"
      ],
      "reuseAr": "Partner وProduct وService وPartnerTokenGuard وassertProductOwner",
      "risksAr": [
        "ترحيل منتجات بلا متغيرات",
        "إبقاء trackEvent يقبل معرف العميل"
      ],
      "effortAr": "4 إلى 8 أسابيع",
      "effortAssumptionsAr": "مهندسان يعرفان Prisma الحالي، بلا قرار دفع داخلي، وبلا بيانات إنتاج تُنسخ",
      "entryCriteriaAr": [
        "إعادة مراجعة GATE-00 أو إعفاء مكتوب من المالك",
        "DEC-0003 محدد"
      ],
      "exitCriteriaAr": [
        "متغير واحد يطابق لونًا ومقاسًا وتوفرًا معًا",
        "شريك لا يعدّل منتج شريك آخر على قاعدة اختبار",
        "المنتجات الحالية ما زالت تُقرأ",
        "حزمة اختبار العزل مرفقة"
      ],
      "proofPackAr": [
        "اختبارات الخدمة",
        "مخطط بعد الترحيل",
        "لقطات نموذج الشريك"
      ],
      "rollbackAr": "علم ترحيل معطل واستعادة نسخة قاعدة الاختبار. لا إسقاط جداول الإنتاج ضمن هذه البوابة."
    },
    {
      "id": "GATE-02",
      "titleAr": "دورة الوسائط والتصفح المرئي",
      "status": "planned",
      "goalAr": "رفع ومعالجة ومراجعة وتشغيل مقطع مرتبط بالمنتج الأصلي",
      "scopeAr": "تطبيق ميرا والخادم والتخزين. يشمل الفشل وإعادة المحاولة وليس شاشة تشغيل فقط.",
      "reqIds": [
        "REQ-0004",
        "REQ-0005",
        "REQ-0009",
        "REQ-0012"
      ],
      "decisionIds": [],
      "dependsOn": [
        "GATE-01"
      ],
      "likelyUnits": [
        "lib/features/marketplace",
        "mira-api/src",
        "موفر تخزين لم يُختار"
      ],
      "reuseAr": "لا مشغل فيديو قائم داخل lib حسب EVD-0024. يُعاد استخدام هوية المنتج من GATE-01.",
      "risksAr": [
        "تقدير تكلفة غير متحقق",
        "ذاكرة الجهاز عند التحميل المسبق"
      ],
      "effortAr": "6 إلى 10 أسابيع",
      "effortAssumptionsAr": "موفر تخزين متفق عليه، فيديو قصير حتى 60 ثانية، بلا بث حي",
      "entryCriteriaAr": [
        "GATE-01 خرج بأدلة",
        "حد حجم الوسائط مقرر"
      ],
      "exitCriteriaAr": [
        "المقطع غير المنشور لا يظهر في الخلاصة",
        "صوت مقطع واحد فقط",
        "الموضع يُستأنف",
        "فشل الرفع قابل لإعادة المحاولة دون تكرار النشر"
      ],
      "proofPackAr": [
        "اختبار الدورة",
        "لقطات هاتف وجهاز لوحي",
        "سجل فشل المعالجة"
      ],
      "rollbackAr": "إيقاف النشر بعلم وإبقاء الملفات غير المنشورة غير مرئية"
    },
    {
      "id": "GATE-03",
      "titleAr": "الفلاتر والفهرسة",
      "status": "planned",
      "goalAr": "فلاتر سريعة ومتقدمة على خصائص المتغير مع عدّ صحيح",
      "scopeAr": "الخادم والفهرس والتطبيق. ليس ترشيح قائمة محلية بعد جلب الكل.",
      "reqIds": [
        "REQ-0013",
        "REQ-0014"
      ],
      "decisionIds": [],
      "dependsOn": [
        "GATE-01"
      ],
      "likelyUnits": [
        "mira-api/src/marketplace",
        "lib/features/marketplace"
      ],
      "reuseAr": "concernTags وskinTypes كسمات قائمة لا كبديل عن لون الملابس",
      "risksAr": [
        "عدّ المنتجات بدل عدّ المقاطع",
        "حالة الفلتر تضيع عند الرجوع"
      ],
      "effortAr": "3 إلى 5 أسابيع",
      "effortAssumptionsAr": "الفهرس على قاعدة الاختبار، كتالوج حتى 50 منتجًا لكل متجر في سيناريو القبول",
      "entryCriteriaAr": [
        "متغيرات GATE-01 قابلة للاستعلام"
      ],
      "exitCriteriaAr": [
        "مثال الفستان الأزرق M المتوفر يطابق متغيرًا واحدًا",
        "عدد المنتجات المطابقة مستقل عن عدد المقاطع",
        "الصفحة الثانية لا تكرر الصف الأول",
        "العودة من التفاصيل تُبقي الفلتر"
      ],
      "proofPackAr": [
        "استعلام موثّق",
        "لقطة العدد",
        "حالة فارغة"
      ],
      "rollbackAr": "إخفاء الفلاتر المتقدمة والإبقاء على قائمة غير مفلترة"
    },
    {
      "id": "GATE-04",
      "titleAr": "المشاهير والإسناد والموافقة",
      "status": "planned",
      "goalAr": "إعلان يشير إلى المنتج بلا نسخ سعر أو مخزون",
      "scopeAr": "العقود والمراجعة الإدارية والعرض والخصوصية. ليس حملة إعلانية جاهزة.",
      "reqIds": [
        "REQ-0007",
        "REQ-0008",
        "REQ-0010",
        "REQ-0017"
      ],
      "decisionIds": [
        "DEC-0004"
      ],
      "dependsOn": [
        "GATE-01",
        "DEC-0004"
      ],
      "likelyUnits": [
        "mira-api/src",
        "admin-portal/web",
        "lib/features/marketplace"
      ],
      "reuseAr": "اعتماد الشريك الحالي كنمط مراجعة، لا نموذج مشهور قائم",
      "risksAr": [
        "اقتباس تنظيمي ليس اعتمادًا قانونيًا",
        "خلط الإعلان مع تحليل البشرة"
      ],
      "effortAr": "4 إلى 7 أسابيع",
      "effortAssumptionsAr": "قرار DEC-0004 ثابت، وبلا بث حي",
      "entryCriteriaAr": [
        "GATE-01",
        "إجابة DEC-0004"
      ],
      "exitCriteriaAr": [
        "تغيير سعر المنتج يظهر في الإعلان دون حقل سعر منسوخ",
        "رفض المتجر يزيل الإعلان ويبقي المنتج",
        "الإعلان موسوم مدفوعًا",
        "أطراف الناشر والمعلن والبائع مفصولة في السجل"
      ],
      "proofPackAr": [
        "عقد الإعلان",
        "اختبار الموافقة",
        "لقطة الوسم"
      ],
      "rollbackAr": "حالة الربط suspended تخفي الإعلان فقط"
    },
    {
      "id": "GATE-05",
      "titleAr": "مسارات الطلب والحجز والاستفسار والتحليلات",
      "status": "planned",
      "goalAr": "تمييز الأفعال وحفظ لقطة المتغير عند الطلب إن اختير الدفع داخل ميرا",
      "scopeAr": "الخادم والتطبيق والإدارة والتحقق. الشراء الداخلي مشروط بـ DEC-0001.",
      "reqIds": [
        "REQ-0011",
        "REQ-0015",
        "REQ-0019"
      ],
      "decisionIds": [
        "DEC-0001"
      ],
      "dependsOn": [
        "GATE-01",
        "DEC-0001"
      ],
      "likelyUnits": [
        "mira-api/src",
        "lib/features/marketplace",
        "admin-portal/web"
      ],
      "reuseAr": "externalUrl للشراء الخارجي، وأحداث PartnerEvent بعد تصحيح مصدر partnerId",
      "risksAr": [
        "بناء طلب داخلي قبل قرار مكان الدفع",
        "التتبع الحالي يقبل معرف العميل"
      ],
      "effortAr": "5 إلى 9 أسابيع إذا اختير دفع داخلي؛ 2 إلى 4 إذا بقي الشراء خارجيًا والحجز هو المسار الجديد",
      "effortAssumptionsAr": "لا تشغيل دفع إنتاجي داخل البوابة. بيئة اختبار فقط.",
      "entryCriteriaAr": [
        "قرار DEC-0001 مكتوب",
        "GATE-01 مكتمل"
      ],
      "exitCriteriaAr": [
        "أزرار الشراء والحجز والاستفسار والاتصال منفصلة",
        "إن وُجد طلب فهو يحتفظ بلقطة السعر",
        "حدث التحليلات لا يُقبل بمعرف شريك من الجسم دون تفويض",
        "لا رسالة أو حجز حقيقي على إنتاج"
      ],
      "proofPackAr": [
        "مصفوفة المسارات",
        "اختبار اللقطة",
        "اختبار رفض التتبع المتجاوز"
      ],
      "rollbackAr": "الإبقاء على الرابط الخارجي وإخفاء أزرار المسار الجديد"
    },
    {
      "id": "GATE-06",
      "titleAr": "المرحلة الأولى — استكمال حزمة مصدر الأماكن",
      "status": "in_progress",
      "goalAr": "إغلاق فجوات المصدر والتوثيق والتحقق المستقل بحزمة RC2",
      "scopeAr": "يدخل: الاعتماديات الناقصة والتوثيق والمدقق. يخرج: تنفيذ ميرا وتعديل دار كار.",
      "reqIds": [],
      "decisionIds": [
        "DEC-0006"
      ],
      "dependsOn": [
        "GATE-00"
      ],
      "likelyUnits": [
        "حزمة DAR_PLACES_TO_MIRA_SOURCE_HANDOFF_RC2"
      ],
      "reuseAr": "لا دمج",
      "risksAr": [
        "اعتبار البصمة إثباتًا لاكتمال كل ملفات المشروع الأصلي"
      ],
      "effortAr": "جولة توثيق",
      "effortAssumptionsAr": "بلا تنفيذ منتج",
      "entryCriteriaAr": [
        "وجود حزمة RC1 وملاحظات المراجعة"
      ],
      "exitCriteriaAr": [
        "الملفات الناقصة مرفقة أو موثقة كمانع",
        "الفحوص السلبية ترفض الحزم التالفة",
        "الحزمة السابقة لم تُستبدل"
      ],
      "proofPackAr": [
        "ZIP RC2",
        "negative_validation_rc2",
        "freshness"
      ],
      "rollbackAr": "الإبقاء على حزمة RC1 كما هي"
    },
    {
      "id": "GATE-07",
      "titleAr": "المرحلة الثانية — دراسة التكييف في موقع ميرا",
      "status": "in_progress",
      "goalAr": "تسجيل القرارات والمتطلبات وخطة الملفات داخل الموقع المرجعي",
      "scopeAr": "يدخل: بيانات الدراسة والأقسام. يخرج: تعديل تطبيق ميرا.",
      "reqIds": [],
      "decisionIds": [
        "DEC-0006",
        "DEC-0007"
      ],
      "dependsOn": [
        "GATE-06"
      ],
      "likelyUnits": [
        "docs/mira-commerce-reference"
      ],
      "reuseAr": "الموقع الحالي نفسه",
      "risksAr": [
        "تعليم المعالجة كاعتماد نهائي"
      ],
      "effortAr": "جولة توثيق",
      "effortAssumptionsAr": "لا تنفيذ قبل مراجعة هذه المرحلة",
      "entryCriteriaAr": [
        "حزمة RC2 معروفة بالاسم والبصمة"
      ],
      "exitCriteriaAr": [
        "كل متطلب جديد له حالة",
        "المرجع البصري الناقص مصرح به",
        "الخطة لا تأذن ببدء التنفيذ الآن"
      ],
      "proofPackAr": [
        "أقسام 22-35",
        "validate_study"
      ],
      "rollbackAr": "بيانات JSON السابقة تبقى في السجل"
    },
    {
      "id": "GATE-08",
      "titleAr": "المرحلة الثالثة — تجربة العرض داخل ميرا",
      "status": "planned",
      "goalAr": "شاشة كاملة ووسائط وتصنيفات وبحث وفلاتر وتفاصيل بهوية ميرا",
      "scopeAr": "يدخل لاحقًا: الواجهة ببيانات اختبار. يخرج الآن: أي تنفيذ.",
      "reqIds": [
        "REQ-0024",
        "REQ-0025",
        "REQ-0026"
      ],
      "decisionIds": [
        "DEC-0006"
      ],
      "dependsOn": [
        "GATE-07"
      ],
      "likelyUnits": [
        "lib/features واجهة ميرا المقترحة لاحقًا"
      ],
      "reuseAr": "نمط PageView بعد التكييف لا النسخ",
      "risksAr": [
        "قص المنتج",
        "كسر RTL أو SafeArea"
      ],
      "effortAr": "غير مقدّر للتنفيذ",
      "effortAssumptionsAr": "لا يبدأ قبل مراجعة GATE-07 وحزمة إثبات خاصة",
      "entryCriteriaAr": [
        "مراجعة المرحلة الثانية",
        "بيانات اختبار واضحة"
      ],
      "exitCriteriaAr": [
        "RTL وSafeArea",
        "سلامة الإيماءات",
        "ظهور المنتج وتوقف الصوت وحالات الفراغ والخطأ والإتاحة"
      ],
      "proofPackAr": [
        "ZIP لاحق",
        "لقطات جهاز"
      ],
      "rollbackAr": "علم واجهة يمكن إطفاؤه"
    },
    {
      "id": "GATE-09",
      "titleAr": "المرحلة الرابعة — لوحة التاجر والمشاهدات والربط",
      "status": "planned",
      "goalAr": "إدارة المحتوى والربط الخارجي والإحصاءات الصادقة",
      "scopeAr": "يدخل لاحقًا: اللوحة والإحصاءات. يخرج الآن: إنشاء endpoint أو قاعدة مشاهدات.",
      "reqIds": [
        "REQ-0021",
        "REQ-0022",
        "REQ-0023"
      ],
      "decisionIds": [
        "DEC-0001",
        "DEC-0007"
      ],
      "dependsOn": [
        "GATE-08"
      ],
      "likelyUnits": [
        "لوحة التاجر",
        "عقد المشاهدات"
      ],
      "reuseAr": "بوابة المزود كنمط بعد إعادة تقييم الصلاحيات",
      "risksAr": [
        "تكرار الأحداث",
        "صفر كاذب",
        "مزامنة سعر خاطئة"
      ],
      "effortAr": "غير مقدّر للتنفيذ",
      "effortAssumptionsAr": "قدرات المنصة الخارجية غير معتمدة",
      "entryCriteriaAr": [
        "مراجعة المرحلة الثالثة",
        "قرار دفع ما زال مفتوحًا ولا يُغلق ضمنيًا"
      ],
      "exitCriteriaAr": [
        "عزل المتاجر",
        "عدم تكرار الأحداث",
        "صدق الأعداد وحالات الطلب",
        "معالجة فشل المزامنة"
      ],
      "proofPackAr": [
        "ZIP لاحق",
        "اختبارات عقد"
      ],
      "rollbackAr": "إيقاف النشر دون حذف المصدر الخارجي"
    }
  ],
  "evidence": [
    {
      "id": "EVD-0001",
      "claim": "MIRA_MARKETPLACE_ENABLED default false",
      "claimType": "fact",
      "repo": "mira",
      "path": "lib/core/config/mira_features.dart",
      "symbol": "",
      "lines": "41-47",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "779d099d02ebe82171122ee8313ae69479c8b22d8da64b9716bb5fd892c3729f",
      "excerptFile": "evidence/source/EVD-0001.txt",
      "proves": "MIRA_MARKETPLACE_ENABLED default false",
      "doesNotProve": "لا يثبت سلوك الإنتاج المنشور دون ربط النسخة المنشورة بهذا الـ commit",
      "runtime": "SOURCE_ONLY",
      "limitations": "فحص مصدر فقط"
    },
    {
      "id": "EVD-0002",
      "claim": "Route gates redirect when marketplace disabled",
      "claimType": "fact",
      "repo": "mira",
      "path": "lib/main.dart",
      "symbol": "",
      "lines": "355-385",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "ab3be120a7558dbb7822f5d0e67be9a9a12646a06fe91046353fb0b53185dd9c",
      "excerptFile": "evidence/source/EVD-0002.txt",
      "proves": "Route gates redirect when marketplace disabled",
      "doesNotProve": "لا يثبت سلوك الإنتاج المنشور دون ربط النسخة المنشورة بهذا الـ commit",
      "runtime": "SOURCE_ONLY",
      "limitations": "فحص مصدر فقط"
    },
    {
      "id": "EVD-0003",
      "claim": "Booking button stubbed",
      "claimType": "fact",
      "repo": "mira",
      "path": "lib/features/marketplace/presentation/screens/service_detail_screen.dart",
      "symbol": "",
      "lines": "71-97",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "c6fb3485eb7cc65958b4af7a8acfea357b7073bb2a56502ed1f2e9e9cd417d9b",
      "excerptFile": "evidence/source/EVD-0003.txt",
      "proves": "Booking button stubbed",
      "doesNotProve": "لا يثبت سلوك الإنتاج المنشور دون ربط النسخة المنشورة بهذا الـ commit",
      "runtime": "SOURCE_ONLY",
      "limitations": "فحص مصدر فقط"
    },
    {
      "id": "EVD-0004",
      "claim": "Product buy = external launchUrl",
      "claimType": "fact",
      "repo": "mira",
      "path": "lib/features/marketplace/presentation/screens/product_detail_screen.dart",
      "symbol": "",
      "lines": "1-45",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "192ea1ef27e3377dd6a78154262a5e716ba6ae8fc10269a7fc83a9e56e80dc02",
      "excerptFile": "evidence/source/EVD-0004.txt",
      "proves": "Product buy = external launchUrl",
      "doesNotProve": "لا يثبت سلوك الإنتاج المنشور دون ربط النسخة المنشورة بهذا الـ commit",
      "runtime": "SOURCE_ONLY",
      "limitations": "فحص مصدر فقط"
    },
    {
      "id": "EVD-0005",
      "claim": "Partner/Product/Service; no Order/Cart",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/prisma/schema.prisma",
      "symbol": "",
      "lines": "117-180",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "01dd03c140e35698ab4b795404201f3e1ba7d23fd828de1b2ee1b5cb447a65d2",
      "excerptFile": "evidence/source/EVD-0005.txt",
      "proves": "Partner/Product/Service; no Order/Cart",
      "doesNotProve": "مقتطف المخطط يثبت شكل الجداول المعروضة فيه فقط. لا ينفي جداول خارج النطاق أو في خدمة أخرى.",
      "runtime": "SOURCE_ONLY",
      "limitations": "فحص مصدر فقط"
    },
    {
      "id": "EVD-0006",
      "claim": "Public marketplace APIs",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/marketplace/marketplace.controller.ts",
      "symbol": "",
      "lines": "1-40",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "13833f34b202b1098b46d6666688a8f4e58a99369f2f2e60826f6b6005decac4",
      "excerptFile": "evidence/source/EVD-0006.txt",
      "proves": "Public marketplace APIs",
      "doesNotProve": "لا يثبت سلوك الإنتاج المنشور دون ربط النسخة المنشورة بهذا الـ commit",
      "runtime": "SOURCE_ONLY",
      "limitations": "فحص مصدر فقط"
    },
    {
      "id": "EVD-0007",
      "claim": "Pay at partner; no Mira cart",
      "claimType": "document",
      "repo": "mira",
      "path": "partners-portal/SPEC.md",
      "symbol": "",
      "lines": "1-80",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "82cad22cbe38f082adb0edb20f3f4afae4bf2a19d01ba22c7bc468391ad42afb",
      "excerptFile": "evidence/source/EVD-0007.txt",
      "proves": "Pay at partner; no Mira cart",
      "doesNotProve": "ملف مواصفات. لا يثبت أن بوابة الشركاء مفعلة في الإنتاج، ولا يغني عن قراءة المتحكم والحارس.",
      "runtime": "SOURCE_ONLY",
      "limitations": "SPEC فقط. راجع EVD-0011 وما بعده للتنفيذ."
    },
    {
      "id": "EVD-0008",
      "claim": "Local offline seed catalog",
      "claimType": "fact",
      "repo": "mira",
      "path": "lib/features/marketplace/data/marketplace_local_catalog.dart",
      "symbol": "",
      "lines": "90-120",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "13ec504cf64b923268d264724366e5b1c651368bf0e61c822fa40e76be8c67c7",
      "excerptFile": "evidence/source/EVD-0008.txt",
      "proves": "Local offline seed catalog",
      "doesNotProve": "لا يثبت سلوك الإنتاج المنشور دون ربط النسخة المنشورة بهذا الـ commit",
      "runtime": "SOURCE_ONLY",
      "limitations": "فحص مصدر فقط"
    },
    {
      "id": "EVD-0010",
      "claim": "لا نماذج Order/Cart للمنتجات",
      "claimType": "search-summary",
      "repo": "mira",
      "path": "mira-api/prisma/schema.prisma",
      "symbol": "search",
      "lines": "n/a",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "01dd03c140e35698ab4b795404201f3e1ba7d23fd828de1b2ee1b5cb447a65d2",
      "excerptFile": "evidence/commands/CMD-0001-search-order-cart.txt",
      "proves": "Absence after search",
      "doesNotProve": "الملف السابق ملخص مكتوب وليس سجل أمر. لا ينفي وجود الطلب خارج المسارات المفحوصة. السجل القابل للمراجعة هو EVD-0018.",
      "runtime": "SOURCE_ONLY",
      "limitations": "ملخص غير كافٍ. أُبقي كدليل على قصور النسخة السابقة."
    },
    {
      "id": "EVD-0011",
      "claim": "متحكم بوابة الشركاء ينفذ التقديم والدخول وCRUD والاعتماد",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/partners-portal/partners-portal.controller.ts",
      "symbol": "",
      "lines": "38-130",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "915b7b3406f94e56dbb75dfb5da0cc14ddc7ab2de189dc7d385655d45b8af7c2",
      "excerptFile": "evidence/source/EVD-0011.txt",
      "proves": "وجود مسارات في المصدر",
      "doesNotProve": "لا يثبت نشرًا أو تفعيلًا في الإنتاج",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0012",
      "claim": "partnerId يُؤخذ من الرمز المخزن وليس من جسم طلب الكتالوج",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/partners-portal/guards/partner-token.guard.ts",
      "symbol": "",
      "lines": "14-38",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "9df2c6069dd225a6318f9ddf202537e02d5fdfe35b3e16028ac9573ce6217974",
      "excerptFile": "evidence/source/EVD-0012.txt",
      "proves": "مصدر partnerId في الطلبات المحمية",
      "doesNotProve": "لا يثبت أن كل المسارات محمية؛ track بلا حارس",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0013",
      "claim": "تعديل وحذف المنتج والخدمة يشترطان partnerId المالك؛ التتبع يقبل معرف العميل",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/partners-portal/partners-portal.service.ts",
      "symbol": "",
      "lines": "282-412",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "dd4aaa49c38647860fe75b147a8a20de11d518f725222050674608fcfb7d6ccf",
      "excerptFile": "evidence/source/EVD-0013.txt",
      "proves": "عزل الكتابة على الكتالوج في المصدر، وثغرة كتابة أحداث التتبع",
      "doesNotProve": "لا يثبت عزلًا على قاعدة إنتاج حية",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0014",
      "claim": "متحكم الإدارة يسرد الشركاء ويعتمد الطلبات ويوقف الشريك",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/admin/admin.controller.ts",
      "symbol": "",
      "lines": "24-109",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "2af5bfd10d29da42966f8cad996c4009ff9ab88f362755dc8a51ee2d9303f9a3",
      "excerptFile": "evidence/source/EVD-0014.txt",
      "proves": "وجود مسارات إدارة في المصدر خلف AdminApiKeyGuard",
      "doesNotProve": "لا يثبت أن المفتاح مضبوط في الإنتاج أو أن الواجهة منشورة",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0015",
      "claim": "واجهة الإدارة الثابتة تستدعي /admin بمفتاح محلي",
      "claimType": "fact",
      "repo": "mira",
      "path": "admin-portal/web/js/api.js",
      "symbol": "",
      "lines": "1-79",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "06b8ff8af6d4b96987245826121a69e4d57bc682e4451331dc206f04073be247",
      "excerptFile": "evidence/source/EVD-0015.txt",
      "proves": "عميل لوحة الإدارة موجود في المستودع",
      "doesNotProve": "العنوان الافتراضي localhost. لا يثبت نشر admin.mira.app",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0016",
      "claim": "واجهة الشركاء تستدعي مسارات partners-portal",
      "claimType": "fact",
      "repo": "mira",
      "path": "partners-portal/web/js/api.js",
      "symbol": "",
      "lines": "1-79",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "93548cfbd8122f7c19ca15f8f8a1598554f011cd3ad6f949e0b787271cfa1cdc",
      "excerptFile": "evidence/source/EVD-0016.txt",
      "proves": "عميل البوابة يطابق مسارات الخادم",
      "doesNotProve": "لا يثبت جلسة إنتاج أو عزلًا من جهة المتصفح وحده",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0017",
      "claim": "عقد إنشاء المنتج بلا مقاس أو لون أو مخزون أو وسيط",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/partners-portal/dto/catalog.dto.ts",
      "symbol": "",
      "lines": "13-90",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "13e94f39889a337fa0f194b9b17fef0a18a12a842415596be7d9f1a330fa2cee",
      "excerptFile": "evidence/source/EVD-0017.txt",
      "proves": "شكل الإدخال الحالي للشريك",
      "doesNotProve": "لا ينفي حقولًا في عميل آخر لم يُفحص",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY داخل هذا الملف"
    },
    {
      "id": "EVD-0018",
      "claim": "بحث Order/Cart/Booking داخل المسارات المحددة لم يُرجع تطابقًا",
      "claimType": "search",
      "repo": "mira",
      "path": "evidence/commands/CMD-RC2-0001-order-cart.txt",
      "symbol": "",
      "lines": "n/a",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "a8fee5c4f001fbd5f43a3a10ebaa3c39279b65ed36ce576ee207806822ac16f9",
      "excerptFile": "evidence/commands/CMD-RC2-0001-order-cart.txt",
      "proves": "لا تطابق للنماذج المذكورة داخل النطاق وexit=1",
      "doesNotProve": "لا ينفي منظومة تجارة خارج المستودع أو بأسماء مختلفة",
      "runtime": "SOURCE_ONLY",
      "limitations": "نطاق الأمر مذكور في الملف"
    },
    {
      "id": "EVD-0019",
      "claim": "لا نماذج Branch/Employee/ProductVariant/MediaAsset/Creator في schema",
      "claimType": "search",
      "repo": "mira",
      "path": "evidence/commands/CMD-RC2-0002-models.txt",
      "symbol": "",
      "lines": "n/a",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "c600449a88756efac5bf65727f9d79a84b65a97943d81bb489f7b6b75c1a29d1",
      "excerptFile": "evidence/commands/CMD-RC2-0002-models.txt",
      "proves": "لا تطابق لتلك النماذج في mira-api/prisma وexit=1",
      "doesNotProve": "لا ينفي الجداول إن وُجدت خارج هذا الملف",
      "runtime": "SOURCE_ONLY",
      "limitations": "بحث أسماء محددة"
    },
    {
      "id": "EVD-0020",
      "claim": "علم الاشتراك وعلم السوق يُقرآن من dart-define وافتراضهما false",
      "claimType": "fact",
      "repo": "mira",
      "path": "lib/core/config/mira_features.dart",
      "symbol": "",
      "lines": "14-46",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "779d099d02ebe82171122ee8313ae69479c8b22d8da64b9716bb5fd892c3729f",
      "excerptFile": "evidence/source/EVD-0020.txt",
      "proves": "الإخفاء في بناء التطبيق يعتمد على العلم",
      "doesNotProve": "لا يثبت قيمة العلم في بناء المتجر المنشور",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0021",
      "claim": "الدخول يربط الجلسة بسجل PartnerUser",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/partners-portal/partners-portal.service.ts",
      "symbol": "",
      "lines": "102-125",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "dd4aaa49c38647860fe75b147a8a20de11d518f725222050674608fcfb7d6ccf",
      "excerptFile": "evidence/source/EVD-0021.txt",
      "proves": "مصدر هوية الشريك بعد الدخول",
      "doesNotProve": "الرمز نفسه سر الدخول؛ لا كلمة مرور منفصلة في هذا المسار",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0022",
      "claim": "خط أساس RC2 يطابق commit الدراسة السابقة وشجرة العمل متسخة خارج الدراسة",
      "claimType": "search",
      "repo": "mira",
      "path": "evidence/git/HEAD.txt",
      "symbol": "",
      "lines": "n/a",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "9e7092b8d5b8f24b9512e884b8282fa00f4a4710a98a8afd2311b3fbb7c457c4",
      "excerptFile": "evidence/git/STATUS.txt",
      "proves": "HEAD والفرع وحالة الشجرة وقت الفحص",
      "doesNotProve": "لا يصف محتوى كل ملف متسخ",
      "runtime": "SOURCE_ONLY",
      "limitations": "لم يُعاد ضبط المستودع"
    },
    {
      "id": "EVD-0023",
      "claim": "لا رموز فيديو منتج أو مشاهير أو متغير في النطاق المبحوث",
      "claimType": "search",
      "repo": "mira",
      "path": "evidence/commands/CMD-RC2-0003-video-creator.txt",
      "symbol": "",
      "lines": "n/a",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "d954c4c3832175df7408f0fa1e447e3e840a3edb41ec36331daabdbfc3add438",
      "excerptFile": "evidence/commands/CMD-RC2-0003-video-creator.txt",
      "proves": "exit=1 للأنماط المذكورة",
      "doesNotProve": "غياب الكلمة ليس غياب كل وسيط في العالم",
      "runtime": "SOURCE_ONLY",
      "limitations": "نطاق محدد في رأس الملف"
    },
    {
      "id": "EVD-0024",
      "claim": "لا VideoPlayer أو video_player في lib وmira-api/src",
      "claimType": "search",
      "repo": "mira",
      "path": "evidence/commands/CMD-RC2-0004-video-player.txt",
      "symbol": "",
      "lines": "n/a",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "85acfd2e79dd47df07d214334642196301332f72d792b52068cdfd8898755409",
      "excerptFile": "evidence/commands/CMD-RC2-0004-video-player.txt",
      "proves": "exit=1 داخل المسارين",
      "doesNotProve": "لا يشمل تطبيقات ويب ثابتة أو أصولًا ثنائية",
      "runtime": "SOURCE_ONLY",
      "limitations": "نمط بحث محدد"
    },
    {
      "id": "EVD-0025",
      "claim": "الإدارة تُفوَّض بمفتاح API مشترك",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/common/guards/admin-api-key.guard.ts",
      "symbol": "",
      "lines": "10-26",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "4d644f569c187ab61dc8f954934ed55b8078b1356630ded248fd83aab718d4bb",
      "excerptFile": "evidence/source/EVD-0025.txt",
      "proves": "فرق الصلاحية عن شريك واحد",
      "doesNotProve": "لا يثبت تدوير المفتاح أو تخزينه",
      "runtime": "SOURCE_ONLY",
      "limitations": "SOURCE_ONLY"
    },
    {
      "id": "EVD-0026",
      "claim": "اختبار وحدة لعزل تحديث المنتج بين شريكين",
      "claimType": "fact",
      "repo": "mira",
      "path": "mira-api/src/partners-portal/partners-portal.service.spec.ts",
      "symbol": "",
      "lines": "105-121",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "6087e75e8c3817dd934c10c36456a23f7fdcb08b0fbfe5e18c1742e1838b957a",
      "excerptFile": "evidence/source/EVD-0026.txt",
      "proves": "العزل مقصود في الاختبار وعلى mock",
      "doesNotProve": "ليس اختبار قاعدة بيانات حية ولا إنتاجًا",
      "runtime": "SOURCE_ONLY",
      "limitations": "UNIT_MOCK"
    },
    {
      "id": "EVD-0027",
      "claim": "ثماني تجارب سلبية على نسخة مؤقتة أعطت FAIL وخروجًا غير صفري، والنسخة السليمة PASS",
      "claimType": "search",
      "repo": "mira",
      "path": "evidence/tests/negative_validation.txt",
      "symbol": "",
      "lines": "n/a",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "fileSha256": "eaf5ec93b83339a925bf7ccd1817f6628d2cf48956808281063d2d328f272d4a",
      "excerptFile": "evidence/tests/negative_validation.txt",
      "proves": "المدقق يرفض الانحراف والتبعية الناقصة وحذف الدليل وتكرار المعرف والحقل الفارغ والحالة الممنوعة وقبولًا عامًا ومرجعًا من نوع خاطئ",
      "doesNotProve": "لا يثبت صحة المنتج ولا مراجعة موضوعية",
      "runtime": "TOOLING",
      "limitations": "التجارب على نسخة مؤقتة. الأدلة الأصلية لم تُحذف."
    },
    {
      "id": "EVD-0028",
      "claim": "Discovery feed uses DiscoveryApi not VenueApi",
      "claimType": "handoff",
      "repo": "mastermax-handoff",
      "path": "evidence/source/EVD-0028.txt",
      "symbol": "PlacesHttpDiscoveryRepository",
      "lines": "",
      "commitSha": "3ae70f296d7a42e096f55650ea45b9845616c474",
      "excerptFile": "evidence/source/EVD-0028.txt",
      "proves": "مسار الخلاصة في الحزمة موثق إلى DiscoveryApi وConsumerController",
      "doesNotProve": "لا يثبت تشغيل الإنتاج ولا أن كل ملفات المشروع الأصلي جُمعت",
      "runtime": "SOURCE_ONLY",
      "limitations": "البصمة تثبت اتساق الحزمة. اكتمال النطاق يعتمد على خريطة الاعتماديات."
    },
    {
      "id": "EVD-0029",
      "claim": "Views counter is a new MIRA requirement",
      "claimType": "handoff",
      "repo": "mira-study",
      "path": "evidence/source/EVD-0029.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "excerptFile": "evidence/source/EVD-0029.txt",
      "proves": "المشاهدات موثقة كمتطلب غير منفذ، والمرجع البصري غير مرفق",
      "doesNotProve": "لا يثبت غياب المشاهدات من كل ملف في دار كار خارج نطاق القراءة",
      "runtime": "SOURCE_ONLY",
      "limitations": "لا endpoint ولا قاعدة بيانات للمشاهدات في هذه الجولة"
    },
    {
      "id": "EVD-0030",
      "claim": "Discovery feed path inside unmodified RC2 0125 archive",
      "claimType": "handoff",
      "repo": "places-handoff-0125",
      "path": "evidence/source-corrections/discovery_path.txt",
      "symbol": "PlacesHttpDiscoveryRepository",
      "lines": "",
      "commitSha": "3ae70f296d7a42e096f55650ea45b9845616c474",
      "excerptFile": "evidence/source-corrections/discovery_path.txt",
      "proves": "الخلاصة في أرشيف 0125 تمر عبر DiscoveryApi وليس VenueApi",
      "doesNotProve": "لا يثبت تشغيل المنتج",
      "runtime": "SOURCE_ONLY",
      "limitations": "مقتطف توثيق. الأرشيف نفسه لم يُعدَّل."
    },
    {
      "id": "EVD-0031",
      "claim": "Redaction JSON disagrees with exclusions JSON in archive 0125",
      "claimType": "handoff",
      "repo": "places-handoff-0125",
      "path": "evidence/source-corrections/redaction_mismatch.txt",
      "symbol": "app_config.dart",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/source-corrections/redaction_mismatch.txt",
      "proves": "التعارض موثق دون كشف السر",
      "doesNotProve": "لا يستعيد المفتاح",
      "runtime": "SOURCE_ONLY",
      "limitations": "تصحيح لاحق داخل الموقع فقط"
    },
    {
      "id": "EVD-0032",
      "claim": "Historical nine-file hashes from archive 0059",
      "claimType": "handoff",
      "repo": "places-handoff-0059",
      "path": "evidence/historical/rc2-0059/README.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/historical/rc2-0059/README.txt",
      "proves": "النسخ التاريخية موجودة ومرتبطة بأرشيف 0059",
      "doesNotProve": "لا يثبت ثبات المستودع كاملًا",
      "runtime": "SOURCE_ONLY",
      "limitations": "تسعة ملفات فقط"
    },
    {
      "id": "EVD-0033",
      "claim": "RC3 browser capture metadata",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/rc3_browser.json",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/rc3_browser.json",
      "proves": "لقطات 390×844 و768×1024 و1280×900 مسجلة بأبعادها الفعلية",
      "doesNotProve": "لا يثبت جاهزية المنتج",
      "runtime": "SOURCE_ONLY",
      "limitations": "الأبعاد مقاسة من ملفات PNG. التصورات الثلاثة ما زالت NEEDS_ASSET."
    },
    {
      "id": "EVD-0034",
      "claim": "Discover test activation status",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/discover_activation_status.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/discover_activation_status.txt",
      "proves": "نتائج اختبار العلم ومسبار خادم ميرا",
      "doesNotProve": "لا يثبت تجربة جهاز إذا لم يُسجَّل الجهاز في الملف نفسه",
      "runtime": "SOURCE_ONLY",
      "limitations": "بذرة الخادم ليست متاجرًا حقيقية"
    },
    {
      "id": "EVD-0035",
      "claim": "RC3 screenshots repeat every 445 and 527 pixels",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/rc3_screenshot_tiling.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/rc3_screenshot_tiling.txt",
      "proves": "تكرار البكسل في ملفات RC3 ومصدره أداة الالتقاط لا تكرار عقد DOM",
      "doesNotProve": "لا يثبت سلامة اللقطات البديلة قبل قياسها",
      "runtime": "SOURCE_ONLY",
      "limitations": "تُستكمل بلقطات جديدة بعد القياس"
    },
    {
      "id": "EVD-0036",
      "claim": "Phase 1 presentation widget tests",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/phase1_flutter_test.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/phase1_flutter_test.txt",
      "proves": "نجاح اختبارات اكتشفي وشاشة العرض على آلة الاختبار، مع رمز الخروج في الملف",
      "doesNotProve": "لا يثبت تشغيل video_player على جهاز أو محاكي",
      "runtime": "WIDGET_TEST",
      "limitations": "منفذ الفيديو في الاختبار بديل. العلم الافتراضي ما زال false في التشغيل بلا dart-define."
    },
    {
      "id": "EVD-0037",
      "claim": "Per-request provenance and explicit demo mark",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/phase1_flutter_test.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/phase1_flutter_test.txt",
      "proves": "اختبار التفصيلة المحلية بعد قائمة الخادم واختبار العلم الصريح",
      "doesNotProve": "لا يغيّر بذرة الخادم المنشورة",
      "runtime": "WIDGET_TEST",
      "limitations": "الخادم بلا demoContent يبقى unmarked"
    },
    {
      "id": "EVD-0038",
      "claim": "Reference site screenshots after the clip fix",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/phase1_screenshots.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/phase1_screenshots.txt",
      "proves": "أبعاد اللقطات وقياس الحافة بعد تعديل CSS",
      "doesNotProve": "لا يثبت شاشة العرض داخل التطبيق",
      "runtime": "SOURCE_ONLY",
      "limitations": "لقطات Chrome headless لصفحة الهبوط لا للتمرير إلى القسم"
    },
    {
      "id": "EVD-0039",
      "claim": "No Places files were copied for phase 1",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/phase1_places_independence.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/phase1_places_independence.txt",
      "proves": "لا استيراد تشغيلي من الأماكن أو دار كار داخل مجلد السوق",
      "doesNotProve": "لا يفحص مستودعات خارج ميرا",
      "runtime": "SOURCE_ONLY",
      "limitations": "الفحص نصي على مجلد marketplace وpubspec"
    },
    {
      "id": "EVD-0040",
      "claim": "RC2 widget tests for playback ownership and video failure",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/rc2_widget_test.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/rc2_widget_test.txt",
      "proves": "نجاح اختبارات الودجت لتصحيحات الإيقاف والفشل والترتيب المتأخر، مع وبدون علم الاختبار في اختبار التفعيل",
      "doesNotProve": "لا يثبت video_player على جهاز أو محاكي",
      "runtime": "WIDGET_TEST",
      "limitations": "المنفذ في اختبار العرض بديل ذو بوابات تأخير. العلم الافتراضي بقي false في الأمر الأول."
    },
    {
      "id": "EVD-0041",
      "claim": "RC2 real player attempt on simulator and iPhone",
      "claimType": "handoff",
      "repo": "reference-site",
      "path": "evidence/tests/rc2_device_run.txt",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/rc2_device_run.txt",
      "proves": "أن البناء على الجهاز بدأ وأن الاتصال انقطع قبل إثبات التشغيل، وأن بناء المحاكي فشل بالربط",
      "doesNotProve": "لا يثبت تشغيل الفيديو ولا السحب ولا الإيقاف على المشغّل الحقيقي",
      "runtime": "DEVICE",
      "limitations": "لا لقطات لشاشة العرض. التطبيق لم يبقَ في المقدمة."
    },
    {
      "id": "EVD-0042",
      "claim": "RC3 AssetVideoPort unit coverage",
      "claimType": "fact",
      "repo": "mira",
      "path": "test/features/marketplace/asset_video_port_test.dart",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/rc3_asset_video_port.txt",
      "proves": "سلامة منطق الإلغاء والتنظيف على AssetVideoPort وليس بديل DelayedVideoPort",
      "doesNotProve": "لا يثبت video_player على جهاز",
      "runtime": "UNIT",
      "limitations": "مشغّل ControllableVideoController حقن مصنع"
    },
    {
      "id": "EVD-0043",
      "claim": "RC3 playback integration test corrections",
      "claimType": "fact",
      "repo": "mira",
      "path": "integration_test/discover_playback_rc2_test.dart",
      "symbol": "",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/tests/rc3_playback_integration_note.txt",
      "proves": "منطق الاختبار المصحح وRTL والتمييز بين محاكاة lifecycle والجهاز",
      "doesNotProve": "لا يثبت تشغيل clip حقيقي حتى ينجح rc3_device_run",
      "runtime": "INTEGRATION",
      "limitations": "يعتمد على VM Service على iPhone"
    },
    {
      "id": "EVD-0044",
      "claim": "RC3 empty presentation exit",
      "claimType": "fact",
      "repo": "mira",
      "path": "lib/features/marketplace/presentation/screens/discover_presentation_screen.dart",
      "symbol": "_exitPresentation",
      "lines": "",
      "commitSha": "",
      "excerptFile": "evidence/source/EVD-0044.txt",
      "proves": "زر إغلاق يعيد المستخدم من حالة لا توجد عروض",
      "doesNotProve": "لا يثبت مسار اكتشفي الكامل من التطبيق الحي",
      "runtime": "WIDGET",
      "limitations": "اختبار MaterialApp بمسارين فقط"
    }
  ],
  "changelog": [
    {
      "version": "1.0.0-GATE00-study-draft",
      "date": "2026-09-23T03:20:00+03:00",
      "changesAr": [
        "إنشاء GATE-00",
        "جرد القدرات",
        "موقع مرجعي"
      ],
      "baselineCommit": "15fe65c40d3dedb9afdd95619f2945bd84cb616a"
    },
    {
      "version": "RC2 — استكمال الدراسة بعد المراجعة",
      "date": "2026-09-23T03:43:29+03:00",
      "changesAr": [
        "تصحيح أحكام التفعيل والغياب والإيقاف",
        "أدلة تنفيذ الشركاء والإدارة",
        "سجل REV ومعايير قبول وخطة بوابات",
        "عقود مقترحة ومصادر تنظيمية بتاريخ اطلاع",
        "نقل النص الموضوعي إلى JSON"
      ],
      "baselineCommit": "15fe65c40d3dedb9afdd95619f2945bd84cb616a",
      "previousVersion": "1.0.0-GATE00-study-draft"
    },
    {
      "version": "RC2 — خطة الأماكن بعد مراجعة التسليم",
      "date": "2026-09-24T01:10:00+03:00",
      "changesAr": [
        "إضافة حزمة مصدر RC2 بالاسم والبصمة دون استبدال حزمة 0030",
        "تصحيح مسار الاكتشاف وتسجيل المشاهدات والربط الخارجي كمتطلبات غير منفذة",
        "أقسام 22 إلى 35 وخطة GATE-06 إلى GATE-09 دون إعادة ترقيم GATE-00 إلى GATE-05",
        "المرجع البصري ما زال مطلوبًا ولم يُولَّد بديل"
      ],
      "baselineCommit": "15fe65c40d3dedb9afdd95619f2945bd84cb616a"
    },
    {
      "version": "RC3 — تصحيح الموقع بعد المراجعة",
      "date": "2026-09-24T02:20:00+03:00",
      "changesAr": [
        "فصل فحص الحزمة عن فحص حداثة الأدلة",
        "تصحيح سجل التوثيق لخلاصة الأماكن والتنقيح دون تعديل أرشيف 0125",
        "نسخ أدلة البصمة التاريخية من أرشيف 0059",
        "تسجيل NEEDS_ASSET للتصورات الثلاثة"
      ],
      "baselineCommit": "15fe65c40d3dedb9afdd95619f2945bd84cb616a"
    },
    {
      "version": "RC1 — تفعيل اختبار اكتشفي وخطة الدمج",
      "date": "2026-09-24T03:10:00+03:00",
      "changesAr": [
        "تسجيل توجيه المالك للإغلاق من أجل تجربة العرض، والتصريح بنسخة الاختبار",
        "خطة دمج تمنع تكرار وظائف ميرا واستقلالها عن الأماكن",
        "تشخيص تكرار لقطات RC3"
      ],
      "baselineCommit": "15fe65c40d3dedb9afdd95619f2945bd84cb616a"
    },
    {
      "version": "RC1 — مراحل اكتشفي وشاشة العرض",
      "date": "2026-09-24T05:10:00+03:00",
      "changesAr": [
        "تسجيل المراحل الخمس في الموقع دون تنفيذ المراحل 2 إلى 5",
        "إغلاق مصدر البيانات والعلامة التجريبية وقص الجوال بانتظار المراجعة",
        "شاشة العرض المرئي داخل اكتشفي مع إبقاء المرحلة قيد التنفيذ لنقص إثبات الفيديو على جهاز"
      ],
      "baselineCommit": "15fe65c40d3dedb9afdd95619f2945bd84cb616a"
    },
    {
      "version": "RC2 — تصحيحات المرحلة الأولى لاكتشفي",
      "date": "2026-09-24T06:11:28+03:00",
      "changesAr": [
        "تسجيل نتيجة مراجعة RC1 دون اعتماد المرحلة الأولى",
        "ملاحظات P1-RC2-01 إلى P1-RC2-05 على بطاقة المرحلة الأولى فقط",
        "روابط تسليم RC1 وRC2 دون إدراج بصمة الحزمة الجديدة داخلها"
      ],
      "baselineCommit": "15fe65c40d3dedb9afdd95619f2945bd84cb616a"
    }
  ],
  "categories": [
    {
      "id": "CAT-FACE",
      "nameAr": "الوجه",
      "filters": [
        "النوع",
        "نوع البشرة المعلن",
        "الحجم",
        "السعر"
      ],
      "subcategoriesAr": [
        "يُقترح تعداد فرعي يديره المتجر ضمن الفئة"
      ],
      "attributesOnCreateAr": [
        "النوع",
        "نوع البشرة المعلن",
        "الحجم",
        "السعر"
      ],
      "quickFilters": [
        "النوع",
        "نوع البشرة المعلن",
        "الحجم"
      ],
      "advancedFilters": [
        "النوع",
        "نوع البشرة المعلن",
        "الحجم",
        "السعر"
      ],
      "allowedValuesSourceAr": "قاموس يديره الشريك وتراجعه الإدارة. القيم الناقصة تُرفض ولا تُخترع في الواجهة.",
      "unitsAr": "مل",
      "logicAr": "OR داخل النوع، AND مع الحجم والسعر",
      "indexAr": "فهرس مقترح على partnerId والحالة وخصائص المتغير المستخدمة في الفلتر. غير منفذ.",
      "sortAr": "السعر أو الأحدث. الترتيب على نتيجة الاستعلام لا على صفحة واحدة.",
      "paginationAr": "حد صفحة ثابت مع عدد كلي.",
      "countAr": "عدد المنتجات المطابقة منفصل عن عدد الأصول المنشورة المرتبطة.",
      "stateAr": "حفظ الاستعلام عند فتح التفاصيل والعودة.",
      "emptyAr": "حالة لا نتائج مع إبقاء الفلاتر ظاهرة.",
      "note": "لا ادعاء طبي من الوسوم",
      "unimplemented": true
    },
    {
      "id": "CAT-BODY",
      "nameAr": "الجسم",
      "filters": [
        "المنطقة",
        "القوام",
        "الحجم",
        "السعر"
      ],
      "subcategoriesAr": [
        "يُقترح تعداد فرعي يديره المتجر ضمن الفئة"
      ],
      "attributesOnCreateAr": [
        "المنطقة",
        "القوام",
        "الحجم",
        "السعر"
      ],
      "quickFilters": [
        "المنطقة",
        "القوام",
        "الحجم"
      ],
      "advancedFilters": [
        "المنطقة",
        "القوام",
        "الحجم",
        "السعر"
      ],
      "allowedValuesSourceAr": "قاموس يديره الشريك وتراجعه الإدارة. القيم الناقصة تُرفض ولا تُخترع في الواجهة.",
      "unitsAr": "مل",
      "logicAr": "AND بين المنطقة والحجم",
      "indexAr": "فهرس مقترح على partnerId والحالة وخصائص المتغير المستخدمة في الفلتر. غير منفذ.",
      "sortAr": "السعر أو الأحدث. الترتيب على نتيجة الاستعلام لا على صفحة واحدة.",
      "paginationAr": "حد صفحة ثابت مع عدد كلي.",
      "countAr": "عدد المنتجات المطابقة منفصل عن عدد الأصول المنشورة المرتبطة.",
      "stateAr": "حفظ الاستعلام عند فتح التفاصيل والعودة.",
      "emptyAr": "حالة لا نتائج مع إبقاء الفلاتر ظاهرة.",
      "note": "المنطقة تعداد",
      "unimplemented": true
    },
    {
      "id": "CAT-HAIR",
      "nameAr": "الشعر",
      "filters": [
        "نوع الشعر المعلن",
        "الهدف",
        "الحجم"
      ],
      "subcategoriesAr": [
        "يُقترح تعداد فرعي يديره المتجر ضمن الفئة"
      ],
      "attributesOnCreateAr": [
        "نوع الشعر المعلن",
        "الهدف",
        "الحجم"
      ],
      "quickFilters": [
        "نوع الشعر المعلن",
        "الهدف",
        "الحجم"
      ],
      "advancedFilters": [
        "نوع الشعر المعلن",
        "الهدف",
        "الحجم"
      ],
      "allowedValuesSourceAr": "قاموس يديره الشريك وتراجعه الإدارة. القيم الناقصة تُرفض ولا تُخترع في الواجهة.",
      "unitsAr": "مل",
      "logicAr": "AND",
      "indexAr": "فهرس مقترح على partnerId والحالة وخصائص المتغير المستخدمة في الفلتر. غير منفذ.",
      "sortAr": "السعر أو الأحدث. الترتيب على نتيجة الاستعلام لا على صفحة واحدة.",
      "paginationAr": "حد صفحة ثابت مع عدد كلي.",
      "countAr": "عدد المنتجات المطابقة منفصل عن عدد الأصول المنشورة المرتبطة.",
      "stateAr": "حفظ الاستعلام عند فتح التفاصيل والعودة.",
      "emptyAr": "حالة لا نتائج مع إبقاء الفلاتر ظاهرة.",
      "note": "النوع تسويقي لا تشخيص",
      "unimplemented": true
    },
    {
      "id": "CAT-APPAREL",
      "nameAr": "الملابس",
      "filters": [
        "نوع القطعة",
        "اللون",
        "المقاس",
        "التوفر"
      ],
      "subcategoriesAr": [
        "يُقترح تعداد فرعي يديره المتجر ضمن الفئة"
      ],
      "attributesOnCreateAr": [
        "نوع القطعة",
        "اللون",
        "المقاس",
        "التوفر"
      ],
      "quickFilters": [
        "نوع القطعة",
        "اللون",
        "المقاس"
      ],
      "advancedFilters": [
        "نوع القطعة",
        "اللون",
        "المقاس",
        "التوفر"
      ],
      "allowedValuesSourceAr": "قاموس يديره الشريك وتراجعه الإدارة. القيم الناقصة تُرفض ولا تُخترع في الواجهة.",
      "unitsAr": "مقاس حرفي",
      "logicAr": "AND على متغير واحد للون والمقاس والتوفر",
      "indexAr": "فهرس مقترح على partnerId والحالة وخصائص المتغير المستخدمة في الفلتر. غير منفذ.",
      "sortAr": "السعر أو الأحدث. الترتيب على نتيجة الاستعلام لا على صفحة واحدة.",
      "paginationAr": "حد صفحة ثابت مع عدد كلي.",
      "countAr": "عدد المنتجات المطابقة منفصل عن عدد الأصول المنشورة المرتبطة.",
      "stateAr": "حفظ الاستعلام عند فتح التفاصيل والعودة.",
      "emptyAr": "حالة لا نتائج مع إبقاء الفلاتر ظاهرة.",
      "note": "مثال الفستان هنا",
      "unimplemented": true
    },
    {
      "id": "CAT-ACCESSORY",
      "nameAr": "الإكسسوارات",
      "filters": [
        "النوع",
        "اللون",
        "المادة"
      ],
      "subcategoriesAr": [
        "يُقترح تعداد فرعي يديره المتجر ضمن الفئة"
      ],
      "attributesOnCreateAr": [
        "النوع",
        "اللون",
        "المادة"
      ],
      "quickFilters": [
        "النوع",
        "اللون",
        "المادة"
      ],
      "advancedFilters": [
        "النوع",
        "اللون",
        "المادة"
      ],
      "allowedValuesSourceAr": "قاموس يديره الشريك وتراجعه الإدارة. القيم الناقصة تُرفض ولا تُخترع في الواجهة.",
      "unitsAr": "بدون وحدة مقاس ملابس",
      "logicAr": "AND",
      "indexAr": "فهرس مقترح على partnerId والحالة وخصائص المتغير المستخدمة في الفلتر. غير منفذ.",
      "sortAr": "السعر أو الأحدث. الترتيب على نتيجة الاستعلام لا على صفحة واحدة.",
      "paginationAr": "حد صفحة ثابت مع عدد كلي.",
      "countAr": "عدد المنتجات المطابقة منفصل عن عدد الأصول المنشورة المرتبطة.",
      "stateAr": "حفظ الاستعلام عند فتح التفاصيل والعودة.",
      "emptyAr": "حالة لا نتائج مع إبقاء الفلاتر ظاهرة.",
      "note": "المادة تعداد",
      "unimplemented": true
    },
    {
      "id": "CAT-SALON",
      "nameAr": "المشاغل",
      "filters": [
        "الخدمة",
        "المدينة",
        "مدة بالدقائق"
      ],
      "subcategoriesAr": [
        "يُقترح تعداد فرعي يديره المتجر ضمن الفئة"
      ],
      "attributesOnCreateAr": [
        "الخدمة",
        "المدينة",
        "مدة بالدقائق"
      ],
      "quickFilters": [
        "الخدمة",
        "المدينة",
        "مدة بالدقائق"
      ],
      "advancedFilters": [
        "الخدمة",
        "المدينة",
        "مدة بالدقائق"
      ],
      "allowedValuesSourceAr": "قاموس يديره الشريك وتراجعه الإدارة. القيم الناقصة تُرفض ولا تُخترع في الواجهة.",
      "unitsAr": "دقيقة",
      "logicAr": "AND",
      "indexAr": "فهرس مقترح على partnerId والحالة وخصائص المتغير المستخدمة في الفلتر. غير منفذ.",
      "sortAr": "السعر أو الأحدث. الترتيب على نتيجة الاستعلام لا على صفحة واحدة.",
      "paginationAr": "حد صفحة ثابت مع عدد كلي.",
      "countAr": "عدد المنتجات المطابقة منفصل عن عدد الأصول المنشورة المرتبطة.",
      "stateAr": "حفظ الاستعلام عند فتح التفاصيل والعودة.",
      "emptyAr": "حالة لا نتائج مع إبقاء الفلاتر ظاهرة.",
      "note": "ليست خدمة طبية",
      "unimplemented": true
    },
    {
      "id": "CAT-CLINIC",
      "nameAr": "العيادات",
      "filters": [
        "التخصص",
        "المدينة",
        "نوع الزيارة"
      ],
      "subcategoriesAr": [
        "يُقترح تعداد فرعي يديره المتجر ضمن الفئة"
      ],
      "attributesOnCreateAr": [
        "التخصص",
        "المدينة",
        "نوع الزيارة"
      ],
      "quickFilters": [
        "التخصص",
        "المدينة",
        "نوع الزيارة"
      ],
      "advancedFilters": [
        "التخصص",
        "المدينة",
        "نوع الزيارة"
      ],
      "allowedValuesSourceAr": "قاموس يديره الشريك وتراجعه الإدارة. القيم الناقصة تُرفض ولا تُخترع في الواجهة.",
      "unitsAr": "دقيقة",
      "logicAr": "AND",
      "indexAr": "فهرس مقترح على partnerId والحالة وخصائص المتغير المستخدمة في الفلتر. غير منفذ.",
      "sortAr": "السعر أو الأحدث. الترتيب على نتيجة الاستعلام لا على صفحة واحدة.",
      "paginationAr": "حد صفحة ثابت مع عدد كلي.",
      "countAr": "عدد المنتجات المطابقة منفصل عن عدد الأصول المنشورة المرتبطة.",
      "stateAr": "حفظ الاستعلام عند فتح التفاصيل والعودة.",
      "emptyAr": "حالة لا نتائج مع إبقاء الفلاتر ظاهرة.",
      "note": "حقول إعلان صحي منفصلة",
      "unimplemented": true
    }
  ],
  "reviewFindings": [
    {
      "id": "REV-0001",
      "parentId": null,
      "titleAr": "أدلة الشركاء والإدارة لا تطابق حكم التفعيل",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "بوابة الشركاء وُصفت مفعلة ودليلها ملف مواصفات، ولوحة الإدارة بلا دليل.",
      "reqIds": [
        "REQ-0006",
        "REQ-0016"
      ],
      "severity": "high",
      "impactAr": "بوابة الشركاء وُصفت مفعلة ودليلها ملف مواصفات، ولوحة الإدارة بلا دليل.",
      "unit": "partners-admin",
      "files": [
        "partners-portal/SPEC.md",
        "admin-portal/web/js/api.js"
      ],
      "previousEvidenceAr": "EVD-0007 فقط لـ CAP-0007، وCAP-0008 بلا evidenceIds",
      "actionAr": "قراءة المتحكم والحارس وعميل الويب، وتخفيض التفعيل إلى UNKNOWN",
      "newEvidenceIds": [
        "EVD-0011",
        "EVD-0012",
        "EVD-0014",
        "EVD-0015"
      ],
      "verificationAr": "مقارنة الملفات بالمقتطفات وSHA-256",
      "remainingLimitsAr": "لا تشغيل إنتاجي. البندان الفرعيان اكتملت دراستهما بانتظار المراجعة.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0001a",
      "parentId": "REV-0001",
      "titleAr": "SPEC ليس دليل تنفيذ الشركاء",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "EVD-0007 مواصفات. التنفيذ في المتحكم والعميل.",
      "reqIds": [
        "REQ-0006"
      ],
      "severity": "high",
      "impactAr": "EVD-0007 مواصفات. التنفيذ في المتحكم والعميل.",
      "unit": "partners",
      "files": [
        "partners-portal/SPEC.md",
        "mira-api/src/partners-portal/partners-portal.controller.ts"
      ],
      "previousEvidenceAr": "EVD-0007",
      "actionAr": "أُبقي EVD-0007 كوثيقة وأُضيفت أدلة التنفيذ",
      "newEvidenceIds": [
        "EVD-0007",
        "EVD-0011",
        "EVD-0016"
      ],
      "verificationAr": "مراجعة نوع الدليل document مقابل fact",
      "remainingLimitsAr": "التفعيل الإنتاجي UNKNOWN",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0001b",
      "parentId": "REV-0001",
      "titleAr": "لوحة الإدارة بلا دليل مرتبط",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "CAP-0008 كانت بلا evidenceIds.",
      "reqIds": [
        "REQ-0016"
      ],
      "severity": "high",
      "impactAr": "CAP-0008 كانت بلا evidenceIds.",
      "unit": "admin",
      "files": [
        "mira-api/src/admin/admin.controller.ts",
        "admin-portal/web/js/api.js"
      ],
      "previousEvidenceAr": "مصفوفة فارغة",
      "actionAr": "رُبطت EVD-0014 وEVD-0015 وEVD-0025",
      "newEvidenceIds": [
        "EVD-0014",
        "EVD-0015",
        "EVD-0025"
      ],
      "verificationAr": "وجود الملفات والمقتطفات",
      "remainingLimitsAr": "لا يثبت ضبط المفتاح في الإنتاج",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0002",
      "parentId": null,
      "titleAr": "أحكام الوجود أوسع من الأدلة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "قدرات بلا أدلة، وملخص بحث، ومقتطف مخطط يُستخدم كنفي شامل.",
      "reqIds": [
        "REQ-0002",
        "REQ-0011"
      ],
      "severity": "high",
      "impactAr": "قدرات بلا أدلة، وملخص بحث، ومقتطف مخطط يُستخدم كنفي شامل.",
      "unit": "study",
      "files": [
        "data/capabilities.json"
      ],
      "previousEvidenceAr": "CAP-0008 و0010 و0011 و0013 و0014 بلا أدلة أو بملخص",
      "actionAr": "تضييق نطاق الغياب وإرفاق أوامر الخروج",
      "newEvidenceIds": [
        "EVD-0018",
        "EVD-0019",
        "EVD-0023"
      ],
      "verificationAr": "مراجعة سجل الأمر وexit code",
      "remainingLimitsAr": "البحث لا يغطي أسماءً لم تُذكر ولا مستودعات خارج ميرا",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0002a",
      "parentId": "REV-0002",
      "titleAr": "قدرات بلا أدلة مرتبطة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "CAP-0008 وCAP-0010 وCAP-0011 وCAP-0013 وCAP-0014 كانت بلا أدلة.",
      "reqIds": [
        "REQ-0013"
      ],
      "severity": "high",
      "impactAr": "CAP-0008 وCAP-0010 وCAP-0011 وCAP-0013 وCAP-0014 كانت بلا أدلة.",
      "unit": "capabilities",
      "files": [
        "data/capabilities.json"
      ],
      "previousEvidenceAr": "evidenceIds فارغة",
      "actionAr": "رُبط كل حكم بدليل أو صُنّف البحث بنطاقه",
      "newEvidenceIds": [
        "EVD-0014",
        "EVD-0017",
        "EVD-0020",
        "EVD-0023"
      ],
      "verificationAr": "كل قدرة حقيقة لها دليل",
      "remainingLimitsAr": "SOURCE_ONLY",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0002b",
      "parentId": "REV-0002",
      "titleAr": "سجل Order/Cart كان ملخصًا",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "CMD-0001 ليس مخرج أمر.",
      "reqIds": [
        "REQ-0011"
      ],
      "severity": "high",
      "impactAr": "CMD-0001 ليس مخرج أمر.",
      "unit": "evidence",
      "files": [
        "evidence/commands/CMD-0001-search-order-cart.txt"
      ],
      "previousEvidenceAr": "EVD-0010 ملخص",
      "actionAr": "أُضيف CMD-RC2-0001 مع exit_code=1",
      "newEvidenceIds": [
        "EVD-0018",
        "EVD-0010"
      ],
      "verificationAr": "قراءة ملف الأمر",
      "remainingLimitsAr": "exit=1 يعني لا تطابق للنمط لا غيابًا كونيًا",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "search"
    },
    {
      "id": "REV-0002c",
      "parentId": "REV-0002",
      "titleAr": "مقتطف المخطط لا ينفي المشروع",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "EVD-0005 نطاقه أسطر المخطط المعروضة.",
      "reqIds": [
        "REQ-0002"
      ],
      "severity": "medium",
      "impactAr": "EVD-0005 نطاقه أسطر المخطط المعروضة.",
      "unit": "schema",
      "files": [
        "mira-api/prisma/schema.prisma"
      ],
      "previousEvidenceAr": "EVD-0005",
      "actionAr": "أُضيف بحث النماذج EVD-0019 ونص doesNotProve",
      "newEvidenceIds": [
        "EVD-0005",
        "EVD-0019"
      ],
      "verificationAr": "مقارنة حدود الدليل",
      "remainingLimitsAr": "جداول بأسماء أخرى خارج النمط لن تُكتشف",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "search"
    },
    {
      "id": "REV-0003",
      "parentId": null,
      "titleAr": "تقرير الإيقاف يخلط المنفذ والموقوف والناقص",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "عبارة الانطلاق قريبًا ليست سببًا تشغيليًا، والشراء الداخلي لم يكن خدمة متوقفة.",
      "reqIds": [
        "REQ-0019"
      ],
      "severity": "high",
      "impactAr": "عبارة الانطلاق قريبًا ليست سببًا تشغيليًا، والشراء الداخلي لم يكن خدمة متوقفة.",
      "unit": "paused",
      "files": [
        "data/paused-services.json"
      ],
      "previousEvidenceAr": "PAUSE-0001 إلى 0003",
      "actionAr": "فُصلت طبقات الإخفاء والبوابة وAPI واكتمال المنطق",
      "newEvidenceIds": [
        "EVD-0001",
        "EVD-0003",
        "EVD-0004",
        "EVD-0018"
      ],
      "verificationAr": "جدول الأحكام المتغيرة",
      "remainingLimitsAr": "وصول API الإنتاج بقي UNKNOWN",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0003a",
      "parentId": "REV-0003",
      "titleAr": "طبقات Discover مختلطة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "حُكم بوصول API دون دليل تشغيل.",
      "reqIds": [
        "REQ-0006"
      ],
      "severity": "high",
      "impactAr": "حُكم بوصول API دون دليل تشغيل.",
      "unit": "marketplace",
      "files": [
        "lib/core/config/mira_features.dart",
        "lib/main.dart"
      ],
      "previousEvidenceAr": "EVD-0001 وEVD-0002",
      "actionAr": "uiHidden موثق والباقي UNKNOWN",
      "newEvidenceIds": [
        "EVD-0001",
        "EVD-0002",
        "EVD-0006"
      ],
      "verificationAr": "لا طلب شبكة إنتاجي في هذه المرحلة",
      "remainingLimitsAr": "لم يُفحص البناء المنشور",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0003b",
      "parentId": "REV-0003",
      "titleAr": "عبارة الانطلاق قريبًا ليست سبب إيقاف",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "النص واجهة. السبب التاريخي غير موثق.",
      "reqIds": [],
      "severity": "medium",
      "impactAr": "النص واجهة. السبب التاريخي غير موثق.",
      "unit": "marketplace",
      "files": [
        "lib/main.dart"
      ],
      "previousEvidenceAr": "حقل documentedReason السابق",
      "actionAr": "صُحح reasonClass",
      "newEvidenceIds": [
        "EVD-0002"
      ],
      "verificationAr": "قراءة النص في المقتطف",
      "remainingLimitsAr": "لا وثيقة تشغيل إضافية داخل المستودع",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0003c",
      "parentId": "REV-0003",
      "titleAr": "الشراء الداخلي ليس خدمة متوقفة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "التصميم رابط خارجي ولم يُبنَ طلب داخلي ثم يُوقف.",
      "reqIds": [
        "REQ-0019"
      ],
      "severity": "high",
      "impactAr": "التصميم رابط خارجي ولم يُبنَ طلب داخلي ثم يُوقف.",
      "unit": "orders",
      "files": [
        "product_detail_screen.dart",
        "SPEC.md"
      ],
      "previousEvidenceAr": "PAUSE-0003",
      "actionAr": "التصنيف NEVER_BUILT",
      "newEvidenceIds": [
        "EVD-0004",
        "EVD-0007",
        "EVD-0018"
      ],
      "verificationAr": "مقارنة التصنيف بالأدلة",
      "remainingLimitsAr": "قرار DEC-0001 ما زال مفتوحًا",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0004",
      "parentId": null,
      "titleAr": "القبول والمراحل والجهد غير محددة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "معيار قبول واحد لكل المتطلبات، ومراحل بلا خروج، ومتطلبات خارج الخطة.",
      "reqIds": [
        "REQ-0003",
        "REQ-0006",
        "REQ-0009",
        "REQ-0015",
        "REQ-0016",
        "REQ-0017",
        "REQ-0018",
        "REQ-0020"
      ],
      "severity": "high",
      "impactAr": "معيار قبول واحد لكل المتطلبات، ومراحل بلا خروج، ومتطلبات خارج الخطة.",
      "unit": "roadmap",
      "files": [
        "data/requirements.json",
        "data/roadmap.json"
      ],
      "previousEvidenceAr": "acceptanceAr الموحد",
      "actionAr": "معايير لكل متطلب وخطة تغطي الكل",
      "newEvidenceIds": [],
      "verificationAr": "أداة التحقق ترفض المعيار العام",
      "remainingLimitsAr": "التقديرات نطاقات بافتراضات لا عروض أسعار",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0004a",
      "parentId": "REV-0004",
      "titleAr": "معيار القبول العام",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "النص كان: يُثبت لاحقًا ببوابة قبول.",
      "reqIds": [
        "REQ-0001"
      ],
      "severity": "high",
      "impactAr": "النص كان: يُثبت لاحقًا ببوابة قبول.",
      "unit": "requirements",
      "files": [
        "data/requirements.json"
      ],
      "previousEvidenceAr": "حقل acceptanceAr",
      "actionAr": "استُبدل بمعطى وإجراء ومتوقع وفشل واختبار ودليل",
      "newEvidenceIds": [],
      "verificationAr": "validate_study يرفض العبارة العامة",
      "remainingLimitsAr": "المعايير مقترحة للدراسة وليست اختبارات منفذة على المنتج",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0004b",
      "parentId": "REV-0004",
      "titleAr": "شروط خروج المراحل",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "GATE-01 إلى GATE-05 بلا خروج محدد.",
      "reqIds": [],
      "severity": "high",
      "impactAr": "GATE-01 إلى GATE-05 بلا خروج محدد.",
      "unit": "roadmap",
      "files": [
        "data/roadmap.json"
      ],
      "previousEvidenceAr": "exitCriteria على GATE-00 فقط",
      "actionAr": "لكل مرحلة دخول وخروج وجهد ومخاطر وتراجع",
      "newEvidenceIds": [],
      "verificationAr": "قراءة roadmap.json",
      "remainingLimitsAr": "الجهد تقدير دراسة",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0004c",
      "parentId": "REV-0004",
      "titleAr": "متطلبات خارج المراحل المستقبلية",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "REQ-0003 و0006 و0009 و0015 و0016 و0017 و0018 و0020 لم تكن في GATE-01..05.",
      "reqIds": [
        "REQ-0003",
        "REQ-0006",
        "REQ-0009",
        "REQ-0015",
        "REQ-0016",
        "REQ-0017",
        "REQ-0018",
        "REQ-0020"
      ],
      "severity": "high",
      "impactAr": "REQ-0003 و0006 و0009 و0015 و0016 و0017 و0018 و0020 لم تكن في GATE-01..05.",
      "unit": "roadmap",
      "files": [
        "data/roadmap.json",
        "data/scope-decisions.json"
      ],
      "previousEvidenceAr": "GATE-00 كان يجمع كل المتطلبات",
      "actionAr": "وُزعت على البوابات وREQ-0020 قرار نطاق",
      "newEvidenceIds": [],
      "verificationAr": "مصفوفة التغطية",
      "remainingLimitsAr": "لم يبدأ التنفيذ",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0005",
      "parentId": null,
      "titleAr": "الفلاتر والوسائط والتنظيم مختصرة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "بلا عقود أو فهرسة أو تكلفة أو مصادر رسمية.",
      "reqIds": [
        "REQ-0013",
        "REQ-0004"
      ],
      "severity": "high",
      "impactAr": "بلا عقود أو فهرسة أو تكلفة أو مصادر رسمية.",
      "unit": "product-study",
      "files": [
        "data/categories.json",
        "data/contracts.json"
      ],
      "previousEvidenceAr": "قوائم أسماء فلاتر",
      "actionAr": "عقود مقترحة موسومة غير منفذة وبحث مصادر",
      "newEvidenceIds": [],
      "verificationAr": "المصادر مؤرخة بتاريخ الاطلاع",
      "remainingLimitsAr": "الأسعار غير متحققة والدراسة ليست اعتمادًا قانونيًا",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0005a",
      "parentId": "REV-0005",
      "titleAr": "عقود وفلاتر قابلة للمراجعة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "المثال المطلوب: فستان أزرق مقاس M متوفر يطابق متغيرًا واحدًا.",
      "reqIds": [
        "REQ-0013",
        "REQ-0014"
      ],
      "severity": "high",
      "impactAr": "المثال المطلوب: فستان أزرق مقاس M متوفر يطابق متغيرًا واحدًا.",
      "unit": "filters",
      "files": [
        "data/contracts.json",
        "data/categories.json"
      ],
      "previousEvidenceAr": "أسماء فلاتر فقط",
      "actionAr": "عقود وحالات AND ومثال العدّ",
      "newEvidenceIds": [],
      "verificationAr": "العرض في القسم 8 ووسم مقترح غير منفذ",
      "remainingLimitsAr": "غير مبني في المنتج",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "proposal"
    },
    {
      "id": "REV-0005b",
      "parentId": "REV-0005",
      "titleAr": "دورة الوسائط والتكلفة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "لا دورة حياة ولا معادلة تكلفة.",
      "reqIds": [
        "REQ-0004",
        "REQ-0005"
      ],
      "severity": "medium",
      "impactAr": "لا دورة حياة ولا معادلة تكلفة.",
      "unit": "media",
      "files": [
        "data/media-lifecycle.json",
        "data/costs.json"
      ],
      "previousEvidenceAr": "قسم مختصر",
      "actionAr": "دورة كاملة ومعادلات بلا أسعار مخترعة",
      "newEvidenceIds": [
        "EVD-0024"
      ],
      "verificationAr": "لا مشغل قائم في النطاق قبل اقتراح مزود",
      "remainingLimitsAr": "أسعار المزود غير متحقق",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0005c",
      "parentId": "REV-0005",
      "titleAr": "البحث التنظيمي الرسمي",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "لم يُنجز في النسخة السابقة.",
      "reqIds": [
        "REQ-0017"
      ],
      "severity": "high",
      "impactAr": "لم يُنجز في النسخة السابقة.",
      "unit": "regulatory",
      "files": [
        "data/regulatory.json"
      ],
      "previousEvidenceAr": "عبارة تحتاج مراجعة",
      "actionAr": "مصادر رسمية بتاريخ اطلاع وأثر تصميمي وأسئلة مختص",
      "newEvidenceIds": [],
      "verificationAr": "روابط المصادر في القسم 12",
      "remainingLimitsAr": "ليس رأيًا قانونيًا ملزمًا",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "regulatory"
    },
    {
      "id": "REV-0006",
      "parentId": null,
      "titleAr": "أداة التحقق تقبل دراسة فاسدة",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "نجحت رغم انحراف JSON واعتماد مرحلة ناقصة وحقول دليل فارغة.",
      "reqIds": [],
      "severity": "high",
      "impactAr": "نجحت رغم انحراف JSON واعتماد مرحلة ناقصة وحقول دليل فارغة.",
      "unit": "tooling",
      "files": [
        "scripts/validate_study.py"
      ],
      "previousEvidenceAr": "PASS بعدد ثابت",
      "actionAr": "فحوص بنيوية واختبارات سلبية على نسخة مؤقتة",
      "newEvidenceIds": [
        "EVD-0027"
      ],
      "verificationAr": "ثماني حالات FAIL بخروج غير صفري ثم PASS على النسخة السليمة. السجل EVD-0027.",
      "remainingLimitsAr": "التحقق بنيوي. لا يغني عن قراءة الملاحظات.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "test"
    },
    {
      "id": "REV-0007",
      "parentId": null,
      "titleAr": "مصدر الحقيقة والعرض والاختبار التفاعلي",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "نصوص الدراسة داخل app.js وأنماط مضمّنة وبلا لقطات.",
      "reqIds": [],
      "severity": "high",
      "impactAr": "نصوص الدراسة داخل app.js وأنماط مضمّنة وبلا لقطات.",
      "unit": "site",
      "files": [
        "js/app.js",
        "css/components.css"
      ],
      "previousEvidenceAr": "لا مجلد لقطات في الحزمة السابقة",
      "actionAr": "نقل المحتوى إلى JSON وفصل CSS",
      "newEvidenceIds": [],
      "verificationAr": "اختبار متصفح لاحقًا",
      "remainingLimitsAr": "لقطات المتصفح تُستكمل في هذه الجولة أو تبقى القيد ظاهرًا",
      "status": "قيد المعالجة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0007a",
      "parentId": "REV-0007",
      "titleAr": "النص الموضوعي داخل app.js",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "sectionBody كان يحمل نتائج التدقيق.",
      "reqIds": [],
      "severity": "high",
      "impactAr": "sectionBody كان يحمل نتائج التدقيق.",
      "unit": "site",
      "files": [
        "js/app.js",
        "data/section-content.json"
      ],
      "previousEvidenceAr": "سويتش النصوص",
      "actionAr": "العرض يقرأ JSON والتوكنات {{ID}}",
      "newEvidenceIds": [],
      "verificationAr": "مقارنة المولد بالملف",
      "remainingLimitsAr": "نصوص أزرار الواجهة تبقى في العرض",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0007b",
      "parentId": "REV-0007",
      "titleAr": "أنماط مضمّنة في القالب",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "style على بطاقات المقاييس.",
      "reqIds": [],
      "severity": "low",
      "impactAr": "style على بطاقات المقاييس.",
      "unit": "site",
      "files": [
        "css/layout.css"
      ],
      "previousEvidenceAr": "ثلاث خصائص style",
      "actionAr": "صنف metric-compact",
      "newEvidenceIds": [],
      "verificationAr": "بحث style= في app.js بعد التعديل",
      "remainingLimitsAr": "لا يشمل أنماط المتصفح الافتراضية",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "source"
    },
    {
      "id": "REV-0007c",
      "parentId": "REV-0007",
      "titleAr": "لقطات واختبار تفاعل المتصفح",
      "source": "مراجعة الحزمة السابقة",
      "descriptionAr": "node --check وHTTP 200 لا يثبتان التفاعل.",
      "reqIds": [],
      "severity": "high",
      "impactAr": "node --check وHTTP 200 لا يثبتان التفاعل.",
      "unit": "tests",
      "files": [
        "evidence/screenshots",
        "evidence/tests"
      ],
      "previousEvidenceAr": "لا لقطات",
      "actionAr": "اختبار عرض كمبيوتر وجوال وتابلت على النسخة المستخرجة إن أمكن",
      "newEvidenceIds": [],
      "verificationAr": "المتصفح المدمج: 22 قسمًا، RTL، فتح #REV-0001، البحث أخفى 20 قسمًا ثم أظهرها، وفلتر الحالة أظهر REV-0007 وREV-0007c. لقطة Chrome 1280 ناجحة. لقطتا 768 و390 خرجتا فارغتين وليستا دليلًا.",
      "remainingLimitsAr": "لقطات التابلت والجوال من Chrome headless بيضاء. لا تُحتسب نجاح عرض. البند يبقى قيد المعالجة.",
      "status": "قيد المعالجة",
      "previousStatus": "مفتوحة في مراجعة الحزمة 20260923_032329",
      "updatedAt": "2026-09-23T03:43:29+03:00",
      "evidenceType": "browser"
    },
    {
      "id": "REV-0008",
      "parentId": null,
      "titleAr": "ملفات مصدر ناقصة في RC1",
      "source": "مراجعة حزمة الأماكن RC1",
      "descriptionAr": "خمسة مسارات لم تكن في الحزمة السابقة.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "medium",
      "impactAr": "خمسة مسارات لم تكن في الحزمة السابقة.",
      "unit": "places-handoff",
      "files": [
        "lib/src/features/auth/models/auth_credentials.dart",
        "lib/src/core/geo/geo.dart",
        "assets/fonts/Cairo-Variable.ttf"
      ],
      "previousEvidenceAr": "حزمة 20260924_0030",
      "actionAr": "أُرفقت مع إغلاق الاستيراد اللازم وصُنفت اعتماديات المضيف.",
      "newEvidenceIds": [
        "EVD-0028"
      ],
      "verificationAr": "فحص حزمة RC2 بعد فكها",
      "remainingLimitsAr": "لم يُنسخ تطبيق دار كار كاملًا. المراجعة البشرية لم تعتمد الحزمة.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة",
      "updatedAt": "2026-09-24T01:10:00+03:00",
      "evidenceType": "handoff"
    },
    {
      "id": "REV-0009",
      "parentId": null,
      "titleAr": "مدقق الحزمة كان يقبل تلفًا",
      "source": "مراجعة حزمة الأماكن RC1",
      "descriptionAr": "تغيير README أو إتلاف MANIFEST أو حذف سجل كان يمكن أن يمر.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "medium",
      "impactAr": "تغيير README أو إتلاف MANIFEST أو حذف سجل كان يمكن أن يمر.",
      "unit": "places-handoff",
      "files": [
        "scripts/validate_package.py"
      ],
      "previousEvidenceAr": "حزمة 20260924_0030",
      "actionAr": "أُعيدت الفحوص السلبية على نسخ مؤقتة ورُفضت.",
      "newEvidenceIds": [
        "EVD-0028"
      ],
      "verificationAr": "فحص حزمة RC2 بعد فكها",
      "remainingLimitsAr": "البصمة تثبت الاتساق لا اكتمال جمع كل ملفات الأصل.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة",
      "updatedAt": "2026-09-24T01:10:00+03:00",
      "evidenceType": "handoff"
    },
    {
      "id": "REV-0010",
      "parentId": null,
      "titleAr": "مسار الاكتشاف نُسب إلى VenueApi",
      "source": "مراجعة حزمة الأماكن RC1",
      "descriptionAr": "الخلاصة في الكود عبر DiscoveryApi.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "medium",
      "impactAr": "الخلاصة في الكود عبر DiscoveryApi.",
      "unit": "places-handoff",
      "files": [
        "lib/src/features/places/core/api/places_http_discovery_repository.dart"
      ],
      "previousEvidenceAr": "حزمة 20260924_0030",
      "actionAr": "صُحح المسار في وثائق RC2 والموقع.",
      "newEvidenceIds": [
        "EVD-0028"
      ],
      "verificationAr": "فحص حزمة RC2 بعد فكها",
      "remainingLimitsAr": "لا يثبت سلوك النسخة المنشورة.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة",
      "updatedAt": "2026-09-24T01:10:00+03:00",
      "evidenceType": "handoff"
    },
    {
      "id": "REV-0011",
      "parentId": null,
      "titleAr": "عدد أسطر git status ليس دليل عدم التعديل",
      "source": "مراجعة حزمة الأماكن RC1",
      "descriptionAr": "RC1 اعتمد ثبات 1151 سطرًا.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "medium",
      "impactAr": "RC1 اعتمد ثبات 1151 سطرًا.",
      "unit": "places-handoff",
      "files": [
        "evidence/baseline/source_file_hashes_before.txt"
      ],
      "previousEvidenceAr": "حزمة 20260924_0030",
      "actionAr": "RC2 يسجل بصمات الملفات قبل وبعد. لم يُدعَ إصلاح النقص بأثر رجعي.",
      "newEvidenceIds": [
        "EVD-0028"
      ],
      "verificationAr": "فحص حزمة RC2 بعد فكها",
      "remainingLimitsAr": "دليل RC1 يبقى محدودًا بتلك الطريقة.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة",
      "updatedAt": "2026-09-24T01:10:00+03:00",
      "evidenceType": "handoff"
    },
    {
      "id": "REV-0012",
      "parentId": null,
      "titleAr": "تعارض عبارة التنقيح",
      "source": "مراجعة حزمة الأماكن RC1",
      "descriptionAr": "ملف قال إن شيئًا لم يُنقح والفهرس فيه نسخة منقحة.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "medium",
      "impactAr": "ملف قال إن شيئًا لم يُنقح والفهرس فيه نسخة منقحة.",
      "unit": "places-handoff",
      "files": [
        "lib/src/core/config/app_config.dart"
      ],
      "previousEvidenceAr": "حزمة 20260924_0030",
      "actionAr": "وُحّد السجل على app_config.dart فقط. auth_credentials ليس سرًا.",
      "newEvidenceIds": [
        "EVD-0028"
      ],
      "verificationAr": "فحص حزمة RC2 بعد فكها",
      "remainingLimitsAr": "المفتاح الأصلي بقي في المستودع ولم يُمس.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة في مراجعة الحزمة",
      "updatedAt": "2026-09-24T01:10:00+03:00",
      "evidenceType": "handoff"
    },
    {
      "id": "REV-0013",
      "parentId": null,
      "titleAr": "المرجع البصري للتصورات غير مرفق",
      "source": "مراجعة حزمة الأماكن RC1",
      "descriptionAr": "ثلاثة تصورات أعجب بها المالك بلا ملفات صور في التسليم.",
      "reqIds": [
        "REQ-0026"
      ],
      "severity": "medium",
      "impactAr": "ثلاثة تصورات أعجب بها المالك بلا ملفات صور في التسليم.",
      "unit": "places-handoff",
      "files": [
        "data/places-adoption.json"
      ],
      "previousEvidenceAr": "حزمة 20260924_0030",
      "actionAr": "RC3 بحث في ملفات الدراسة وسطح المكتب. الصور الثلاثة غير موجودة. لم تُولَّد بدائل ولم يُستخدم رابط مكسور.",
      "newEvidenceIds": [
        "EVD-0029",
        "EVD-0033"
      ],
      "verificationAr": "فحص حزمة RC2 بعد فكها",
      "remainingLimitsAr": "NEEDS_ASSET لشاشة المنتجات والعيادات والمشاغل. الحالة تبقى قيد المعالجة.",
      "status": "قيد المعالجة",
      "previousStatus": "مفتوحة في مراجعة الحزمة",
      "updatedAt": "2026-09-24T02:20:00+03:00",
      "evidenceType": "handoff"
    },
    {
      "id": "REV-0014",
      "parentId": null,
      "titleAr": "سجل MANIFEST لا يطابق محتويات الحزمة",
      "source": "مراجعة الموقع 0125",
      "descriptionAr": "17 بصمة مختلفة و7 ملفات غير مسجلة وبيانات تعريف قديمة.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "17 بصمة مختلفة و7 ملفات غير مسجلة وبيانات تعريف قديمة.",
      "unit": "reference-site",
      "files": [
        "MANIFEST.json",
        "scripts/write_manifest.py"
      ],
      "previousEvidenceAr": "حزمة الموقع 0125",
      "actionAr": "يُعاد إنشاء السجل من الشجرة النهائية ويستثني نفسه فقط.",
      "newEvidenceIds": [
        "EVD-0030"
      ],
      "verificationAr": "فحص الحزمة المستقل بعد فك ZIP",
      "remainingLimitsAr": "بانتظار مراجعة بشرية. ليس اعتماد دراسة.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مثبتة في المراجعة",
      "updatedAt": "2026-09-24T02:20:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0015",
      "parentId": null,
      "titleAr": "فاحص الدراسة يفشل خارج مستودع ميرا",
      "source": "مراجعة الموقع 0125",
      "descriptionAr": "18 دليلًا من نوع fact تُفحص على ملفات التطبيق.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "18 دليلًا من نوع fact تُفحص على ملفات التطبيق.",
      "unit": "reference-site",
      "files": [
        "scripts/validate_package.py",
        "scripts/verify_evidence_freshness.py"
      ],
      "previousEvidenceAr": "حزمة الموقع 0125",
      "actionAr": "فُصل فحص الحزمة عن فحص الحداثة. غياب المستودع يُظهر BLOCKED ولا يُفشل الحزمة.",
      "newEvidenceIds": [
        "EVD-0001"
      ],
      "verificationAr": "فحص الحزمة المستقل بعد فك ZIP",
      "remainingLimitsAr": "الحداثة تبقى فحصًا منفصلًا عند تمرير --repo.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مثبتة في المراجعة",
      "updatedAt": "2026-09-24T02:20:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0016",
      "parentId": null,
      "titleAr": "لقطة سطح المكتب ليست بعرض 1280",
      "source": "مراجعة الموقع 0125",
      "descriptionAr": "places-plan-desktop-1280.png أبعادها 277×445.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "places-plan-desktop-1280.png أبعادها 277×445.",
      "unit": "reference-site",
      "files": [
        "evidence/screenshots/places-plan-desktop-1280.png",
        "evidence/screenshots/rc3-mobile-390x844.png",
        "evidence/screenshots/rc3-tablet-768x1024.png",
        "evidence/screenshots/rc3-desktop-1280x900.png",
        "evidence/tests/rc3_browser.json"
      ],
      "previousEvidenceAr": "حزمة الموقع 0125",
      "actionAr": "التقطت لقطات جديدة بأبعاد 390×844 و768×1024 و1280×900. اللقطة القديمة 277×445 بقيت باسمها وليست إثبات العرض العريض.",
      "newEvidenceIds": [
        "EVD-0033"
      ],
      "verificationAr": "فحص الحزمة المستقل بعد فك ZIP",
      "remainingLimitsAr": "لقطات RC1 ليست تكرار 445/527. قص حافة الجوال ما زال ملاحظة في REV-0019.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مثبتة في المراجعة",
      "updatedAt": "2026-09-24T03:18:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0017",
      "parentId": null,
      "titleAr": "DEPENDENCY_MAP.json ما زال يمرر الخلاصة عبر VenueApi",
      "source": "مراجعة الموقع 0125",
      "descriptionAr": "سلسلة browse-media داخل أرشيف 0125.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "سلسلة browse-media داخل أرشيف 0125.",
      "unit": "reference-site",
      "files": [
        "DEPENDENCY_MAP.json"
      ],
      "previousEvidenceAr": "حزمة الموقع 0125",
      "actionAr": "التصحيح موثق في الموقع. أرشيف المصدر لم يُعد تغليفه. مسار التفاصيل بقي على VenueApi.",
      "newEvidenceIds": [
        "EVD-0030"
      ],
      "verificationAr": "فحص الحزمة المستقل بعد فك ZIP",
      "remainingLimitsAr": "الوثيقة الأصلية داخل ZIP بقيت خاطئة عمدًا لأن الأرشيف لا يُعدَّل.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مثبتة في المراجعة",
      "updatedAt": "2026-09-24T02:20:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0018",
      "parentId": null,
      "titleAr": "سجل الاستبعاد ينفي تنقيحًا يثبته redaction_rc2",
      "source": "مراجعة الموقع 0125",
      "descriptionAr": "EXCLUSIONS_AND_REDACTIONS.json مقابل redaction_rc2.json.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "EXCLUSIONS_AND_REDACTIONS.json مقابل redaction_rc2.json.",
      "unit": "reference-site",
      "files": [
        "EXCLUSIONS_AND_REDACTIONS.json"
      ],
      "previousEvidenceAr": "حزمة الموقع 0125",
      "actionAr": "وُثّق التعارض دون استعادة المفتاح ودون تعديل الأرشيف.",
      "newEvidenceIds": [
        "EVD-0031"
      ],
      "verificationAr": "فحص الحزمة المستقل بعد فك ZIP",
      "remainingLimitsAr": "التصحيح لاحق داخل الموقع.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مثبتة في المراجعة",
      "updatedAt": "2026-09-24T02:20:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0019",
      "parentId": "REV-0016",
      "titleAr": "لقطات RC3 تكرر المحتوى كل 445 و527 بكسل",
      "source": "مراجعة لقطات RC3",
      "descriptionAr": "الأبعاد صحيحة لكن الصفوف تتطابق كل 445 بكسل والأعمدة كل 527 في التابلت والكمبيوتر.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "اللقطات لا تثبت سلامة العرض.",
      "unit": "reference-site",
      "files": [
        "evidence/screenshots/rc3-mobile-390x844.png",
        "evidence/screenshots/rc3-tablet-768x1024.png",
        "evidence/screenshots/rc3-desktop-1280x900.png",
        "evidence/tests/rc3_screenshot_tiling.txt",
        "evidence/screenshots/rc1-mobile-390x844.png",
        "evidence/screenshots/rc1-tablet-768x1024.png",
        "evidence/screenshots/rc1-desktop-1280x900.png",
        "evidence/tests/rc1_browser.json"
      ],
      "previousEvidenceAr": "حزمة RC3 0215",
      "actionAr": "أُعيد الالتقاط بـ Chrome headless بدون تكرار مطابق. لقطة التمرير إلى s38 كانت فارغة ورُفضت.",
      "newEvidenceIds": [
        "EVD-0035"
      ],
      "verificationAr": "مقارنة البكسل على الإزاحة 445 و527 ثم فحص اللقطات الجديدة",
      "remainingLimitsAr": "التكرار المطابق زال. لقطة 390 ما زال فيها حبر عند الحافة اليمنى، فلا يُعلن اكتمال خلوها من القص.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مثبتة في المراجعة",
      "updatedAt": "2026-09-24T03:18:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0020",
      "parentId": null,
      "titleAr": "وصف مصدر التفاصيل يتغير بعد طلب قائمة آخر",
      "source": "مراجعة تفعيل اختبار اكتشفي",
      "descriptionAr": "حقل lastOrigin على المستودع كان يُستبدل عندما يقرأ مسار التفاصيل المحلية قائمة الشركاء.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "تفاصيل محلية قد تُعرض على أنها من الخادم.",
      "unit": "mira-app",
      "files": [
        "lib/features/marketplace/data/repositories/marketplace_repository_impl.dart",
        "lib/features/marketplace/presentation/widgets/marketplace_data_banner.dart"
      ],
      "previousEvidenceAr": "حزمة تفعيل الاختبار 0319",
      "actionAr": "أصبحت نتيجة كل طلب CatalogLoad تحمل النقل وعلامة المحتوى. مسار التفاصيل المحلية يقرأ الكتالوج مباشرة ولا يستدعي قائمة الشركاء.",
      "newEvidenceIds": [
        "EVD-0037"
      ],
      "verificationAr": "اختبار يثبت أن تفصيلة محلية تبقى محلية بعد نجاح قائمة من الخادم.",
      "remainingLimitsAr": "استجابات الخادم بلا الحقل demoContent تبقى unmarked، وهذا ليس حكمًا بأنها حقيقية.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة",
      "updatedAt": "2026-09-24T05:10:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0021",
      "parentId": null,
      "titleAr": "المحتوى التجريبي كان يُستنتج من أسماء الجهات",
      "source": "مراجعة تفعيل اختبار اكتشفي",
      "descriptionAr": "قائمة أسماء عربية كانت تقرر أن المجموعة تجريبية.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "high",
      "impactAr": "اسم جهة على الخادم قد يُصنف المحتوى تجريبيًا أو العكس.",
      "unit": "mira-app",
      "files": [
        "lib/features/marketplace/data/marketplace_local_catalog.dart",
        "lib/features/marketplace/domain/entities/partner_summary.dart"
      ],
      "previousEvidenceAr": "حزمة تفعيل الاختبار 0319",
      "actionAr": "الكتالوج المحلي يعلن ContentMark.explicitDemo. الخادم لا يُعلَّم تجريبيًا إلا إذا كان demoContent true. حُذف الاعتماد على الأسماء.",
      "newEvidenceIds": [
        "EVD-0037"
      ],
      "verificationAr": "اختبار يعيد اسم لوريال من الخادم بلا العلم فيبقى unmarked، وعلَم true يجعله explicitDemo.",
      "remainingLimitsAr": "بذرة الخادم الحالية بلا الحقل، لذلك تُعرض unmarked لا حقيقية ولا تجريبية.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة",
      "updatedAt": "2026-09-24T05:10:00+03:00",
      "evidenceType": "correction"
    },
    {
      "id": "REV-0022",
      "parentId": null,
      "titleAr": "قص محتوى الموقع على عرض الجوال",
      "source": "مراجعة لقطات الموقع",
      "descriptionAr": "الجداول وحاوية البحث كانت توسع عرض الصفحة، ولقطة 390 وصل حبرها إلى الحافة.",
      "reqIds": [
        "REQ-0024"
      ],
      "severity": "medium",
      "impactAr": "النص والأزرار قد تُقص على الجوال.",
      "unit": "reference-site",
      "files": [
        "css/layout.css",
        "css/components.css",
        "css/responsive.css"
      ],
      "previousEvidenceAr": "لقطات rc1 في حزمة 0319",
      "actionAr": "أُلغي min-width الثابت للبحث وللجداول، وبطاقات المراحل والروابط تلتف. اللقطات الجديدة تُقاس في دليل هذه الجولة.",
      "newEvidenceIds": [
        "EVD-0038"
      ],
      "verificationAr": "لقطات 390 و768 و1280 وقياس الحافة والتكرار.",
      "remainingLimitsAr": "لقطات 390 و768 و1280 صار scrollWidth فيها مساويًا لعرض النافذة، وحبر الحافة اليمنى واليسرى صفر. التكرار على 445 ليس 1.0. هذا لا يعتمد المرحلة.",
      "status": "معالجة بانتظار المراجعة",
      "previousStatus": "مفتوحة",
      "updatedAt": "2026-09-24T05:10:00+03:00",
      "evidenceType": "correction"
    }
  ],
  "scopeCoverage": [
    {
      "id": "SCOPE-ORIG-00",
      "titleAr": "تدقيق مبني على الأدلة بلا إعادة بناء",
      "sectionId": "s3",
      "dataFiles": [
        "capabilities.json"
      ],
      "evidenceIds": [
        "EVD-0011"
      ],
      "status": "partial",
      "remainingAr": "التشغيل الإنتاجي غير مفحوص",
      "whyAr": "صلاحية الدراسة تمنع التنفيذ الحي",
      "approvalEffectAr": "يمنع إغلاق GATE-00"
    },
    {
      "id": "SCOPE-ORIG-01",
      "titleAr": "اسم الموقع المتاجر الإلكترونية في ميرا",
      "sectionId": "s0",
      "dataFiles": [
        "project.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "",
      "whyAr": "",
      "approvalEffectAr": "لا يمنع المراجعة"
    },
    {
      "id": "SCOPE-ORIG-02",
      "titleAr": "أقسام 00 إلى 19 ومعرفات ثابتة",
      "sectionId": "s21",
      "dataFiles": [
        "project.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "",
      "whyAr": "",
      "approvalEffectAr": "لا يمنع المراجعة"
    },
    {
      "id": "SCOPE-ORIG-03",
      "titleAr": "عدم تعديل منتج ميرا",
      "sectionId": "s2",
      "dataFiles": [
        "evidence/git/STATUS.txt"
      ],
      "evidenceIds": [
        "EVD-0022"
      ],
      "status": "complete",
      "remainingAr": "شجرة العمل كانت متسخة قبل الدراسة",
      "whyAr": "لم تُنسب إلى RC2 ولم تُمسح",
      "approvalEffectAr": "لا يمنع المراجعة"
    },
    {
      "id": "SCOPE-ORIG-04",
      "titleAr": "رؤية 50 منتجًا ومحتوى مرتبط بلا نسخ إعلان",
      "sectionId": "s1",
      "dataFiles": [
        "contracts.json"
      ],
      "evidenceIds": [],
      "status": "partial",
      "remainingAr": "العقود مقترحة غير منفذة",
      "whyAr": "هذه دراسة",
      "approvalEffectAr": "يمنع بدء البناء قبل القرار"
    },
    {
      "id": "SCOPE-RC2-00",
      "titleAr": "عدم إغلاق GATE-00",
      "sectionId": "s0",
      "dataFiles": [
        "project.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "",
      "whyAr": "",
      "approvalEffectAr": "الحالة بانتظار إعادة المراجعة"
    },
    {
      "id": "SCOPE-RC2-01",
      "titleAr": "كل نتيجة داخل الموقع",
      "sectionId": "s20",
      "dataFiles": [
        "section-content.json"
      ],
      "evidenceIds": [],
      "status": "partial",
      "remainingAr": "يكتمل بحزمة المتصفح",
      "whyAr": "اللقطات بند REV-0007c",
      "approvalEffectAr": "يبقي الملاحظة مفتوحة إن غابت اللقطات"
    },
    {
      "id": "SCOPE-RC2-04",
      "titleAr": "سجل REV-0001 إلى REV-0007",
      "sectionId": "s20",
      "dataFiles": [
        "review-findings.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "بعض البنود الفرعية قيد المعالجة",
      "whyAr": "لا إخفاء للنقص",
      "approvalEffectAr": "الملاحظة المفتوحة تمنع ادعاء الاكتمال"
    },
    {
      "id": "SCOPE-RC2-05",
      "titleAr": "تدقيق تنفيذ الشركاء والإدارة",
      "sectionId": "s6",
      "dataFiles": [
        "partner-traces.json"
      ],
      "evidenceIds": [
        "EVD-0011",
        "EVD-0013",
        "EVD-0026"
      ],
      "status": "partial",
      "remainingAr": "عزل الكتابة مثبت في المصدر واختبار mock فقط",
      "whyAr": "لا قاعدة حية",
      "approvalEffectAr": "SOURCE_ONLY"
    },
    {
      "id": "SCOPE-RC2-06",
      "titleAr": "تصحيح الوجود والغياب والتوقف",
      "sectionId": "s4",
      "dataFiles": [
        "judgment-corrections.json"
      ],
      "evidenceIds": [
        "EVD-0018"
      ],
      "status": "complete",
      "remainingAr": "API الإنتاج UNKNOWN",
      "whyAr": "لم يُنفذ طلب شبكة",
      "approvalEffectAr": "UNKNOWN لا يُغلق كحقيقة"
    },
    {
      "id": "SCOPE-RC2-07",
      "titleAr": "عقود الفلاتر والمثال المرجعي",
      "sectionId": "s8",
      "dataFiles": [
        "contracts.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "غير منفذ في المنتج",
      "whyAr": "مقترح دراسة",
      "approvalEffectAr": "لا يُحتسب ميزة مبنية"
    },
    {
      "id": "SCOPE-RC2-08",
      "titleAr": "وسائط وتكلفة وتنظيم",
      "sectionId": "s9",
      "dataFiles": [
        "regulatory.json"
      ],
      "evidenceIds": [
        "EVD-0024"
      ],
      "status": "partial",
      "remainingAr": "الأسعار غير متحققة",
      "whyAr": "لا سعر رسمي مجلوب لهذه الدورة",
      "approvalEffectAr": "لا اعتماد تكلفة"
    },
    {
      "id": "SCOPE-RC2-09",
      "titleAr": "قبول ومراحل",
      "sectionId": "s15",
      "dataFiles": [
        "roadmap.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "الجهد نطاق تقديري",
      "whyAr": "افتراضات مكتوبة في البوابة",
      "approvalEffectAr": "لا يمنع المراجعة"
    },
    {
      "id": "SCOPE-RC2-10",
      "titleAr": "JSON مصدر الحقيقة",
      "sectionId": "s19",
      "dataFiles": [
        "section-content.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "",
      "whyAr": "",
      "approvalEffectAr": "يُراجع مع REV-0007a"
    },
    {
      "id": "SCOPE-RC2-11",
      "titleAr": "تحقق سلبي وإيجابي",
      "sectionId": "s19",
      "dataFiles": [
        "evidence/tests"
      ],
      "evidenceIds": [
        "EVD-0027"
      ],
      "status": "complete",
      "remainingAr": "التحقق بنيوي ولا يغني عن المراجعة الموضوعية",
      "whyAr": "التجارب السلبية مثبتة في السجل",
      "approvalEffectAr": "فشل الأداة يبقي REV-0006 مفتوحة"
    },
    {
      "id": "SCOPE-RC2-12",
      "titleAr": "اختبار متصفح",
      "sectionId": "s21",
      "dataFiles": [
        "evidence/screenshots"
      ],
      "evidenceIds": [],
      "status": "partial",
      "remainingAr": "لقطة سطح المكتب 1280 فقط. لقطات 768 و390 خرجت فارغة وحُذفت.",
      "whyAr": "Chrome headless لم يرسم التابلت والجوال. التفاعل ثبت في متصفح بعرض 293.",
      "approvalEffectAr": "لا يُسمى نجاحًا تفاعليًا قبل اللقطات"
    },
    {
      "id": "SCOPE-RC2-13",
      "titleAr": "مصفوفة التغطية",
      "sectionId": "s21",
      "dataFiles": [
        "scope-coverage.json"
      ],
      "evidenceIds": [],
      "status": "complete",
      "remainingAr": "",
      "whyAr": "",
      "approvalEffectAr": "المراجع ينتقل من البند إلى الدليل"
    },
    {
      "id": "SCOPE-RC2-14",
      "titleAr": "حزمة RC2 وSHA",
      "sectionId": "s18",
      "dataFiles": [
        "changelog.json"
      ],
      "evidenceIds": [],
      "status": "partial",
      "remainingAr": "تُختم بعد الاختبار",
      "whyAr": "النسخ يتم في نهاية الجولة",
      "approvalEffectAr": "الحزمة السابقة لا تُستبدل بصمت"
    },
    {
      "id": "SCOPE-PLC-01",
      "titleAr": "ملخص قرار الاستفادة",
      "sectionId": "s22",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-02",
      "titleAr": "ما وصل من الأماكن",
      "sectionId": "s23",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0028"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-03",
      "titleAr": "نتائج مراجعة الحزمة",
      "sectionId": "s24",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0028"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-04",
      "titleAr": "سجل معالجة الملاحظات",
      "sectionId": "s25",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-05",
      "titleAr": "مصفوفة إعادة الاستخدام",
      "sectionId": "s26",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-06",
      "titleAr": "تجربة المنتجات",
      "sectionId": "s27",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-07",
      "titleAr": "تجربة العيادات والمشاغل",
      "sectionId": "s28",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-08",
      "titleAr": "معيار الوسائط",
      "sectionId": "s29",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-09",
      "titleAr": "المشاهدات والإحصاءات",
      "sectionId": "s30",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-10",
      "titleAr": "ربط المتاجر وإعلانات المشاهير",
      "sectionId": "s31",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-11",
      "titleAr": "خطة التنفيذ المرحلية",
      "sectionId": "s32",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-12",
      "titleAr": "القرارات المفتوحة",
      "sectionId": "s33",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-13",
      "titleAr": "الأدلة والتنزيلات",
      "sectionId": "s34",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0028"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-PLC-14",
      "titleAr": "سجل تغييرات خطة الأماكن",
      "sectionId": "s35",
      "dataFiles": [
        "places-adoption.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "بانتظار مراجعة بشرية. ليس اعتمادًا نهائيًا.",
      "whyAr": "التوثيق أُضيف إلى الموقع الحالي دون تنفيذ المنتج.",
      "approvalEffectAr": "لا يغلق GATE-00 ولا يبدأ GATE-08 أو GATE-09"
    },
    {
      "id": "SCOPE-RC3-01",
      "titleAr": "فحص الحزمة مستقل عن المستودع",
      "sectionId": "s19",
      "dataFiles": [
        "project.json"
      ],
      "evidenceIds": [
        "EVD-0030"
      ],
      "status": "partial",
      "remainingAr": "الحداثة فحص منفصل",
      "whyAr": "FAIL 18 كانت بسبب ملفات المستودع",
      "approvalEffectAr": "لا يغلق GATE-00"
    },
    {
      "id": "SCOPE-RC3-02",
      "titleAr": "التصورات المرجعية",
      "sectionId": "s36",
      "dataFiles": [
        "visual-references.json"
      ],
      "evidenceIds": [
        "EVD-0029"
      ],
      "status": "partial",
      "remainingAr": "NEEDS_ASSET للتصورات الثلاثة",
      "whyAr": "الأصول غير موجودة في النطاق المفحوص",
      "approvalEffectAr": "لا يُدعى اكتمال الصور"
    },
    {
      "id": "SCOPE-RC3-03",
      "titleAr": "تصحيح توثيق المصدر دون تعديل أرشيفه",
      "sectionId": "s37",
      "dataFiles": [
        "source-handoff-corrections.json"
      ],
      "evidenceIds": [
        "EVD-0030",
        "EVD-0031",
        "EVD-0032"
      ],
      "status": "partial",
      "remainingAr": "الأرشيف الأصلي يبقى بنصه",
      "whyAr": "المراجعة منعت إعادة التغليف",
      "approvalEffectAr": "لا يغيّر SHA-256 لأرشيف 0125"
    },
    {
      "id": "SCOPE-RC1-01",
      "titleAr": "تفعيل اختبار اكتشفي وخطة الدمج",
      "sectionId": "s38",
      "dataFiles": [
        "discover-integration-plan.json"
      ],
      "evidenceIds": [
        "EVD-0034"
      ],
      "status": "partial",
      "remainingAr": "إثبات الجهاز ولقطات الموقع البديلة يُستكملان في التقرير",
      "whyAr": "التفعيل بالعلم وخطة منع التكرار أُضيفا دون دمج الأماكن",
      "approvalEffectAr": "لا يغلق GATE-00 ولا ينشر الميزة"
    },
    {
      "id": "SCOPE-PH1-01",
      "titleAr": "تسجيل مراحل اكتشفي وتنفيذ شاشة العرض",
      "sectionId": "s39",
      "dataFiles": [
        "discover-phases.json"
      ],
      "evidenceIds": [
        "EVD-0036",
        "EVD-0038",
        "EVD-0039"
      ],
      "status": "partial",
      "remainingAr": "المرحلة 1 قيد التنفيذ لنقص إثبات الفيديو على جهاز. المراحل 2 إلى 5 لم تبدأ.",
      "whyAr": "التسجيل شرط التسليم، والتنفيذ اقتصر على المرحلة الأولى دون اعتمادها",
      "approvalEffectAr": "لا يعتمد المرحلة 1 ولا يغلق GATE-00"
    }
  ],
  "judgmentCorrections": [
    {
      "id": "JDG-0001",
      "subject": "CAP-0007",
      "beforeAr": "موجودة ومفعلة ودليلها SPEC",
      "afterAr": "موجودة في المصدر، التفعيل الإنتاجي UNKNOWN، والأدلة تنفيذية",
      "reasonAr": "REV-0001: المواصفات ليست تنفيذًا",
      "evidenceIds": [
        "EVD-0007",
        "EVD-0011",
        "EVD-0012"
      ]
    },
    {
      "id": "JDG-0002",
      "subject": "CAP-0008",
      "beforeAr": "موجودة ومفعلة بلا دليل",
      "afterAr": "موجودة في المصدر، التفعيل UNKNOWN، مع أدلة المتحكم والعميل",
      "reasonAr": "REV-0001 وREV-0002",
      "evidenceIds": [
        "EVD-0014",
        "EVD-0015"
      ]
    },
    {
      "id": "JDG-0003",
      "subject": "CAP-0010 CAP-0011 CAP-0012 CAP-0014",
      "beforeAr": "غياب أو وجود بلا أدلة مرتبطة أو بمقتطف مخطط فقط",
      "afterAr": "غياب داخل نطاق بحث موثّق، أو وجود علم اشتراك في المصدر",
      "reasonAr": "REV-0002",
      "evidenceIds": [
        "EVD-0018",
        "EVD-0019",
        "EVD-0020",
        "EVD-0023"
      ]
    },
    {
      "id": "JDG-0004",
      "subject": "CAP-0001 CAP-0002 CAP-0003 CAP-0009",
      "beforeAr": "التفعيل ENABLED مع SOURCE_ONLY",
      "afterAr": "التفعيل UNKNOWN لأن الشيفرة لا تثبت الإنتاج",
      "reasonAr": "قاعدة RC2: لا ENABLED بلا دليل تشغيل",
      "evidenceIds": [
        "EVD-0001",
        "EVD-0006",
        "EVD-0008"
      ]
    },
    {
      "id": "JDG-0005",
      "subject": "PAUSE-0001",
      "beforeAr": "الإيقاف موثق بعبارة الانطلاق قريبًا وAPI قابل للوصول",
      "afterAr": "إخفاء واجهة موثق. وصول API وبوابة الخادم UNKNOWN. السبب التاريخي غير موثق.",
      "reasonAr": "REV-0003",
      "evidenceIds": [
        "EVD-0001",
        "EVD-0002",
        "EVD-0006"
      ]
    },
    {
      "id": "JDG-0006",
      "subject": "PAUSE-0002",
      "beforeAr": "حجز متوقف",
      "afterAr": "مسار غير مكتمل وليس خدمة تُستأنف",
      "reasonAr": "REV-0003",
      "evidenceIds": [
        "EVD-0003",
        "EVD-0018"
      ]
    },
    {
      "id": "JDG-0007",
      "subject": "PAUSE-0003",
      "beforeAr": "شراء داخلي متوقف",
      "afterAr": "غير منفذ حسب التصميم الحالي",
      "reasonAr": "REV-0003",
      "evidenceIds": [
        "EVD-0004",
        "EVD-0007",
        "EVD-0018"
      ]
    }
  ],
  "contracts": {
    "unimplemented": true,
    "labelAr": "مقترح غير منفذ",
    "entities": [
      {
        "name": "Product",
        "existsAr": "جدول Product: اسم وسعر وهلالة ورابط خارجي ووسوم",
        "extendAr": "الإبقاء على المعرف وإضافة حالة النشر دون جدول موازٍ",
        "fields": [
          {
            "name": "id",
            "type": "string",
            "required": true,
            "source": "الخادم"
          },
          {
            "name": "partnerId",
            "type": "string",
            "required": true,
            "source": "من الرمز لا من العميل"
          },
          {
            "name": "status",
            "type": "enum draft|active|paused|archived",
            "required": true,
            "source": "الشريك والإدارة"
          }
        ]
      },
      {
        "name": "ProductVariant",
        "existsAr": "غير موجود في المخطط المبحوث",
        "extendAr": "متغير جديد يرتبط بمنتج واحد",
        "fields": [
          {
            "name": "id",
            "type": "string",
            "required": true,
            "source": "الخادم"
          },
          {
            "name": "productId",
            "type": "string",
            "required": true,
            "source": "المسار"
          },
          {
            "name": "color",
            "type": "enum",
            "required": true,
            "source": "قاموس يديره المتجر"
          },
          {
            "name": "size",
            "type": "enum",
            "required": true,
            "source": "قاموس المقاسات"
          },
          {
            "name": "stockQty",
            "type": "int>=0",
            "required": true,
            "source": "الشريك"
          },
          {
            "name": "priceHalalas",
            "type": "int>=0",
            "required": true,
            "source": "الشريك"
          },
          {
            "name": "active",
            "type": "bool",
            "required": true,
            "source": "الشريك"
          }
        ]
      },
      {
        "name": "ServiceOffering",
        "existsAr": "جدول Service بلا فرع",
        "extendAr": "ربط branchId عند تعدد الفروع",
        "fields": [
          {
            "name": "facilityId",
            "type": "string",
            "required": true,
            "source": "شريك من نوع عيادة أو صالون"
          },
          {
            "name": "branchId",
            "type": "string",
            "required": true,
            "source": "سجل الفرع"
          },
          {
            "name": "bookingMode",
            "type": "enum inquiry|appointment|external",
            "required": true,
            "source": "قرار المتجر"
          }
        ]
      },
      {
        "name": "MediaAsset",
        "existsAr": "لا نموذج في البحث EVD-0019",
        "extendAr": "أصل يرتبط بمنتج أو متغير أو خدمة دون نسخ السعر",
        "fields": [
          {
            "name": "ownerType",
            "type": "enum product|variant|service",
            "required": true,
            "source": "عند الرفع"
          },
          {
            "name": "ownerId",
            "type": "string",
            "required": true,
            "source": "الرابط"
          },
          {
            "name": "state",
            "type": "enum uploaded|processing|in_review|published|failed|removed",
            "required": true,
            "source": "دورة المعالجة"
          }
        ]
      },
      {
        "name": "AdLink",
        "existsAr": "لا نموذج مشاهير",
        "extendAr": "رابط إعلان يقرأ السعر والمخزون من المتغير",
        "fields": [
          {
            "name": "publisherId",
            "type": "string",
            "required": true,
            "source": "حساب الناشر"
          },
          {
            "name": "advertiserId",
            "type": "string",
            "required": true,
            "source": "المعلن"
          },
          {
            "name": "sellerPartnerId",
            "type": "string",
            "required": true,
            "source": "الشريك المالك"
          },
          {
            "name": "variantId",
            "type": "string",
            "required": true,
            "source": "المنتج الأصلي"
          },
          {
            "name": "storeApproval",
            "type": "enum pending|approved|rejected|expired",
            "required": true,
            "source": "المتجر"
          }
        ]
      }
    ],
    "example": {
      "titleAr": "فستان أزرق مقاس M متوفر",
      "variants": [
        {
          "id": "V1",
          "color": "blue",
          "size": "M",
          "stockQty": 5,
          "match": true
        },
        {
          "id": "V2",
          "color": "blue",
          "size": "S",
          "stockQty": 0,
          "match": false
        },
        {
          "id": "V3",
          "color": "red",
          "size": "M",
          "stockQty": 3,
          "match": false
        }
      ],
      "ruleAr": "AND على متغير واحد: اللون والمقاس والتوفر من الصف نفسه.",
      "productCount": 1,
      "clipCountAr": "مقطعان منشوران مرتبطان بالمنتج أو بـ V1 يُحسبان محتوىً مرئيًا. مقطع مرتبط بـ V3 فقط لا يظهر. عدد المنتجات 1 وعدد المقاطع قد يكون 2."
    }
  },
  "regulatory": {
    "legalApproval": false,
    "accessDate": "2026-09-23",
    "sources": [
      {
        "id": "REG-0001",
        "topicAr": "متاجر الملابس والمنتجات غير الطبية",
        "sourceAr": "نظام التجارة الإلكترونية — هيئة الخبراء / وزارة التجارة",
        "url": "https://laws.boe.gov.sa/BoeLaws/Laws/LawDetails/360de590-0286-4fa5-a243-aa9100c31979/1",
        "alsoUrl": "https://mc.gov.sa/ar/ECC/pages/default.aspx",
        "appliesAr": "التعاملات الإلكترونية لبيع المنتجات والإعلان عنها داخل النطاق الذي يحدده النظام.",
        "designImpactAr": "تعريف البائع وبيانات العرض ومسار الشراء يجب أن يبقى قابلًا للتمييز. هذه الدراسة لا تستخرج التزامًا تنفيذيًا مادةً مادة.",
        "specialistQuestionsAr": [
          "هل منصة الوساطة تأخذ وصف موفر خدمة أم معلن؟",
          "ما بيانات المتجر الواجب إظهارها في بطاقة المنتج؟"
        ]
      },
      {
        "id": "REG-0002",
        "topicAr": "إعلانات المشاهير على الشبكات",
        "sourceAr": "ترخيص موثوق — الهيئة العامة لتنظيم الإعلام",
        "url": "https://mawthooq.gmedia.gov.sa/",
        "alsoUrl": "https://my.gov.sa/ar/services/21449",
        "appliesAr": "تقديم الأفراد محتوى إعلانيًا عبر منصات التواصل. لا يُنقل تلقائيًا إلى كل مقطع داخل تطبيق ميرا.",
        "designImpactAr": "فصل المعلن والناشر ووسم المحتوى الإعلاني قبل النشر. الترخيص نفسه سؤال لمختص لا حقل نفترضه كافيًا.",
        "specialistQuestionsAr": [
          "هل مقطع داخل التطبيق يُعد منصة تواصل بالمعنى التنظيمي؟",
          "ما إثبات الترخيص الذي نطلبه من الناشر؟"
        ]
      },
      {
        "id": "REG-0003",
        "topicAr": "المنتجات التجميلية",
        "sourceAr": "إدراج منتجات التجميل — هيئة الغذاء والدواء",
        "url": "https://www.sfda.gov.sa/ar/eservices/88819",
        "alsoUrl": "https://www.sfda.gov.sa/ar/taxonomy/term/47",
        "appliesAr": "إدراج مستحضر تجميلي قبل تداوله. الإعلان عن ادعاء علاجي خارج نطاق هذه الصفحة حتى يراجعه مختص.",
        "designImpactAr": "عدم تحويل وسوم البشرة التسويقية إلى ادعاء طبي. ربط المنتج بسجل إدراج إن قرر المختص ذلك.",
        "specialistQuestionsAr": [
          "أي ادعاءات تجميل ممنوعة في بطاقة المنتج؟",
          "هل يكفي رقم الإدراج في البيانات؟"
        ]
      },
      {
        "id": "REG-0004",
        "topicAr": "الخدمات الطبية والإعلان عنها",
        "sourceAr": "ضوابط المحتوى الإعلاني للمنشآت الصحية — وزارة الصحة",
        "url": "https://www.moh.gov.sa/eServices/Licences/Documents/10.pdf",
        "alsoUrl": "https://www.moh.gov.sa/eservices/licences/pages/private-health-institutions-law-and-regulations.aspx",
        "appliesAr": "المحتوى الإعلاني للخدمات الصحية المرخصة، بما فيه وضوح أنه إعلان وبيانات المنشأة والتحذيرات.",
        "designImpactAr": "عيادة ميرا لا تُعرض كصالون. مسار الحجز الطبي منفصل عن شراء الملابس.",
        "specialistQuestionsAr": [
          "هل الخصم على خدمة طبية يحتاج موافقة ترخيص قبل عرضه؟",
          "ما الحقول الإلزامية في بطاقة العيادة؟"
        ]
      },
      {
        "id": "REG-0005",
        "topicAr": "صالونات التزيين",
        "sourceAr": "اشتراطات التزيين النسائي — وزارة البلديات والإسكان",
        "url": "https://momah.gov.sa/ar/node/14893",
        "alsoUrl": "https://momah.gov.sa/sites/default/files/2024-12/alqwa%60d%20altnfy.pdf",
        "appliesAr": "ترخيص نشاط التزيين ومنع خدمات منزلية أو منتجات دوائية داخل مركز غير مرخص لذلك.",
        "designImpactAr": "نوع الشريك salon لا يرث حقول العيادة. الخدمة خارج المنشأة ليست افتراضًا.",
        "specialistQuestionsAr": [
          "ما رقم الترخيص البلدي الذي يُخزن؟",
          "أين حد الخدمة الطبية داخل الصالون؟"
        ]
      },
      {
        "id": "REG-0006",
        "topicAr": "بيانات التحليل الشخصي",
        "sourceAr": "نظام حماية البيانات الشخصية — سدايا",
        "url": "https://sdaia.gov.sa/ar/Research/Pages/DataProtection.aspx",
        "alsoUrl": "https://sdaia.gov.sa/ar/Research/Documents/ExecutiveRegulations.pdf",
        "appliesAr": "معالجة بيانات شخصية. نتائج البشرة قد تكون حساسة حسب توصيف المختص لا حسب تسمية التسويق.",
        "designImpactAr": "REQ-0017 يفصل الإعلان عن نتيجة التحليل. لا استخدام للنتيجة كجمهور إعلاني قبل رأي مختص.",
        "specialistQuestionsAr": [
          "هل نتيجة البشرة بيانات حساسة في هذا المنتج؟",
          "ما أساس معالجة المطابقة؟"
        ]
      }
    ]
  },
  "costs": {
    "priceStatus": "غير متحقق",
    "accessDate": "2026-09-23",
    "assumptions": {
      "stores": 20,
      "productsPerStore": 50,
      "imagesPerProduct": 4,
      "avgImageMb": 1.5,
      "videosPerProduct": 1,
      "videoSeconds": 30,
      "mbPerVideoMinute": "غير متحقق",
      "watchMinutesPerMonth": 10000
    },
    "equationsAr": [
      "عدد المنتجات = المتاجر × منتجات المتجر",
      "تخزين الصور بالميغابايت = عدد المنتجات × صور المنتج × متوسط حجم الصورة",
      "تخزين الفيديو لا يُحسب برقم حتى يُثبت mb لكل دقيقة من مصدر السعر",
      "تكلفة المعالجة والبث = غير متحقق لهذه الدورة"
    ],
    "scenariosAr": [
      "سيناريو الدراسة: 20 متجرًا و50 منتجًا. تخزين الصور الافتراضي 20×50×4×1.5 = 6000 ميغابايت. هذا حجم افتراضي لا فاتورة.",
      "دقائق المشاهدة 10000 رقم افتراضي للسيناريو وليس قياس إنتاج."
    ]
  },
  "mediaLifecycle": {
    "unimplemented": true,
    "inspectedExistingAr": "لا video_player ولا VideoPlayer في lib وmira-api/src حسب EVD-0024. لا يُقترح مزود كبديل عن مشغل قائم لأنه غير موجود في هذا النطاق.",
    "steps": [
      "رفع",
      "تحقق من النوع والحجم",
      "معالجة",
      "مراجعة",
      "نشر",
      "تشغيل",
      "إيقاف أو حذف"
    ],
    "playbackAr": [
      "تشغيل متكيف إن وُجد أكثر من تمثيل بعد المعالجة",
      "حد لذاكرة الجهاز وإلغاء التحميل المسبق عند انخفاض الذاكرة",
      "مقطع مسموع واحد",
      "حفظ نسبة العرض دون قص جوهري",
      "حفظ موضع المشاهدة لكل أصل",
      "فشل الشبكة يعيد المحاولة دون نشر مكرر"
    ],
    "vendorAr": "لا اختيار مزود في RC2. أي سعر لاحق يُؤرخ بمصدره أو يُوسم غير متحقق."
  },
  "partnerTraces": [
    {
      "id": "TR-01",
      "titleAr": "طلب الانضمام",
      "chain": [
        "apply.html",
        "PartnersApi.apply",
        "POST /partners-portal/apply",
        "PartnersPortalController.apply",
        "PartnersPortalService.apply",
        "PartnerApplication",
        "status token"
      ],
      "verified": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0011",
        "EVD-0016"
      ]
    },
    {
      "id": "TR-02",
      "titleAr": "متابعة الحالة",
      "chain": [
        "status.html",
        "GET apply/status/:token",
        "getApplicationStatus"
      ],
      "verified": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0011"
      ]
    },
    {
      "id": "TR-03",
      "titleAr": "الدخول والخروج",
      "chain": [
        "login.html",
        "POST /partners-portal/login",
        "email+accessToken",
        "PartnerUser",
        "localStorage",
        "clearSession"
      ],
      "verified": "SOURCE_ONLY",
      "noteAr": "لا كلمة مرور منفصلة في هذا المسار. partnerId من السجل.",
      "evidenceIds": [
        "EVD-0021",
        "EVD-0016"
      ]
    },
    {
      "id": "TR-04",
      "titleAr": "عزل المنتجات",
      "chain": [
        "Bearer",
        "PartnerTokenGuard",
        "partnerId من السجل",
        "assertProductOwner where id+partnerId",
        "رفض إن لم يُوجد"
      ],
      "verified": "SOURCE_PLUS_UNIT_MOCK",
      "noteAr": "الاختبار EVD-0026 على mock. لا يثبت قاعدة حية. القراءة العامة عبر marketplace ليست لوحة الشريك.",
      "evidenceIds": [
        "EVD-0012",
        "EVD-0013",
        "EVD-0026"
      ]
    },
    {
      "id": "TR-05",
      "titleAr": "الإدارة مقابل الشريك",
      "chain": [
        "الشريك: رمز شريك واحد",
        "الإدارة: X-Admin-Key على كل مسارات /admin",
        "اعتماد ورفض وإيقاف status"
      ],
      "verified": "SOURCE_ONLY",
      "noteAr": "لا أدوار موظفين. البحث عن Employee وBranch بلا تطابق EVD-0019.",
      "evidenceIds": [
        "EVD-0014",
        "EVD-0025",
        "EVD-0019"
      ]
    },
    {
      "id": "TR-06",
      "titleAr": "سعر ووسائط وتوفر",
      "chain": [
        "UpsertProductDto priceHalalas+externalUrl+active",
        "لا حقل مخزون",
        "لا رفع وسيط"
      ],
      "verified": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0017"
      ]
    },
    {
      "id": "TR-07",
      "titleAr": "حجوزات",
      "chain": [
        "bookingEnabled اختياري في عقد الخدمة",
        "لا model Booking في البحث",
        "زر التطبيق stub"
      ],
      "verified": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0017",
        "EVD-0003",
        "EVD-0018"
      ]
    },
    {
      "id": "TR-08",
      "titleAr": "تحليلات",
      "chain": [
        "POST /track بلا حارس",
        "partnerId من الجسم",
        "لوحة الشريك تعد أحداث 30 يومًا"
      ],
      "verified": "SOURCE_ONLY",
      "noteAr": "هذه فجوة مسجلة لا تُصلح في هذه المرحلة.",
      "evidenceIds": [
        "EVD-0013"
      ]
    },
    {
      "id": "TR-09",
      "titleAr": "إيقاف إداري",
      "chain": [
        "PATCH /admin/partners/:id/status",
        "active|suspended",
        "الحارس يرفض شريكًا غير active"
      ],
      "verified": "SOURCE_ONLY",
      "evidenceIds": [
        "EVD-0014",
        "EVD-0012"
      ]
    }
  ],
  "sectionContent": {
    "s0": [
      {
        "type": "callout",
        "text": "RC3 — تصحيح الموقع بعد المراجعة. الحالة: بانتظار إعادة المراجعة. GATE-00 غير مغلق. أرشيف مصدر الأماكن 0125 لم يُعد تغليفه."
      },
      {
        "type": "h3",
        "text": "إجابات المراجعة"
      },
      {
        "type": "list",
        "items": [
          "ماذا كان ناقصًا في النسخة السابقة؟ أدلة تنفيذ الشركاء والإدارة، وسجل بحث قابل للمراجعة، وفصل طبقات الإيقاف، ومعايير قبول، وخطة تغطي المتطلبات، وعقود فلاتر، ومصادر تنظيمية، ومدقق يرفض البيانات الفاسدة، وعرض موضوعي خارج app.js.",
          "ما الذي تحققنا منه الآن؟ مسارات المصدر من الصفحة إلى القاعدة لعزل الكتابة، وفرق مفتاح الإدارة عن رمز الشريك، وغياب نماذج الطلب والمتغير والمشاهير داخل نطاق الأوامر المرفقة. التشغيل الإنتاجي لم يُفحص.",
          "ما الأحكام التي صححناها؟ انظر جدول الأحكام التي تغيرت بعد المراجعة في القسم 4. التفعيل لم يعد ENABLED مع SOURCE_ONLY. الشراء الداخلي لم يعد خدمة متوقفة.",
          "ما الذي نملكه ويمكن إعادة استخدامه؟ جداول Partner وProduct وService، وحارس الرمز، وعزل assertProductOwner، واعتماد الطلبات، وعميل البوابة ولوحة الإدارة، والرابط الخارجي للشراء.",
          "ما الذي يحتاج تطويرًا؟ المتغيرات، الفروع، دورة الوسائط، الفلاتر على متغير واحد، إعلان بلا نسخ سعر، سد تتبع partnerId القادم من العميل، ومسارات الطلب والحجز إن قُرر ذلك.",
          "ما القرارات المطلوبة؟ DEC-0001 مكان الدفع، DEC-0002 البث الحي، DEC-0003 اعتماد المتجر، DEC-0004 منع نسخ الإعلان، DEC-0005 اعتماد الدراسة. لا قرار يُغلق هنا.",
          "ما مراحل التنفيذ وشروط قبولها؟ GATE-01 إلى GATE-05 في القسم 15. GATE-00 دراسة فقط وما زال قيد المعالجة. REQ-0020 قرار نطاق مرتبط بـ DEC-0002.",
          "ما الذي ما زال غير معروف ولماذا؟ قيمة الأعلام في البناء المنشور، وصول API رغم إخفاء الواجهة، ضبط مفتاح الإدارة، سلوك قاعدة الإنتاج، وأسعار مزود الوسائط. السبب: صلاحية هذه المرحلة تمنع التشغيل الحي ولم تُجلب تسعيرة موثوقة."
        ]
      }
    ],
    "s1": [
      {
        "type": "p",
        "text": "الرؤية الأصلية ثابتة: متجر بنحو 50 منتجًا، لكل منتج عرض مرئي مستقل، وإعلان المشهور يشير إلى المنتج دون نسخ السعر أو المخزون."
      },
      {
        "type": "p",
        "text": "البث الحي ليس جزءًا من الرؤية المنفذة. هو {{DEC-0002}}."
      },
      {
        "type": "proposal",
        "text": "العقود في القسم 8 مقترحة وغير منفذة."
      }
    ],
    "s2": [
      {
        "type": "p",
        "text": "خط الأساس السابق والحالي: {{EVD-0022}}. commit المفحوص 15fe65c40d3dedb9afdd95619f2945bd84cb616a. وقت الفحص 2026-09-23T03:43:29+03:00."
      },
      {
        "type": "p",
        "text": "شجرة العمل متسخة بملفات خارج هذه الدراسة. لم تُمسح ولم تُنسب إلى RC2. الفرق عن الأساس السابق: نفس commit، مع حزمة دراسة RC2 غير مدمجة في المنتج."
      },
      {
        "type": "list",
        "items": [
          "المستودع: /Users/fayez/Desktop/mira",
          "الفرع: mira/p5-strict-frontend-recovery-2026-09-14",
          "ما لم يُفحص: بناء المتجر المنشور وقيمة dart-define على الجهاز"
        ]
      }
    ],
    "s3": [
      {
        "type": "p",
        "text": "القدرات التالية من البيانات. التفعيل ENABLED غير مستخدم مع SOURCE_ONLY في هذه النسخة."
      },
      {
        "type": "callout",
        "text": "الغياب ABSENT_AFTER_SEARCH يعني نطاق البحث في الدليل، لا نفيًا لكل منظومة خارج المستودع."
      }
    ],
    "s4": [
      {
        "type": "p",
        "text": "كل خدمة مفصولة إلى إخفاء واجهة، ومنع تنقل، وبوابة خادم، ووصول API، واكتمال منطق، واعتماد خارجي."
      },
      {
        "type": "callout",
        "text": "إن كان الحقل UNKNOWN فلا يُستنتج منه إيقاف ولا تشغيل."
      },
      {
        "type": "h3",
        "text": "الأحكام التي تغيرت بعد المراجعة"
      }
    ],
    "s5": [
      {
        "type": "p",
        "text": "الشراء الحالي يفتح رابطًا خارجيًا {{EVD-0004}}. الحجز زر غير مكتمل {{EVD-0003}}. الاستفسار والاتصال ليسا مسارين منفصلين في المصدر المفحوص."
      },
      {
        "type": "proposal",
        "text": "الفصل المطلوب في {{REQ-0019}} غير منفذ."
      }
    ],
    "s6": [
      {
        "type": "p",
        "text": "التتبع أدناه من المصدر. يمكن إعادة استخدام العزل في الكتابة. التتبع الذي يأخذ partnerId من العميل يحتاج توسيع حماية لاحقًا ولا يُصلح هنا."
      },
      {
        "type": "callout",
        "text": "لم يُثبت تشغيل إنتاجي. الوسم SOURCE_ONLY مقصود."
      },
      {
        "type": "h3",
        "text": "ما لم يُتحقق منه"
      },
      {
        "type": "list",
        "items": [
          "عزل القراءة على قاعدة حية",
          "جلسات إنتاج",
          "وجود فروع أو موظفين خارج أسماء البحث",
          "نشر partners.mira.app وadmin.mira.app في هذه الجولة"
        ]
      }
    ],
    "s7": [
      {
        "type": "p",
        "text": "لا نموذج ناشر أو معلن في النطاق {{EVD-0023}}. الموافقة والربط مقترحان في عقد AdLink."
      },
      {
        "type": "proposal",
        "text": "الإعلان يقرأ السعر من المتغير. انتهاء الربط يخفي الإعلان ولا يحذف المنتج. الطلب القديم يحتفظ بلقطته حسب {{REQ-0011}} غير المنفذ."
      }
    ],
    "s8": [
      {
        "type": "proposal",
        "text": "التصنيفات التالية مقترحة للدراسة. القيم تُدار من قاموس المتجر لا من نص حر عندما تكون تعدادًا."
      },
      {
        "type": "p",
        "text": "القاعدة: خصائص الفلتر على متغير واحد تُجمع بـ AND. القيم داخل الخاصية الواحدة متعددة الاختيار تُجمع بـ OR. عدد المنتجات المطابقة ليس عدد المقاطع."
      },
      {
        "type": "h3",
        "text": "مثال قابل للتحقق"
      }
    ],
    "s9": [
      {
        "type": "p",
        "text": "قبل أي مزود جديد: لا مشغل فيديو في lib وmira-api/src حسب {{EVD-0024}}."
      },
      {
        "type": "p",
        "text": "الدورة المقترحة غير منفذة: رفع ثم تحقق ثم معالجة ثم مراجعة ثم نشر ثم تشغيل ثم إيقاف أو حذف."
      },
      {
        "type": "callout",
        "text": "الأسعار: غير متحقق. المعادلات في بيانات التكلفة ظاهرة في هذا القسم."
      }
    ],
    "s10": [
      {
        "type": "p",
        "text": "الطلب والحجز والاستفسار والاتصال مسارات مختلفة في المتطلب، وليست كذلك في التنفيذ المفحوص."
      },
      {
        "type": "p",
        "text": "بعد تغير الكتالوج، الطلب القديم — إن وُجد لاحقًا — يحتفظ بلقطة المتغير. لا جدول طلب اليوم داخل نطاق {{EVD-0018}}."
      }
    ],
    "s11": [
      {
        "type": "p",
        "text": "التحليلات الحالية أحداث شريك لثلاثين يومًا. {{EVD-0013}} يوضح أن trackEvent يقبل partnerId من العميل بلا حارس."
      },
      {
        "type": "callout",
        "text": "هذا عيب منتج مُسجّل. لا يُصلح في GATE-00."
      },
      {
        "type": "list",
        "items": [
          "ما يمكن إعادة استخدامه: عدّ الأحداث للشريك المالك بعد تصحيح المصدر",
          "ما يحتاج تطويرًا: رفض المعرف القادم من الجسم وربطه بالرمز"
        ]
      }
    ],
    "s12": [
      {
        "type": "p",
        "text": "المصادر بتاريخ اطلاع 2026-09-23. ليست اعتمادًا قانونيًا. أثرها على التصميم وأسئلة المختص في الجدول."
      },
      {
        "type": "callout",
        "text": "عبارة تحتاج مراجعة لا تُستخدم هنا بديلًا عن إيراد المصدر."
      }
    ],
    "s13": [
      {
        "type": "p",
        "text": "الموجود القابل لإعادة الاستخدام: كتالوج الشريك، الحارس، اعتماد الطلبات، لوحة المفتاح، الرابط الخارجي."
      },
      {
        "type": "p",
        "text": "التوسعة: متغير، وسيط، فرع، إعلان، فلاتر خادمية. التكامل مع مزود وسائط مؤجل لأن السعر غير متحقق."
      }
    ],
    "s14": [
      {
        "type": "p",
        "text": "لكل متطلب معطى وإجراء ونتيجة وفشل وطريقة اختبار ودليل. المعيار العام السابق أُزيل."
      },
      {
        "type": "p",
        "text": "وجود صف في الجدول لا يعني أن المنتج حقق المعيار. الحالة proposed."
      }
    ],
    "s15": [
      {
        "type": "p",
        "text": "GATE-00 دراسة فقط وقيد المعالجة. بوابات 01 إلى 05 تغطي البيانات والخادم وويب الشركاء والتطبيق والإدارة والتحقق، لا واجهة فيديو وحدها."
      },
      {
        "type": "p",
        "text": "{{REQ-0020}} في قرارات النطاق مرتبط بـ {{DEC-0002}} وليس مرحلة بناء."
      }
    ],
    "s16": [
      {
        "type": "p",
        "text": "لا قرار يُعلَّم معتمدًا من هذه الأداة. {{DEC-0005}} يبقى بانتظار المالك."
      }
    ],
    "s17": [
      {
        "type": "p",
        "text": "كل دليل يذكر ما يثبته وما لا يثبته. روابط المقتطفات نسبية."
      },
      {
        "type": "callout",
        "text": "ملخص CMD-0001 أُبقي كدليل على ضعف النسخة السابقة. السجل الجديد {{EVD-0018}}."
      }
    ],
    "s18": [
      {
        "type": "p",
        "text": "الإصدار السابق 1.0.0-GATE00-study-draft. الإصدار الحالي RC2 — استكمال الدراسة بعد المراجعة."
      },
      {
        "type": "p",
        "text": "الملاحظات السابقة لم تُحذف. حالتها السابقة ظاهرة في سجل REV."
      }
    ],
    "s19": [
      {
        "type": "h3",
        "text": "فحص الحزمة المستقل"
      },
      {
        "type": "p",
        "text": "بعد فك ZIP خارج المشروع: python3 scripts/validate_package.py --root . لا يحتاج مستودع ميرا ولا دار كار. يغطي السجل والبيانات والمراجع والصور والمعرّفات وتطابق JSON مع JavaScript."
      },
      {
        "type": "h3",
        "text": "فحص حداثة الأدلة"
      },
      {
        "type": "p",
        "text": "python3 scripts/verify_evidence_freshness.py --repo /path/to/mira يقارن أدلة fact الثمانية عشر بملفات المستودع. بلا مسار مستودع تكون الحالة BLOCKED ولا تُسمى PASS ولا تُفشل فحص الحزمة."
      },
      {
        "type": "list",
        "items": [
          "EVD-0001 إلى EVD-0026 من نوع fact هي الفحوص التي كانت تفشل خارج المستودع",
          "لا يُحذف دليل لإسكات الفحص",
          "لا تُكتب كلمة PASS ثابتة داخل تقرير الحزمة"
        ]
      },
      {
        "type": "p",
        "text": "لقطات RC3 المقاسة: rc3-mobile-390x844.png وrc3-tablet-768x1024.png وrc3-desktop-1280x900.png. الملف places-plan-desktop-1280.png يبقى 277×445 وليس إثباتًا لعرض 1280."
      }
    ],
    "s20": [
      {
        "type": "p",
        "text": "الملاحظة تبقى ظاهرة بعد معالجتها مع الحالة السابقة والإجراء والدليل والقيود."
      },
      {
        "type": "callout",
        "text": "الحالة معالجة بانتظار المراجعة ليست إغلاقًا. قيد المعالجة يعني أن جزءًا ما زال ناقصًا."
      }
    ],
    "s21": [
      {
        "type": "p",
        "text": "انتقل من بند التكليف إلى القسم ثم الدليل. اكتمال العنوان لا يعني اكتمال المحتوى. الحالة partial تبقى ظاهرة."
      }
    ],
    "s22": [
      {
        "type": "callout",
        "text": "القرار الحالي متطلب معتمد للدراسة عبر {{DEC-0006}}: تكييف المكونات المناسبة داخل ميرا، لا نقل مشروع الأماكن، ولا إعادة بناء كل شيء، مع بقاء دار كار دون تعديل."
      },
      {
        "type": "p",
        "text": "منطق الغرف والليالي لا ينتقل إلى المنتجات أو المواعيد. الدفع الداخلي ما زال {{DEC-0001}}."
      }
    ],
    "s23": [
      {
        "type": "p",
        "text": "وصلت حزمة RC2 بـ 826 ملف مصدر. التفاصيل والبصمة في قسم التنزيلات. الحزمة ليست تطبيق Flutter قابلًا للبناء. اختبارات RC1 لا تثبت تشغيل المنتج."
      }
    ],
    "s24": [
      {
        "type": "p",
        "text": "مراجعة RC1: 697 ملفًا مسجلًا و723 تطابق بصمة، ونسخة 2.zip فيها تغليف macOS زائد. RC2 أعاد الحساب ولم ينسخ الأرقام كأنها نتيجة جديدة."
      }
    ],
    "s25": [
      {
        "type": "p",
        "text": "ملاحظات الحزمة: {{REV-0008}} إلى {{REV-0013}}. المعالجة بانتظار المراجعة ليست اعتمادًا نهائيًا. {{REV-0007}} ما زال مفتوحًا لأنه موضوع لقطات سابق."
      }
    ],
    "s26": [
      {
        "type": "p",
        "text": "المصفوفة أدناه من places-adoption.json. إعادة استخدام كتالوج ميرا عندما يغطي الاحتياج، وتكييف نمط الأماكن، وبناء المشاهدات من جديد."
      }
    ],
    "s27": [
      {
        "type": "p",
        "text": "{{REQ-0024}} و{{REQ-0025}}. إجراءات المنتج: التفاصيل والشراء والمتجر. الشراء المؤكد ليس نقرة رابط."
      }
    ],
    "s28": [
      {
        "type": "p",
        "text": "العيادة والمشغل يستخدمان أسلوب العرض نفسه. الخدمة: تفاصيل، طلب موعد وفق القدرة الفعلية، وموقع. الطلب ليس حجزًا مؤكدًا. شريط التصنيفات والهوية الوردية مشتركان مع تصور المنتجات."
      }
    ],
    "s29": [
      {
        "type": "proposal",
        "text": "{{REQ-0026}}. BoxFit.cover في الأماكن فجوة تكييف لا حكم عطل منشور. الصور المربعة والأفقية داخل إطار عمودي. المحتوى الضعيف يُعلَّم ولا يُنشر بالاستيراد."
      }
    ],
    "s30": [
      {
        "type": "callout",
        "text": "{{REQ-0021}} متطلب أساسي غير منفذ. لا endpoint ولا قاعدة في هذه الجولة. العتبة الزمنية مقترحة في PLC-0008 وليست معتمدة."
      }
    ],
    "s31": [
      {
        "type": "p",
        "text": "{{REQ-0022}} و{{REQ-0023}}. زد والمنصات الأخرى {{PLC-0010}}. التاجر بلا متجر خارجي {{DEC-0007}}."
      }
    ],
    "s32": [
      {
        "type": "p",
        "text": "المراحل الأربع مربوطة بـ {{GATE-06}} حتى {{GATE-09}} دون إلغاء {{GATE-00}} إلى {{GATE-05}}. وجود الخطة لا يأذن ببدء التنفيذ."
      }
    ],
    "s33": [
      {
        "type": "list",
        "items": [
          "{{DEC-0001}} الدفع",
          "{{DEC-0002}} البث",
          "{{DEC-0003}} موافقة المتجر على الإعلان",
          "{{DEC-0004}} منع نسخ الإعلان",
          "{{DEC-0005}} اعتماد الدراسة",
          "{{DEC-0007}} تاجر بلا متجر خارجي",
          "PLC-0008 عتبة المشاهدة",
          "PLC-0010 قدرات المنصات",
          "PLC-0016 المرجع البصري"
        ]
      }
    ],
    "s34": [
      {
        "type": "p",
        "text": "الدليل المحلي {{EVD-0028}} و{{EVD-0029}}. ملف الحزمة الكبيرة على سطح المكتب وغير منسوخ داخل الموقع. الاسم والبصمة في بطاقة التنزيل."
      }
    ],
    "s35": [
      {
        "type": "p",
        "text": "سجل التغييرات العام في القسم 18 يتضمن جولة خطة الأماكن. الملاحظات القديمة لم تُحذف."
      }
    ],
    "s36": [
      {
        "type": "callout",
        "text": "التصورات الثلاثة المعتمدة غير مرفقة. الحالة NEEDS_ASSET ظاهرة في البطاقات. لم يُولَّد بديل."
      },
      {
        "type": "p",
        "text": "أيقونة المشاهدات والعدد الحقيقي متطلب معتمد أُضيف بعد التصورات حتى لو لم تظهر في صورة لاحقة."
      }
    ],
    "s37": [
      {
        "type": "p",
        "text": "التصحيحات التالية تصف أرشيف {{EVD-0030}} كما هو. الوثيقة الأصلية داخل ZIP تبقى، والجدول تصحيح لاحق في هذا الموقع."
      },
      {
        "type": "p",
        "text": "أدلة قبل/بعد التاريخية في evidence/historical/rc2-0059 تغطي تسعة ملفات من أرشيف 0059 فقط."
      }
    ],
    "s38": [
      {
        "type": "p",
        "text": "نطوّر اكتشفي الموجودة في ميرا، لا متجرًا ثانيًا. توجيه المالك أبقى الإغلاق لتطوير تجربة العرض المرئي، وهذا منفصل عن استنتاج الكود السابق."
      },
      {
        "type": "p",
        "text": "نسخة الاختبار مسموحة الآن بالأمر flutter run --dart-define=MIRA_MARKETPLACE_ENABLED=true. الافتراضي يبقى false."
      },
      {
        "type": "p",
        "text": "تسجيل المراحل الخمس وحالة تنفيذ شاشة العرض موجود في قسم مراحل تطوير اكتشفي. أيقونة المشاهدات بلا عدد حقيقي، والفلاتر وربط المتجر وإعلان المشهور لم تبدأ."
      },
      {
        "type": "p",
        "text": "التصورات الثلاثة تبقى {{VIS-PRODUCTS}} و{{VIS-CLINICS}} و{{VIS-SALONS}} بحالة NEEDS_ASSET، وغيابها لا يمنع اختبار اكتشفي الحالية."
      }
    ],
    "s39": [
      {
        "type": "p",
        "text": "هذه البطاقات هي سجل المراحل. حالتها تُقرأ من discover-phases.json ولا تُكرر في نص متعارض. اعتماد المرحلة لا يصدر من اكتمال التنفيذ."
      }
    ]
  },
  "siteAnswers": [
    {
      "q": "ماذا كان ناقصًا في النسخة السابقة؟",
      "a": "أدلة تنفيذ الشركاء والإدارة، وسجل بحث قابل للمراجعة، وفصل طبقات الإيقاف، ومعايير قبول، وخطة تغطي المتطلبات، وعقود فلاتر، ومصادر تنظيمية، ومدقق يرفض البيانات الفاسدة، وعرض موضوعي خارج app.js."
    },
    {
      "q": "ما الذي تحققنا منه الآن؟",
      "a": "مسارات المصدر من الصفحة إلى القاعدة لعزل الكتابة، وفرق مفتاح الإدارة عن رمز الشريك، وغياب نماذج الطلب والمتغير والمشاهير داخل نطاق الأوامر المرفقة. التشغيل الإنتاجي لم يُفحص."
    },
    {
      "q": "ما الأحكام التي صححناها؟",
      "a": "انظر جدول الأحكام التي تغيرت بعد المراجعة في القسم 4. التفعيل لم يعد ENABLED مع SOURCE_ONLY. الشراء الداخلي لم يعد خدمة متوقفة."
    },
    {
      "q": "ما الذي نملكه ويمكن إعادة استخدامه؟",
      "a": "جداول Partner وProduct وService، وحارس الرمز، وعزل assertProductOwner، واعتماد الطلبات، وعميل البوابة ولوحة الإدارة، والرابط الخارجي للشراء."
    },
    {
      "q": "ما الذي يحتاج تطويرًا؟",
      "a": "المتغيرات، الفروع، دورة الوسائط، الفلاتر على متغير واحد، إعلان بلا نسخ سعر، سد تتبع partnerId القادم من العميل، ومسارات الطلب والحجز إن قُرر ذلك."
    },
    {
      "q": "ما القرارات المطلوبة؟",
      "a": "DEC-0001 مكان الدفع، DEC-0002 البث الحي، DEC-0003 اعتماد المتجر، DEC-0004 منع نسخ الإعلان، DEC-0005 اعتماد الدراسة. لا قرار يُغلق هنا."
    },
    {
      "q": "ما مراحل التنفيذ وشروط قبولها؟",
      "a": "GATE-01 إلى GATE-05 في القسم 15. GATE-00 دراسة فقط وما زال قيد المعالجة. REQ-0020 قرار نطاق مرتبط بـ DEC-0002."
    },
    {
      "q": "ما الذي ما زال غير معروف ولماذا؟",
      "a": "قيمة الأعلام في البناء المنشور، وصول API رغم إخفاء الواجهة، ضبط مفتاح الإدارة، سلوك قاعدة الإنتاج، وأسعار مزود الوسائط. السبب: صلاحية هذه المرحلة تمنع التشغيل الحي ولم تُجلب تسعيرة موثوقة."
    }
  ],
  "scopeDecisions": [
    {
      "reqId": "REQ-0020",
      "kind": "scope-decision",
      "decisionId": "DEC-0002",
      "reasonAr": "البث الحي قرار نطاق مستقل. لا يوزَّع كمرحلة تنفيذ ولا يُترك خارج الخطة."
    },
    {
      "reqId": "REQ-0027",
      "kind": "scope-decision",
      "decisionId": "DEC-0007",
      "reasonAr": "التاجر بلا متجر خارجي قرار مفتوح. لا يُفترض شراء داخلي ولا يوزَّع على مرحلة تنفيذ الآن."
    }
  ],
  "placesAdoption": {
    "package": {
      "name": "DAR_PLACES_TO_MIRA_SOURCE_HANDOFF_RC2_20260924_0125.zip",
      "sha256": "60a8d854eb609e1eef11513a1406fd1e262ac809922e889f2e7beecf76ec48e1",
      "location": "سطح المكتب، بجانب ملف sha256 وملف التحقق. غير مضمّن داخل هذا الموقع.",
      "previousName": "DAR_PLACES_TO_MIRA_SOURCE_HANDOFF_20260924_0030.zip",
      "previousSha256": "5d45520b94a3681b7b92af1bfca0617977de39be224b3c666a257bd236dcc99a",
      "previousLocation": "مراجع تطبيق ميرا على سطح المكتب. لم تُستبدل.",
      "sourceFiles": 826,
      "counts": {
        "places-core": 336,
        "flutter-places": 199,
        "host-integration": 126,
        "provider-web": 94,
        "flutter-shared": 47,
        "asset": 21,
        "host-manifest": 3
      },
      "rc1RegisteredSourceFiles": 697,
      "rc1ManifestMatches": 723,
      "note": "أرقام RC1 سجل مراجعة فقط. أعداد RC2 أُعيد حسابها من الفهرس."
    },
    "items": [
      {
        "id": "PLC-0001",
        "section": "decision",
        "domain": "نطاق",
        "status": "متطلب معتمد",
        "title": "لا ننقل مشروع الأماكن كاملًا إلى ميرا",
        "detail": "نختار المكونات المناسبة ونكيفها داخل ملفات ميرا. الموجود في ميرا يُعاد استخدامه إذا غطى الاحتياج. دار كار يبقى مستقلًا ودون تعديل. هذا متطلب دراسة وليس تنفيذًا تم."
      },
      {
        "id": "PLC-0002",
        "section": "decision",
        "domain": "نطاق",
        "status": "متطلب معتمد",
        "title": "منطق الغرف والليالي لا ينتقل تلقائيًا",
        "detail": "حجوزات الفنادق في الأماكن لا تصبح منتجات ميرا ولا مواعيد الخدمات تلقائيًا."
      },
      {
        "id": "PLC-0003",
        "section": "experience",
        "domain": "منتجات",
        "status": "متطلب معتمد",
        "title": "عرض مستقل بشاشة كاملة لكل منتج أو خدمة",
        "detail": "السحب العمودي ينتقل بين العروض. السحب الأفقي يتنقل بين وسائط العرض نفسه. فتح التفاصيل يحافظ على سياق التصفح."
      },
      {
        "id": "PLC-0004",
        "section": "experience",
        "domain": "منتجات",
        "status": "متطلب معتمد",
        "title": "أسلوب العرض نفسه للاكتشاف ولصفحة المتجر",
        "detail": "داخل متجر محدد تقتصر النتائج على عروضه المطابقة للفلاتر. البحث والفلاتر والتصنيفات تتكيف مع المجال."
      },
      {
        "id": "PLC-0005",
        "section": "media",
        "domain": "وسائط",
        "status": "متطلب معتمد",
        "title": "لا فيديو إلزامي لكل منتج",
        "detail": "الصور المربعة والأفقية تُعرض داخل معالجة عمودية تحافظ على ظهور المنتج دون قص مضلل. المحتوى منخفض الجودة يُعلَّم للمراجعة. الاستيراد لا ينشر تلقائيًا. القوالب لا تخترع ألوانًا أو مزايا."
      },
      {
        "id": "PLC-0006",
        "section": "actions",
        "domain": "منتجات",
        "status": "متطلب معتمد",
        "title": "إجراءات المنتج: التفاصيل والشراء والمتجر",
        "detail": "الخدمة: التفاصيل، وطلب موعد أو حجز وفق القدرة الفعلية، والموقع. زر الموعد لا يوحي بتأكيد لم يحدث. الحفظ والمشاركة والتواصل تُحدد حالتها من الكود: في مجموعة أزرار الأماكن المقروءة لم يُثبت زر حفظ أو مشاركة عام."
      },
      {
        "id": "PLC-0007",
        "section": "views",
        "domain": "مشاهدات",
        "status": "متطلب معتمد",
        "title": "أيقونة عين وعدد واضح على كل عرض منشور",
        "detail": "يشمل الفيديو وعروض الصور والمحتوى. التحميل أو التحميل المسبق لا يُحسب مشاهدة. التنقل بين صور العرض نفسه لا ينشئ مشاهدة جديدة تلقائيًا. إذا تعذر جلب العدد لا يُعرض صفر كأنه حقيقة. الأرقام التسويقية المصطنعة ممنوعة."
      },
      {
        "id": "PLC-0008",
        "section": "views",
        "domain": "مشاهدات",
        "status": "مقترح",
        "title": "عتبة الظهور والمدة ما زالتا قيمتين مقترحتين",
        "detail": "مقترح للمراجعة وليس معتمدًا: ظهور 50٪ من مساحة المحتوى لمدة 1 ثانية للفيديو أو الصورة الثابتة. المشاهدة الفريدة مقترحها: أول مشاهدة مؤهلة للعرض لكل فاعل خلال 24 ساعة. إعادة المشاهدة حدث منفصل لا يزيد العدد العام إلا بقاعدة تُعتمد لاحقًا. هذه الأرقام ليست قرارًا معتمدًا."
      },
      {
        "id": "PLC-0009",
        "section": "stores",
        "domain": "ربط خارجي",
        "status": "متطلب معتمد",
        "title": "ربط متجر التاجر الخارجي وعرض منتجاته بأسلوب ميرا",
        "detail": "مثال الدراسة تاجر لديه 200 منتج. التدفق: ربط بالصلاحيات المتاحة، استيراد البيانات والوسائط والخيارات، مراجعة الجودة، مسودات، وسائط خاصة بميرا، معاينة واعتماد ونشر، ثم مزامنة السعر والمخزون والحالة وفق ما يثبته الربط. لا يُطلب 200 فيديو للبدء."
      },
      {
        "id": "PLC-0010",
        "section": "stores",
        "domain": "ربط خارجي",
        "status": "غير متحقق",
        "title": "قدرات زد والمنصات الأخرى غير موثقة هنا",
        "detail": "المصادقة، الحدود، الترقيم، Webhooks، تغيّر السعر، نفاد المخزون، الحذف، إلغاء الربط، نقل المقاس واللون والكمية، وجهة الدفع، وتأكيد البيع تحتاج وثائق رسمية حديثة أو اختبارًا موثقًا. لا يُدّعى دعم أي قدرة الآن."
      },
      {
        "id": "PLC-0011",
        "section": "stores",
        "domain": "دفع",
        "status": "يحتاج قرارًا",
        "title": "الدفع الداخلي والمحفظة والتسويات ليست معتمدة للتنفيذ",
        "detail": "تبقى ضمن DEC-0001. النقر على الشراء أو الإحالة هو ما يمكن تأكيده إذا لم يوجد ربط يثبت الطلب الخارجي. الضغط على الرابط ليس شراءً مؤكدًا."
      },
      {
        "id": "PLC-0012",
        "section": "stores",
        "domain": "مشاهير",
        "status": "متطلب معتمد",
        "title": "إعلان المشهور يرتبط بالعرض الأصلي ولا ينسخ السعر",
        "detail": "يدعم المتاجر والعيادات والمشاغل. يوثق الناشر والمعلن والجهة المقدمة للخدمة أو البائع. مشاهدات الإعلان مستقلة عن مشاهدات العرض الأصلي مع رابط بينهما."
      },
      {
        "id": "PLC-0013",
        "section": "stores",
        "domain": "ربط خارجي",
        "status": "يحتاج قرارًا",
        "title": "التاجر بلا متجر خارجي",
        "detail": "مساره يحتاج تحديدًا. لا تُفترض جاهزية شراء داخلي له."
      },
      {
        "id": "PLC-0014",
        "section": "gaps",
        "domain": "تكييف",
        "status": "موجود في المصدر",
        "title": "تصفح الأماكن الحالي مبني حول الفيديو",
        "detail": "معرض الصور الأفقي في مسار التفاصيل. دمج عدة وسائط داخل العرض العمودي نفسه يحتاج تكييفًا. BoxFit.cover في شاشة الاكتشاف قد يقص محتوى المنتج؛ معيار العرض يخص ميرا. هذه فجوة تكييف وليست حكمًا بأن تطبيق دار كار المنشور معطوب."
      },
      {
        "id": "PLC-0015",
        "section": "gaps",
        "domain": "تكييف",
        "status": "موجود في المصدر",
        "title": "نموذج المكان والوحدة لا يساوي المنتج أو الخدمة",
        "detail": "فلاتر الفنادق لا تنتقل إلى المنتجات. بوابة المزود مرشحة بعد إعادة تقييم المجال والصلاحيات. SafeArea والتقييم الصفري والنصوص التقنية تُراجع عند التكييف."
      },
      {
        "id": "PLC-0016",
        "section": "visual",
        "domain": "تصميم",
        "status": "يحتاج قرارًا",
        "title": "إرفاق المرجع البصري مطلوب",
        "detail": "RC3 بحث ولم يجد صور المنتجات والعيادات والمشاغل. الحالة NEEDS_ASSET. لم تُولَّد بدائل. الأسماء والأسعار في أي تصور لاحق أمثلة."
      }
    ],
    "matrix": [
      {
        "component": "الخلاصة العمودية",
        "source": "places discovery PageView",
        "deps": "video_player",
        "miraUse": "نمط انتقال بين العروض",
        "action": "تكييف",
        "evidence": "PLC-0003",
        "status": "موجود في المصدر"
      },
      {
        "component": "بيانات الاكتشاف",
        "source": "PlacesHttpDiscoveryRepository → DiscoveryApi → /v1/feed أو /v1/discovery/search → ConsumerController → FilterEngineService",
        "deps": "places-core",
        "miraUse": "مرجع عقد الخلاصة لا نسخة الخادم",
        "action": "تكييف",
        "evidence": "EVD-0028",
        "status": "موجود في المصدر"
      },
      {
        "component": "تفاصيل المكان",
        "source": "VenueApi",
        "deps": "وحدة المكان",
        "miraUse": "لا يُستخدم كخلاصة اكتشاف",
        "action": "لا يُنقل كما هو",
        "evidence": "EVD-0028",
        "status": "موجود في المصدر"
      },
      {
        "component": "معرض الصور الأفقي",
        "source": "مسار تفاصيل المكان",
        "deps": "وسائط الوحدة",
        "miraUse": "وسائط داخل العرض نفسه",
        "action": "تكييف",
        "evidence": "PLC-0014",
        "status": "موجود في المصدر"
      },
      {
        "component": "فلاتر الفندق",
        "source": "فلاتر الأماكن",
        "deps": "وحدات وحجوزات",
        "miraUse": "لا تنتقل إلى المنتجات",
        "action": "بناء معايير مجال في ميرا",
        "evidence": "PLC-0015",
        "status": "متطلب معتمد"
      },
      {
        "component": "بوابة المزود",
        "source": "places-provider-web",
        "deps": "صلاحيات المزود",
        "miraUse": "نمط لوحة بعد إعادة تقييم",
        "action": "تكييف",
        "evidence": "PLC-0015",
        "status": "موجود في المصدر"
      },
      {
        "component": "كتالوج ميرا الحالي",
        "source": "Partner وProduct وService",
        "deps": "حارس الشريك",
        "miraUse": "أساس إعادة الاستخدام",
        "action": "إعادة استخدام",
        "evidence": "CAP-0001",
        "status": "موجود في المصدر"
      },
      {
        "component": "المشاهدات",
        "source": "غير مفترضة في كود الأماكن",
        "deps": "لا endpoint في هذه الجولة",
        "miraUse": "متطلب جديد",
        "action": "بناء جديد",
        "evidence": "PLC-0007",
        "status": "متطلب معتمد"
      },
      {
        "component": "الخط Cairo",
        "source": "assets/fonts/Cairo-Variable.ttf",
        "deps": "pubspec",
        "miraUse": "مرجع أصل فقط",
        "action": "لا نسخ أعمى",
        "evidence": "RC2",
        "status": "موجود في المصدر"
      },
      {
        "component": "خرائط ومفتاح Google",
        "source": "app_config منقح داخل الحزمة",
        "deps": "خدمة خارجية",
        "miraUse": "لا يُنقل المفتاح",
        "action": "مستبعد",
        "evidence": "EVD-0028",
        "status": "معالجة بانتظار المراجعة"
      }
    ],
    "viewsSpec": [
      {
        "topic": "الظهور مقابل المشاهدة المؤهلة",
        "text": "الظهور: العنصر دخل منطقة العرض. المشاهدة المؤهلة: تجاوز عتبة لم تُعتمد بعد. التحميل المسبق ليس مشاهدة.",
        "status": "مقترح"
      },
      {
        "topic": "الخلفية والمحتوى المحجوب والتبديل السريع",
        "text": "التطبيق في الخلفية أو المحتوى المغطى أو المرور الأسرع من العتبة لا يُسجل مشاهدة مؤهلة.",
        "status": "مقترح"
      },
      {
        "topic": "التفرد وإعادة الإرسال",
        "text": "مفتاح idempotency من الخادم. إعادة إرسال الحدث نفسه لا تزيد العدد. dedup على هوية العرض والفاعل والنافذة الزمنية بعد اعتمادها.",
        "status": "مقترح"
      },
      {
        "topic": "تحقق الخادم",
        "text": "الخادم يتحقق من هوية العرض وملكيته. العميل لا يرسل العدد النهائي.",
        "status": "متطلب معتمد"
      },
      {
        "topic": "المعدل والتلاعب",
        "text": "حدود معدل ورفض الأنماط غير البشرية. لا أرقام تسويقية بديلة.",
        "status": "متطلب معتمد"
      },
      {
        "topic": "التجميع والتأخر",
        "text": "العدد العام قد يتأخر. الواجهة تميز بين غير متاح وبين صفر حقيقي.",
        "status": "متطلب معتمد"
      },
      {
        "topic": "الخصوصية والاحتفاظ",
        "text": "لا تُعرض هوية المشاهد للتاجر. مدة الاحتفاظ بالحدث الخام تحتاج قرارًا. العدد المجمع يكفي للعرض العام.",
        "status": "يحتاج قرارًا"
      },
      {
        "topic": "دلالة العدد",
        "text": "العدد الظاهر للعامة وتقرير التاجر للعرض نفسه يعنيان المشاهدات المؤهلة ذاتها، مع تفصيل أوضح في لوحة التاجر.",
        "status": "متطلب معتمد"
      }
    ],
    "events": [
      {
        "event": "عرض المحتوى",
        "meaning": "ظهور في منطقة العرض",
        "status": "مقترح"
      },
      {
        "event": "مشاهدة مؤهلة",
        "meaning": "بعد العتبة المعتمدة لاحقًا",
        "status": "مقترح"
      },
      {
        "event": "فتح التفاصيل",
        "meaning": "انتقال مع حفظ سياق التصفح",
        "status": "متطلب معتمد"
      },
      {
        "event": "الحفظ",
        "meaning": "إن وُجد الفعل في المنتج",
        "status": "يحتاج قرارًا"
      },
      {
        "event": "المشاركة",
        "meaning": "إن وُجد الفعل في المنتج",
        "status": "يحتاج قرارًا"
      },
      {
        "event": "التواصل",
        "meaning": "بدء اتصال أو رسالة، ليس إتمام صفقة",
        "status": "مقترح"
      },
      {
        "event": "النقر على الشراء",
        "meaning": "نقرة أو إحالة فقط",
        "status": "متطلب معتمد"
      },
      {
        "event": "بدء طلب موعد",
        "meaning": "بدء مسار، وليس حجزًا مؤكدًا",
        "status": "متطلب معتمد"
      },
      {
        "event": "طلب مؤكد",
        "meaning": "يحتاج إثباتًا من نظام الطلب. غير متاح للرابط الخارجي وحده.",
        "status": "يحتاج قرارًا"
      }
    ],
    "stages": [
      {
        "id": "PLC-STAGE-01",
        "gate": "GATE-06",
        "title": "استكمال حزمة المصدر",
        "status": "معالجة بانتظار المراجعة",
        "goal": "اعتماديات ناقصة وتوثيق وتحقق مستقل وحزمة RC2",
        "inScope": "الملفات الناقصة والمدقق والفحوص السلبية",
        "outScope": "تنفيذ تجربة ميرا وتعديل دار كار",
        "acceptance": "لا نواقص صامتة داخل النطاق، والبصمات والفحوص السلبية صحيحة",
        "evidence": "حزمة RC2 وسجل الفحوص السلبية",
        "blocker": "المراجعة البشرية لم تُغلق"
      },
      {
        "id": "PLC-STAGE-02",
        "gate": "GATE-07",
        "title": "تحديث دراسة ميرا وعقود التكييف",
        "status": "معالجة بانتظار المراجعة",
        "goal": "جرد قرارات إعادة الاستخدام ونموذج العرض والمشاهدات والربط",
        "inScope": "هذا الموقع والبيانات",
        "outScope": "تنفيذ التطبيق قبل مراجعة المرحلة",
        "acceptance": "كل متطلب له حالة ودليل أو قرار، وخطة ملفات قابلة للمراجعة",
        "evidence": "أقسام الموقع 22 إلى 35",
        "blocker": "المرجع البصري غير مرفق، وقدرات المنصات غير متحققة"
      },
      {
        "id": "PLC-STAGE-03",
        "gate": "GATE-08",
        "title": "تجربة العرض داخل ميرا",
        "status": "مقترح",
        "goal": "شاشة كاملة ووسائط وتصنيفات وبحث وفلاتر وتفاصيل وهوية ميرا",
        "inScope": "واجهة تجريبية ببيانات اختبار",
        "outScope": "يبدأ فقط بعد مراجعة هذه المرحلة وحزمة إثبات خاصة بها",
        "acceptance": "RTL وSafeArea وسلامة الإيماءات وظهور المنتج وتوقف الصوت وإدارة الموارد وحالات الخطأ والفراغ والإتاحة",
        "evidence": "ZIP وأدلة جهاز لاحقًا",
        "blocker": "غير مأذون الآن"
      },
      {
        "id": "PLC-STAGE-04",
        "gate": "GATE-09",
        "title": "لوحة التاجر والبيانات والمشاهدات",
        "status": "مقترح",
        "goal": "إدارة المحتوى والربط والمراجعة والنشر والإحصاءات",
        "inScope": "لوحة وإحصاءات بعد اعتماد العقد",
        "outScope": "لا endpoint للمشاهدات في هذه الجولة",
        "acceptance": "عزل المتاجر وصحة الربط وعدم تكرار الأحداث وصدق الأعداد ومعالجة فشل المزامنة",
        "evidence": "ZIP لاحق",
        "blocker": "غير مأذون الآن"
      }
    ]
  },
  "visualReferences": {
    "viewsNoteAr": "أيقونة المشاهدات والعدد الحقيقي متطلب معتمد أُضيف بعد هذه التصورات. إن لم تكن الأيقونة ظاهرة في صورة لاحقة، فهذا لا يلغي المتطلب.",
    "searchNoteAr": "بُحث في مجلد الدراسة وملفات سطح المكتب الظاهرة. لم تُعثر صور بعنوان شاشة المنتجات أو العيادات أو المشاغل. صورة واتساب الموجودة على سطح المكتب شاشة إنشاء إعلان وليست أحد التصورات الثلاثة، ولم تُدرج.",
    "items": [
      {
        "id": "VIS-PRODUCTS",
        "titleAr": "شاشة المنتجات",
        "descriptionAr": "تصور مرجعي لعرض المنتجات بشاشة كاملة مع البحث والفلاتر بالأعلى وأزرار الإجراءات بالأسفل.",
        "status": "NEEDS_ASSET",
        "path": "",
        "sha256": "",
        "disclaimerAr": "عند توفر الأصل سيُعرض كنسبة كاملة دون قص، وبوصفه تصورًا مرجعيًا لا دليل تشغيل.",
        "searchNoteAr": "NEEDS_ASSET: الملف غير متوفر في النطاق الذي فُحص."
      },
      {
        "id": "VIS-CLINICS",
        "titleAr": "شاشة العيادات",
        "descriptionAr": "تصور مرجعي لخدمات العيادات بنفس أسلوب العرض، مع إجراء موعد لا يوحي بتأكيد لم يحدث.",
        "status": "NEEDS_ASSET",
        "path": "",
        "sha256": "",
        "disclaimerAr": "الأسماء والأسعار في أي تصور لاحق أمثلة وليست بيانات تجارية.",
        "searchNoteAr": "NEEDS_ASSET: الملف غير متوفر في النطاق الذي فُحص."
      },
      {
        "id": "VIS-SALONS",
        "titleAr": "شاشة المشاغل",
        "descriptionAr": "تصور مرجعي للمشاغل بهوية ميرا الوردية وشريط تصنيفات بصري.",
        "status": "NEEDS_ASSET",
        "path": "",
        "sha256": "",
        "disclaimerAr": "لا يُعد تشغيلًا للمنتج ولا ربطًا بمنصة خارجية.",
        "searchNoteAr": "NEEDS_ASSET: الملف غير متوفر في النطاق الذي فُحص."
      }
    ]
  },
  "sourceCorrections": {
    "originalArchive": {
      "name": "DAR_PLACES_TO_MIRA_SOURCE_HANDOFF_RC2_20260924_0125.zip",
      "sha256": "60a8d854eb609e1eef11513a1406fd1e262ac809922e889f2e7beecf76ec48e1",
      "unchanged": true
    },
    "historicalArchive": {
      "name": "DAR_PLACES_TO_MIRA_SOURCE_HANDOFF_RC2_20260924_0059.zip",
      "sha256": "fa752eea3627e88b62f369aa6af0e661891d84ad845fc4613cb6b3333617119d",
      "hashFiles": [
        "evidence/historical/rc2-0059/source_file_hashes_before.txt",
        "evidence/historical/rc2-0059/source_file_hashes_after.txt"
      ],
      "coverage": "تسعة ملفات فقط، وليست إثباتًا لثبات المستودع كاملًا"
    },
    "historicalNoteAr": "ملفات البصمة قبل/بعد نُسخت من أرشيف 0059 إلى أدلة هذا الموقع. أرشيف 0125 لم يُعد تغليفه.",
    "corrections": [
      {
        "id": "SRC-CORR-001",
        "topic": "مسار الخلاصة",
        "originalFile": "DEPENDENCY_MAP.json chain browse-media",
        "originalStatement": "السلسلة تمر من places_live_core.dart إلى venue_api.dart ثم وحدات catalog.",
        "correctedStatement": "الخلاصة: PlacesHttpDiscoveryRepository ثم DiscoveryApi ثم GET /v1/feed أو POST /v1/discovery/search ثم ConsumerController.feed ثم CatalogService.feed ثم FilterEngineService.feedAdapter.",
        "status": "تصحيح لاحق موثق؛ الأرشيف الأصلي بقي كما هو"
      },
      {
        "id": "SRC-CORR-002",
        "topic": "تفاصيل المكان",
        "originalFile": "DEPENDENCY_MAP.json chain details و venue_api.dart",
        "originalStatement": "VenueApi يخدم التفاصيل والمعرض.",
        "correctedStatement": "هذا المسار يبقى على VenueApi وGET /v1/venues/:id. التصحيح لا يُعمم على كل السلاسل.",
        "status": "مثبت ويبقى كما هو"
      },
      {
        "id": "SRC-CORR-003",
        "topic": "التنقيح",
        "originalFile": "EXCLUSIONS_AND_REDACTIONS.json",
        "originalStatement": "النص يقول إنه لم تُعد كتابة الملفات في هذه الجولة.",
        "correctedStatement": "evidence/redaction_rc2.json داخل الأرشيف نفسه يثبت تنقيح app_config.dart فقط، باستبدال مفتاح الخرائط بنص REDACTED_GOOGLE_MAPS_API_KEY.",
        "status": "تعارض موثق؛ الأرشيف لم يُعدَّل"
      }
    ]
  },
  "discoverPlan": {
    "titleAr": "تفعيل اختبار اكتشفي وخطة الدمج",
    "ownerDirectiveAr": "سبب الإبقاء على الإغلاق، بحسب توجيه مالك المشروع، هو تطوير اكتشفي إلى تجربة العرض المرئي. هذا توجيه منتج، وهو منفصل عن الاستنتاج السابق من الكود بأن العلم الافتراضي false ولا توجد وثيقة تشغيل تشرح الإيقاف.",
    "testAuthorizationAr": "صُرّح بتفعيل نسخة الاختبار الآن عبر --dart-define=MIRA_MARKETPLACE_ENABLED=true. القيمة الافتراضية في الكود تبقى false، ولم يُفعَّل العلم لبناء الإنتاج.",
    "run": {
      "name": "MIRA Discover Test",
      "command": "flutter run --dart-define=MIRA_MARKETPLACE_ENABLED=true",
      "script": "scripts/run_mira_discover_test.sh",
      "launchConfig": ".vscode/launch.json",
      "defaultRemainsFalse": true
    },
    "independenceAr": [
      "ميرا مستقلة عن دار كار والأماكن في الكود والخدمات والبيانات والنشر.",
      "أي دمج لاحق يأخذ نسخة مستقلة داخل مستودع ميرا. لا روابط ملفات ولا symlinks ولا Git submodules ولا حزمة داخلية مشتركة.",
      "اكتشفي لا تتصل بباك إند الأماكن ولا بقاعدة بياناتها ولا بمفاتيحها، ولا يحتاج تشغيلها بناء دار كار.",
      "هذه الجولة لا تدمج مكونات الأماكن."
    ],
    "dataSource": {
      "probedAt": "2026-09-24T03:07:00+03:00",
      "endpoint": "https://mira-api-n4p3.onrender.com/api/v1/marketplace/partners",
      "result": "HTTP 200 من خادم ميرا. الأسماء هي بذرة marketplace.seed وليست متاجر شركاء مُدخلة من البوابة.",
      "localFallback": "إذا تعذر طلب التفاصيل يُقرأ الكتالوج المحلي مباشرة. وصف النقل مرتبط بنتيجة ذلك الطلب، والعلامة التجريبية معلنة في الكتالوج لا مستنتجة من الأسماء."
    },
    "functions": [
      {
        "id": "ACT-0001",
        "nameAr": "فتح اكتشفي من الرئيسية",
        "state": "منفذة وكانت محجوبة",
        "detailAr": "البطاقة تفتح DiscoverHubScreen. مع العلم تُعرض الأقسام الثلاثة بدل شاشة الانطلاق قريبًا.",
        "tested": "اختبار ودجت مع العلم وبدونه"
      },
      {
        "id": "ACT-0002",
        "nameAr": "قوائم الماركات والعيادات والصالونات",
        "state": "منفذة وتحتاج أن يُفهم أن البيانات بذرة",
        "detailAr": "PartnerListScreen يستدعي خادم ميرا ثم يسقط إلى البذرة المحلية. الخادم أعاد البذرة نفسها.",
        "tested": "فحص HTTP للقوائم الثلاث، واختبار سقوط الخادم إلى البذرة المحلية"
      },
      {
        "id": "ACT-0003",
        "nameAr": "صفحة الجهة وتفاصيل المنتج",
        "state": "منفذة",
        "detailAr": "النقر يفتح صفحة الجهة. أيقونة الرابط الخارجي تبقى للماركات. تفاصيل المنتج تعرض السعر ورابط المتجر وتصرّح أن الفتح ليس شراءً مؤكدًا.",
        "tested": "اختبار ودجت لتفاصيل المنتج، واستجابة الخادم لمنتجات لوريال"
      },
      {
        "id": "ACT-0004",
        "nameAr": "تفاصيل الخدمة والحجز",
        "state": "جزئية",
        "detailAr": "التفاصيل والسعر والمدة موجودة. bookingEnabled قيمته false في البذرة. الزر يعرض «الحجز قريباً» ورسالة انتظار، وليس «تم الحجز».",
        "tested": "اختبار ودجت يمنع نص إتمام الحجز، واستجابة الخادم لخدمات عيادة نور"
      },
      {
        "id": "ACT-0005",
        "nameAr": "الصور",
        "state": "جزئية",
        "detailAr": "العرض الحالي رموز تعبيرية. لا صور منتجات في هذه البذرة.",
        "tested": "قراءة واجهة التفاصيل والكتالوج"
      },
      {
        "id": "ACT-0006",
        "nameAr": "الاتصال والموقع",
        "state": "غير منفذة",
        "detailAr": "لا مسار هاتف أو خريطة داخل شاشات اكتشفي الحالية.",
        "tested": "بحث في ملفات marketplace عن tel أو خريطة ولم يوجد"
      },
      {
        "id": "ACT-0007",
        "nameAr": "المطابقة حسب تحليل البشرة",
        "state": "منفذة وتحتاج تقرير بشرة",
        "detailAr": "MarketplaceMatchedSection على شاشة الروتين، وتستخدم الخادم ثم البذرة المحلية. لم تُختبر على الجهاز في هذه الجولة.",
        "tested": "قراءة الاستدعاء في skin_routine_screen.dart"
      },
      {
        "id": "ACT-0008",
        "nameAr": "المشاهدات",
        "state": "غير منفذة",
        "detailAr": "متطلب لاحق. لم يُضف رقم وهمي.",
        "tested": "لا عداد في شاشات اكتشفي الحالية"
      }
    ],
    "fileMap": [
      {
        "id": "MAP-0001",
        "functionAr": "علم الإغلاق والاختبار",
        "unit": "lib/core/config/mira_features.dart",
        "responsibilityAr": "القيمة الافتراضية false وخيار البناء true",
        "calledByAr": "المسارات والرئيسية وشاشة اكتشفي",
        "decision": "استخدام كما هي",
        "reasonAr": "الآلية موجودة. لا تُقلب القيمة الافتراضية من أجل الاختبار.",
        "affectedAr": ".vscode/launch.json وscripts/run_mira_discover_test.sh",
        "testAr": "discover_activation_test.dart يُشغَّل مرتين"
      },
      {
        "id": "MAP-0002",
        "functionAr": "مسارات اكتشفي",
        "unit": "lib/features/marketplace/presentation/marketplace_routes.dart",
        "responsibilityAr": "البوابة والقوائم والتفاصيل",
        "calledByAr": "lib/main.dart",
        "decision": "استخراج مكون",
        "reasonAr": "نفس السلوك السابق في ملف قابل للاختبار دون إعادة هيكلة التطبيق.",
        "affectedAr": "lib/main.dart",
        "testAr": "اختبار نوع الصفحة عند إغلاق العلم وفتحه"
      },
      {
        "id": "MAP-0003",
        "functionAr": "الكتالوج",
        "unit": "lib/features/marketplace/data/repositories/marketplace_repository_impl.dart",
        "responsibilityAr": "خادم ميرا ثم البذرة المحلية",
        "calledByAr": "قوائم الجهات وصفحة الجهة والمطابقة",
        "decision": "تطوير",
        "reasonAr": "إظهار مصدر البيانات حتى لا تُعرض البذرة كمتاجر حقيقية.",
        "affectedAr": "marketplace_data_banner.dart وpartner_list_screen.dart",
        "testAr": "سقوط Dio إلى البذرة المحلية"
      },
      {
        "id": "MAP-0004",
        "functionAr": "واجهة الخادم",
        "unit": "mira-api/src/marketplace/marketplace.controller.ts",
        "responsibilityAr": "قوائم الجهات والتفاصيل والمطابقة",
        "calledByAr": "MarketplaceApiDataSource",
        "decision": "استخدام كما هي",
        "reasonAr": "لا يُنشأ باك إند تجارة موازٍ.",
        "affectedAr": "لا تعديل على الخادم في هذه الجولة",
        "testAr": "فحص HTTP للقوائم والتفاصيل"
      },
      {
        "id": "MAP-0005",
        "functionAr": "تجربة العرض المرئي لاحقًا",
        "unit": "غير موجودة بعد داخل ميرا",
        "responsibilityAr": "عرض كامل وفيديو وفلاتر ومشاهدات",
        "calledByAr": "لا مستدعٍ حالي",
        "decision": "إضافة جديدة لاحقًا",
        "reasonAr": "لا تُنسخ بيانات السعر إلى سجل فيديو ثانٍ، ولا تُدمج الأماكن في هذه الجولة.",
        "affectedAr": "لا ملفات جديدة للعرض المرئي الآن",
        "testAr": "لا اختبار منتج للمشاهدات لأنها غير منفذة"
      }
    ]
  },
  "discoverPhases": {
    "titleAr": "مراحل تطوير اكتشفي",
    "ownerConfirmationAr": "أكّد المالك أنه اختبر أيقونات اكتشفي على الجهاز وأن النقر والتنقل يعملان. هذا تأكيد للنقر والتنقل فقط، ولا يثبت الحجز ولا المشاهدات ولا التكاملات ولا شاشة العرض الجديدة.",
    "progressBasisAr": "إذا ظهر عدّ للمهام فهو عدد المهام التي حالتها «بانتظار المراجعة» من مهام تلك المرحلة. هذا العدّ ليس نسبة إنجاز تقديرية ولا يعني اعتماد المرحلة.",
    "placesCopyAr": "لم تُنسخ ملفات من حزمة مصدر الأماكن في هذه الجولة. شاشة العرض بُنيت داخل ميرا بـ PageView وvideo_player. لا يوجد استيراد من دار كار أو الأماكن ولا رابط ملفات ولا submodule.",
    "phases": [
      {
        "id": "PH-1",
        "number": 1,
        "nameAr": "شاشة العرض الجديدة",
        "goalAr": "فيديو وصور بشاشة عرض كاملة داخل اكتشفي، مع السحب بين العروض ووسائط العرض الواحد، وموضع لأيقونة المشاهدات دون عدد.",
        "inScopeAr": [
          "مسار العرض المرئي من اكتشفي عند تفعيل علم الاختبار",
          "سحب عمودي بين العروض وأفقي بين وسائط العرض نفسه",
          "ربط العرض بمعرّفات المنتج أو الخدمة والجهة الموجودة",
          "عينات وسائط معزولة وموسومة، وحالة فشل مع إعادة محاولة",
          "تشغيل الفيديو الظاهر فقط عبر منفذ يمكن استبداله في الاختبار"
        ],
        "outOfScopeAr": [
          "احتساب المشاهدات",
          "البحث والفلاتر وصفحة المتجر",
          "بوابة إدارة الوسائط والاستيراد",
          "الدفع والحجز المؤكد والبث وزد"
        ],
        "tasks": [
          {
            "id": "P1-T1",
            "nameAr": "مسار العرض ونقطة الدخول من اكتشفي",
            "status": "بانتظار المراجعة"
          },
          {
            "id": "P1-T2",
            "nameAr": "السحب العمودي والأفقي وفتح التفاصيل بالمعرّف نفسه",
            "status": "بانتظار المراجعة"
          },
          {
            "id": "P1-T3",
            "nameAr": "ملاءمة الصور والعينات المعزولة وحالة الفشل",
            "status": "بانتظار المراجعة"
          },
          {
            "id": "P1-T4",
            "nameAr": "تشغيل video_player وإيقافه على جهاز أو محاكي",
            "status": "قيد التنفيذ"
          },
          {
            "id": "P1-T5",
            "nameAr": "أيقونة العين دون رقم يوحي بإحصاء",
            "status": "بانتظار المراجعة"
          }
        ],
        "expectedAr": "تجربة عرض قابلة للاختبار مرتبطة بالكيانات الحالية، مع سلامة الوسائط والتنقل وحالات التحميل والفشل وأدلة تنفيذ واختبار.",
        "actualAr": "سُجّلت مراجعة RC2 ومهام RC3. صُحّح اختبار التكامل للمشغّل بعد التغطية والخلفية وRTL. أُضيفت 10 اختبارات على AssetVideoPort نفسه مع حقن مصنع المشغّل. أُصلح الخروج من شاشة العروض الفارغة. تشغيل video_player على iPhone iOS 26.6: البناء نجح لكن VM Service لم يُكتشف خلال 60 ثانية في هذه الجولة (نفس عائق RC2). لا لقطات تطبيق جديدة ولا تسجيل فيديو من الجهاز في RC3.",
        "status": "قيد التنفيذ",
        "dependenciesAr": "علم MIRA_MARKETPLACE_ENABLED ومعرّفات الكتالوج الحالي. لا تعتمد على مخطط جديد.",
        "notesAr": "عينات الاختبار المعزولة موجودة في الكتالوج. المراحل 2–5 لم تبدأ. الاعتماد غير صادر. مراجعة RC1 محفوظة. مراجعة RC2 مسجّلة 2026-09-25.",
        "blockersAr": "P1-RC3-04: VM Service غير مكتشف بعد flutter test على iPhone 00008110-00191986268BA01E. يلزم إبقاء الجهاز غير مقفل والتطبيق في المقدمة أثناء الاختبار، أو تشغيل يدوي موثّق.",
        "acceptanceAr": "تجربة عرض فعلية قابلة للاختبار، مرتبطة بالكيانات الحالية، مع سلامة الوسائط والتنقل وحالات التحميل والفشل، وأدلة تنفيذ واختبار.",
        "evidenceIds": [
          "EVD-0036",
          "EVD-0039",
          "EVD-0040",
          "EVD-0041",
          "EVD-0042",
          "EVD-0043",
          "EVD-0044"
        ],
        "reviewPackage": "deliveries/RC1.txt",
        "verificationReport": "deliveries/RC1-VERIFICATION.txt",
        "reviewResultAr": "قبول تسجيل المراحل كأساس للمتابعة. المرحلة الأولى غير معتمدة حتى إغلاق ملاحظات P1-RC2-01 إلى P1-RC2-05. تطابقت بصمة ZIP ad4399482c891b28850efa12dca36cebcc9944f0103c74a547d05994f06551b4، وسجل 150 ملفًا خارجيًا و115 ملفًا داخليًا. المراحل الخمس بطاقات مستقلة. المرحلة 1 قيد التنفيذ والمراحل 2–5 لم تبدأ.",
        "reviewDate": "2026-09-24",
        "reviewPackageLabel": "سجل تسليم RC1",
        "verificationReportLabel": "تقرير تحقق RC1",
        "approvalAr": "غير معتمدة",
        "corrections": [
          {
            "id": "P1-RC2-01",
            "titleAr": "إيقاف الفيديو عند فتح التفاصيل وتغطية الشاشة",
            "problemAr": "فتح التفاصيل كان ينتقل دون إيقاف الفيديو، ودورة حياة التطبيق لا تغطي مسارًا يغطي الشاشة داخل التطبيق.",
            "impactAr": "قد يستمر صوت الفيديو أو تشغيله خلف شاشة التفاصيل أو بعد الخروج.",
            "taskAr": "إيقاف المشغّل عند التغطية، واستئناف الوسيط النشط فقط عند الرجوع إذا كان التطبيق في المقدمة، ومنع استئناف بعد الإغلاق.",
            "relatedTaskIds": [
              "P1-T2",
              "P1-T4"
            ],
            "status": "قيد التنفيذ",
            "resultAr": "الآلية مضافة: RouteAware على miraRouteObserver، والإيقاف عند التغطية والخلفية، وrelease عند الإغلاق. اختبار الودجت أثبت نداء الإيقاف والاستئناف على البديل.",
            "evidenceAr": "اختبار ودجت ببديل: فتح تفاصيل المنتج يوقف التشغيل والرجوع يستأنف الفتحة النشطة. فتح تفاصيل الخدمة من فيديو يوقف المشغّل. مغادرة الشاشة أثناء التهيئة لا تبدأ التشغيل.",
            "remainingAr": "لم يُثبت توقف VideoPlayerController الحقيقي لأن اتصال الجهاز انقطع قبل إكمال السيناريو."
          },
          {
            "id": "P1-RC2-02",
            "titleAr": "فشل الفيديو وإعادة المحاولة",
            "problemAr": "تهيئة المشغّل وتشغيله لم يوصلا الخطأ إلى الواجهة، وقد تبقى حالة التجهيز دون مخرج. إعادة المحاولة السابقة كانت لفشل صورة مصطنع.",
            "impactAr": "انتظار غير منته، أو خطأ وسيط سابق يظهر فوق وسيط لاحق.",
            "taskAr": "حالات تحميل وجاهز وفشل، زر إعادة المحاولة يعيد تهيئة الوسيط نفسه بعد التنظيف، ونقل الفشل المصطنع إلى الاختبار.",
            "relatedTaskIds": [
              "P1-T3"
            ],
            "status": "بانتظار المراجعة",
            "resultAr": "AssetVideoPort يلتقط فشل التهيئة ومهلة 12 ثانية وخطأ المشغّل بعد الجاهزية. الواجهة تعرض «تعذر تشغيل الفيديو» و«إعادة المحاولة». الكتالوج لم يعد يفشل خدمة عند كل دخول.",
            "evidenceAr": "اختبار ودجت: فشل تهيئة ثم إعادة محاولة ناجحة ثم فشل متكرر. خطأ تشغيل بعد الجاهزية منفصل عن «تعذر تحميل الصورة». الانتقال أثناء الفشل لا يترك نص الفيديو على صورة. السجل: evidence/tests/rc2_widget_test.txt",
            "remainingAr": "لا شيء داخل مسار التصفح. فشل التهيئة الحقيقي لم يُحقن في مشغّل الجهاز."
          },
          {
            "id": "P1-RC2-03",
            "titleAr": "منع تداخل عمليات التشغيل",
            "problemAr": "عمليات الإرفاق والفصل والتهيئة غير المتزامنة لم تتحقق بعد الانتظار من أن الطلب ما زال صالحًا.",
            "impactAr": "طلب قديم قد يشغّل فيديو بعد تغيّر الاختيار، أو يوقف مشغّلًا أحدث.",
            "taskAr": "ربط الملكية بالعرض والوسيط، ورمز جيل يمنع تشغيل طلب قديم أو إيقاف مشغّل أحدث، دون تعريف العرض بمسار الملف وحده.",
            "relatedTaskIds": [
              "P1-T2",
              "P1-T4"
            ],
            "status": "بانتظار المراجعة",
            "resultAr": "PresentationSlot يضم معرّف العرض وفهرس الوسيط. رمز الجيل يُزاد عند تبديل الطلب وrelease. إيقاف قديم لا يتخلص من مشغّل أحدث. لا تحديث بعد التخلص.",
            "evidenceAr": "اختبارات ببديل ذي بوابات تأخير: انتقال سريع من فيديو إلى فيديو، ومن فيديو قيد التهيئة إلى صورة، والعودة، والملف نفسه في عرضين، ومغادرة الشاشة أثناء التهيئة، والخلفية أثناء التهيئة. السجل: evidence/tests/rc2_widget_test.txt",
            "remainingAr": "لا شيء في اختبارات الترتيب المتأخر. إثبات المشغّل الحقيقي في P1-RC2-04."
          },
          {
            "id": "P1-RC2-04",
            "titleAr": "التشغيل الفعلي وسلامة العرض",
            "problemAr": "اختبارات الودجت بالبديل لا تثبت video_player الحقيقي.",
            "impactAr": "قد تنجح الاختبارات بينما المشغّل الحقيقي لا يعمل أو لا يتوقف.",
            "taskAr": "تشغيل شاشة العرض بمشغّل حقيقي على جهاز أو محاكي مع العلم، وإثبات السحب والتفاصيل والإيقاف والتقاط صور وتسجيل.",
            "relatedTaskIds": [
              "P1-T4"
            ],
            "status": "قيد التنفيذ",
            "resultAr": "المحاكي iPhone 16 / iOS 26.5: فشل البناء لأن TensorFlowLiteC مبني للجهاز فقط. الجهاز fayez’s iPhone / iOS 26.6: نجح بناء Xcode واتصل flutter drive على المنفذ 8888 ثم قطع النظام الاتصال والاختبار لم يطبع حالة المشغّل. لا صور ولا تسجيل لشاشة العرض.",
            "evidenceAr": "evidence/tests/rc2_device_run.txt",
            "remainingAr": "تشغيل يبقى في مقدمة الجهاز حتى تكتمل تأكيدات المشغّل والسحب واللقطات."
          },
          {
            "id": "P1-RC2-05",
            "titleAr": "روابط الحزمة وتقرير التحقق",
            "problemAr": "حقلا حزمة المراجعة وتقرير التحقق تُركا فارغين في RC1 لأن المراجعة لم تكن قد صدرت.",
            "impactAr": "وجود الحزمة لا يظهر في البطاقة، ويُخلط بين رابط التسليم واعتماد المرحلة.",
            "taskAr": "تسجيل RC1 ثم RC2 بالاسم والتاريخ والحالة والروابط والبصمة المتاحة، مع فصل نتيجة المراجعة عن الاعتماد.",
            "relatedTaskIds": [
              "P1-T1"
            ],
            "status": "بانتظار المراجعة",
            "resultAr": "RC1 مسجّل باسمه وبصمته ونتيجة المراجعة في deliveries/RC1.txt دون نسخ ZIP. RC2 مسجّل في deliveries/RC2.txt دون بصمة نهائية. الاعتماد حقل مستقل ويبقى غير معتمدة.",
            "evidenceAr": "deliveries/RC1.txt وdeliveries/RC1-VERIFICATION.txt وdeliveries/RC2.txt. فحص الفك يُسجّل خارج الحزمة في VERIFICATION.txt.",
            "remainingAr": "لا شيء داخل البطاقة. تأكيد الفك خارج الحزمة."
          },
          {
            "id": "P1-RC3-01",
            "titleAr": "تصحيح اختبار التشغيل والرجوع والخلفية",
            "problemAr": "اختبار التكامل كان يحتفظ بمرجع VideoPlayer قبل التفاصيل بينما التنفيذ يتخلص من المشغّل عند التغطية.",
            "impactAr": "نجاح زائف أو فشل بعد الرجوع رغم سلوك المنتج الصحيح.",
            "taskAr": "إعادة جلب المشغّل النشط بعد الرجوع، تحقق تقدم محدود المدة، RTL فعلي، وتمييز محاكاة دورة الحياة.",
            "relatedTaskIds": [
              "P1-RC2-01",
              "P1-RC2-04",
              "P1-T4"
            ],
            "status": "بانتظار المراجعة",
            "resultAr": "حُدّث integration_test/discover_playback_rc2_test.dart: مرجع جديد بعد pop، تحقق position متعدد العينات، Directionality RTL، سينario covered-resume.",
            "evidenceAr": "evidence/tests/rc3_playback_integration_note.txt — اختبار الوحدة/التكامل في CI؛ تشغيل الجهاز في rc3_device_run.txt.",
            "remainingAr": "إثبات RC3_MARK على جهاز فعلي ما زال معلقًا على VM Service."
          },
          {
            "id": "P1-RC3-02",
            "titleAr": "اختبار منطق AssetVideoPort الفعلي",
            "problemAr": "DelayedVideoPort داخل الاختبارات لا يثبت خوارزمية الإلغاء في AssetVideoPort.",
            "impactAr": "فجوة بين نجاح واجهة الاختبار وسلامة المشغّل الحقيقي.",
            "taskAr": "اختبارات على AssetVideoPort مع حقن مصنع VideoPlayerController قابل للتحكم.",
            "relatedTaskIds": [
              "P1-RC2-02",
              "P1-RC2-03",
              "P1-T4"
            ],
            "status": "بانتظار المراجعة",
            "resultAr": "10 حالات على AssetVideoPort؛ تُصليح بعد play عند hasError؛ play/pause/dispose تُراقَب على الطبقة السفلى.",
            "evidenceAr": "test/features/marketplace/asset_video_port_test.dart و evidence/tests/rc3_asset_video_port.txt",
            "remainingAr": "لا شيء ضمن اختبارات الوحدة."
          },
          {
            "id": "P1-RC3-03",
            "titleAr": "خروج من شاشة العروض الفارغة",
            "problemAr": "فرع _slides.isEmpty كان يعرض نصًا فقط بلا مخرج.",
            "impactAr": "حبس المستخدم عند فتح عرض فارغ.",
            "taskAr": "زر إغلاق في المنطقة الآمنة مع pop أو pushReplacementNamed إلى اكتشفي.",
            "relatedTaskIds": [
              "P1-T1"
            ],
            "status": "بانتظار المراجعة",
            "resultAr": "زر إغلاق في الحالة الفارغة؛ اختبار يضغط الإغلاق ويتحقق من العودة.",
            "evidenceAr": "discover_presentation_test.dart — empty presentation has an exit",
            "remainingAr": "لا شيء."
          },
          {
            "id": "P1-RC3-04",
            "titleAr": "التشغيل الفعلي والأدلة المرئية",
            "problemAr": "RC2: محاكي TensorFlowLiteC؛ الجهاز قطع الاتصال قبل إثبات التشغيل.",
            "impactAr": "لا صور/تسجيل من التطبيق لشاشة العرض.",
            "taskAr": "flutter test على iPhone بعلم MIRA_MARKETPLACE_ENABLED=true مع أدلة لقطات/تسجيل.",
            "relatedTaskIds": [
              "P1-RC2-04",
              "P1-T4"
            ],
            "status": "قيد التنفيذ",
            "resultAr": "أُعيد flutter test على iPhone؛ البناء نجح؛ VM Service لم يُكتشف خلال 60s (جاري/معلق).",
            "evidenceAr": "evidence/tests/rc3_device_run.txt",
            "remainingAr": "لقطات شاشة التطبيق وتسجيل فيدio قصير من الجهاز؛ إبقاء التطبيق في المقدمة."
          },
          {
            "id": "P1-RC3-05",
            "titleAr": "روابط تنزيل ZIP وتقرير التحقق",
            "problemAr": "zipHref كان يشير إلى سجل RC2.txt بدل ملف ZIP.",
            "impactAr": "خلط بين السجل والحزمة والتحقق.",
            "taskAr": "فصل سجل التسليم وتنزيل ZIP والبصمة وتقرير التحقق؛ ترتيب فك بجوار ZIP.",
            "relatedTaskIds": [
              "P1-RC2-05",
              "P1-T1"
            ],
            "status": "بانتظار المراجعة",
            "resultAr": "توسيع app.js وحقول logHref/sha256Href؛ DEL-RC2/DEL-RC3 بمسارات ../../ للفك بجوار ZIP؛ نسخ محلي في deliveries/ للمستودع.",
            "evidenceAr": "deliveries/RC3.txt و evidence/tests/rc3_link_check.txt",
            "remainingAr": "تحقق نهائي بعد إغلاق ZIP على سطح المكتب."
          }
        ],
        "deliveries": [
          {
            "id": "DEL-RC1",
            "name": "MIRA_DISCOVER_PHASE1_AND_PHASE_TRACKER_RC1_20260924_0507.zip",
            "createdAt": "2026-09-24T05:07:00+03:00",
            "deliveryStatus": "تمت مراجعته",
            "zipHref": "deliveries/RC1.txt",
            "zipLabel": "سجل حزمة RC1 والبصمة",
            "verificationHref": "deliveries/RC1-VERIFICATION.txt",
            "verificationLabel": "تقرير تحقق RC1",
            "sha256": "ad4399482c891b28850efa12dca36cebcc9944f0103c74a547d05994f06551b4",
            "reviewResultAr": "قبول تسجيل المراحل كأساس للمتابعة. المرحلة الأولى غير معتمدة."
          },
          {
            "id": "DEL-RC2",
            "name": "MIRA_DISCOVER_PHASE1_CORRECTIONS_RC2_20260924_0611.zip",
            "createdAt": "2026-09-24T06:11:28+03:00",
            "deliveryStatus": "تمت مراجعته",
            "zipHref": "../../MIRA_DISCOVER_PHASE1_CORRECTIONS_RC2_20260924_0611.zip",
            "zipLabel": "MIRA_DISCOVER_PHASE1_CORRECTIONS_RC2_20260924_0611.zip",
            "verificationHref": "../../MIRA_DISCOVER_PHASE1_CORRECTIONS_RC2_20260924_0611__VERIFICATION.txt",
            "verificationLabel": "تقرير تحقق RC2",
            "sha256": "86fbabfc3e74a7701bd2974d29f310aad156b97e2aa329e5169a0e2084f6f6b8",
            "reviewResultAr": "بصمة ZIP صحيحة؛ 146 ملفًا متطابقًا؛ فاحص الموقع 121 ملفًا؛ PH-1 قيد التنفيذ؛ 18 اختبارًا ناجحًا و5 بعلم التفعيل؛ لا إثبات مشغّل حقيقي؛ المرحلة الأولى غير معتمدة.",
            "logHref": "deliveries/RC2.txt",
            "logLabel": "سجل تسليم RC2",
            "sha256Href": "../../MIRA_DISCOVER_PHASE1_CORRECTIONS_RC2_20260924_0611.zip.sha256.txt",
            "sha256Label": "بصمة RC2",
            "approvalAr": "غير معتمدة"
          },
          {
            "id": "DEL-RC3",
            "name": "MIRA_DISCOVER_PHASE1_CLOSURE_RC3_.zip",
            "createdAt": "2026-09-25T04:30:00+03:00",
            "deliveryStatus": "مُسلَّم للمراجعة",
            "logHref": "deliveries/RC3.txt",
            "logLabel": "سجل تسليم RC3",
            "zipHref": "../../MIRA_DISCOVER_PHASE1_CLOSURE_RC3_.zip",
            "zipLabel": "MIRA_DISCOVER_PHASE1_CLOSURE_RC3_.zip",
            "sha256Href": "../../MIRA_DISCOVER_PHASE1_CLOSURE_RC3_.zip.sha256.txt",
            "sha256Label": "بصمة RC3 (خارج الحزمة)",
            "verificationHref": "../../MIRA_DISCOVER_PHASE1_CLOSURE_RC3__VERIFICATION.txt",
            "verificationLabel": "تقرير تحقق RC3",
            "sha256": "",
            "reviewResultAr": "لم تصدر بعد",
            "approvalAr": "غير معتمدة"
          }
        ]
      },
      {
        "id": "PH-2",
        "number": 2,
        "nameAr": "تجربة المنتجات والخدمات",
        "goalAr": "بحث وتصنيفات وفلاتر وصفحة متجر الجهة وتفاصيل وإجراءات صادقة.",
        "inScopeAr": [
          "البحث والتصنيفات والفلاتر من البيانات",
          "صفحة متجر الجهة",
          "إجراءات المنتج والخدمة ضمن القدرة الفعلية"
        ],
        "outOfScopeAr": [
          "دفع داخلي",
          "حجز مؤكد",
          "احتساب مشاهدات"
        ],
        "tasks": [
          {
            "id": "P2-T1",
            "nameAr": "البحث والتصنيفات والفلاتر",
            "status": "لم تبدأ"
          },
          {
            "id": "P2-T2",
            "nameAr": "صفحة متجر الجهة",
            "status": "لم تبدأ"
          },
          {
            "id": "P2-T3",
            "nameAr": "إجراءات صادقة للشراء والتواصل والموقع والموعد",
            "status": "لم تبدأ"
          }
        ],
        "expectedAr": "ترابط الخلاصة والمتجر والتفاصيل بنفس المعرّفات، وفلاتر مبنية على البيانات، وإجراءات تصف نتيجتها الفعلية.",
        "actualAr": "لم يبدأ التنفيذ في هذا التكليف.",
        "status": "لم تبدأ",
        "dependenciesAr": "المرحلة 1 ليست شرطًا برمجيًا، لكن هذا التكليف لا ينفذ المرحلة 2.",
        "notesAr": "الشراء الخارجي الحالي يبقى فتح رابط لا شراءً مكتملًا. الحجز الحالي يبقى «قريبًا».",
        "blockersAr": "",
        "acceptanceAr": "ترابط الخلاصة والمتجر والتفاصيل بنفس المعرّفات، وفلاتر مبنية على البيانات، وإجراءات صادقة في وصف نتائجها.",
        "evidenceIds": [],
        "reviewPackage": "",
        "verificationReport": "",
        "reviewResultAr": "",
        "reviewDate": ""
      },
      {
        "id": "PH-3",
        "number": 3,
        "nameAr": "إدارة المحتوى وربط المتاجر",
        "goalAr": "توسيع بوابة الشركاء الحالية لإدارة الوسائط وربطها بالمنتجات والخدمات مع المراجعة والنشر.",
        "inScopeAr": [
          "إدارة الوسائط في البوابة الحالية",
          "الربط بالمنتجات والخدمات",
          "المراجعة والنشر",
          "توثيق ملكية الحقول"
        ],
        "outOfScopeAr": [
          "استيراد بلا تكامل معتمد ووثائق رسمية",
          "كيان كتالوج موازٍ"
        ],
        "tasks": [
          {
            "id": "P3-T1",
            "nameAr": "إدارة الوسائط في بوابة الشركاء",
            "status": "لم تبدأ"
          },
          {
            "id": "P3-T2",
            "nameAr": "الربط والمراجعة والنشر",
            "status": "لم تبدأ"
          },
          {
            "id": "P3-T3",
            "nameAr": "الاستيراد والمزامنة ضمن تكامل معتمد",
            "status": "لم تبدأ"
          }
        ],
        "expectedAr": "رحلة إدارة محتوى مثبتة، واستيراد ومزامنة ضمن النطاق المعتمد دون تكرار الكيانات.",
        "actualAr": "لم يبدأ التنفيذ في هذا التكليف. لم يُغيَّر مخطط Prisma.",
        "status": "لم تبدأ",
        "dependenciesAr": "تكامل معتمد ووثائق رسمية قبل أي استيراد. البوابة الحالية هي نقطة التوسع.",
        "notesAr": "",
        "blockersAr": "",
        "acceptanceAr": "رحلة إدارة محتوى مثبتة، واستيراد ومزامنة ضمن النطاق المعتمد دون تكرار الكيانات أو تضارب مصادر البيانات.",
        "evidenceIds": [],
        "reviewPackage": "",
        "verificationReport": "",
        "reviewResultAr": "",
        "reviewDate": ""
      },
      {
        "id": "PH-4",
        "number": 4,
        "nameAr": "المشاهدات وإعلانات المشاهير",
        "goalAr": "احتساب مشاهدات حقيقية بعد اعتماد القواعد، وربط إعلان المشهور بالكيان الأصلي مع فصل الأدوار.",
        "inScopeAr": [
          "قواعد العدّ قبل التنفيذ",
          "أيقونة العين والعدد الحقيقي",
          "فصل البائع والمعلن وناشر المحتوى"
        ],
        "outOfScopeAr": [
          "عرض صفر أو رقم تجريبي قبل تنفيذ العدّ",
          "احتساب التحميل المسبق مشاهدة"
        ],
        "tasks": [
          {
            "id": "P4-T1",
            "nameAr": "اعتماد قواعد العدّ ومنع التكرار",
            "status": "لم تبدأ"
          },
          {
            "id": "P4-T2",
            "nameAr": "إظهار العدد الحقيقي وتمييز الصفر عن التعذر",
            "status": "لم تبدأ"
          },
          {
            "id": "P4-T3",
            "nameAr": "ربط إعلان المشهور وفصل الأحداث",
            "status": "لم تبدأ"
          }
        ],
        "expectedAr": "أحداث مرتبطة بالكيان الصحيح، وعدم احتساب التحميل المسبق، وعدم تضخيم العدّ، وتمييز الصفر عن تعذر الجلب.",
        "actualAr": "لم يبدأ التنفيذ. المرحلة 1 جهّزت موضع الأيقونة فقط والنص «العد غير مفعّل».",
        "status": "لم تبدأ",
        "dependenciesAr": "اعتماد قواعد العدّ قبل أي تنفيذ. موضع الأيقونة في المرحلة 1 لا ينفذ العدّ.",
        "notesAr": "",
        "blockersAr": "",
        "acceptanceAr": "أحداث مرتبطة بالكيان الصحيح، وعدم احتساب التحميل المسبق، وعدم تضخيم المشاهدات بالتكرار، وتمييز الصفر عن تعذر جلب العدد، واختبارات تثبت ذلك.",
        "evidenceIds": [],
        "reviewPackage": "",
        "verificationReport": "",
        "reviewResultAr": "",
        "reviewDate": ""
      },
      {
        "id": "PH-5",
        "number": 5,
        "nameAr": "الاختبار الشامل وتجهيز الإطلاق",
        "goalAr": "رحلات متكاملة وأداء وصلاحيات واستقلال ميرا وسلامة الوظائف الحالية، مع توثيق الموانع وخطة التراجع.",
        "inScopeAr": [
          "الرحلات المتكاملة",
          "الأداء والصلاحيات",
          "الاستقلال عن الأماكن",
          "توثيق الموانع والجاهزية والتراجع"
        ],
        "outOfScopeAr": [
          "النشر العام التلقائي لمجرد تجهيز الإطلاق"
        ],
        "tasks": [
          {
            "id": "P5-T1",
            "nameAr": "الرحلات المتكاملة",
            "status": "لم تبدأ"
          },
          {
            "id": "P5-T2",
            "nameAr": "الأداء والصلاحيات وسلامة وظائف ميرا",
            "status": "لم تبدأ"
          },
          {
            "id": "P5-T3",
            "nameAr": "الموانع والجاهزية وخطة التراجع",
            "status": "لم تبدأ"
          }
        ],
        "expectedAr": "أدلة اختبار شاملة، وحالة واضحة لكل مانع، وقرار جاهزية مبني على النتائج.",
        "actualAr": "لم يبدأ التنفيذ في هذا التكليف.",
        "status": "لم تبدأ",
        "dependenciesAr": "اكتمال المراحل السابقة التي تدخل في قرار الجاهزية. تجهيز الإطلاق لا يعني النشر.",
        "notesAr": "",
        "blockersAr": "",
        "acceptanceAr": "أدلة اختبار شاملة، وحالة واضحة لكل مانع، وقرار جاهزية مبني على النتائج. تجهيز الإطلاق لا يعني النشر العام تلقائيًا.",
        "evidenceIds": [],
        "reviewPackage": "",
        "verificationReport": "",
        "reviewResultAr": "",
        "reviewDate": ""
      }
    ]
  },
  "sections": [
    {
      "id": "s0",
      "num": "00",
      "title": "لوحة المشروع",
      "icon": "📊"
    },
    {
      "id": "s1",
      "num": "01",
      "title": "الرؤية والنطاق",
      "icon": "🎯"
    },
    {
      "id": "s2",
      "num": "02",
      "title": "خط الأساس والمستودعات",
      "icon": "📦"
    },
    {
      "id": "s3",
      "num": "03",
      "title": "الموجود حاليًا",
      "icon": "✅"
    },
    {
      "id": "s4",
      "num": "04",
      "title": "الخدمات المتوقفة",
      "icon": "⏸️"
    },
    {
      "id": "s5",
      "num": "05",
      "title": "رحلة العميل",
      "icon": "🧍"
    },
    {
      "id": "s6",
      "num": "06",
      "title": "رحلة المتجر والعيادة",
      "icon": "🏪"
    },
    {
      "id": "s7",
      "num": "07",
      "title": "المشاهير والإعلانات",
      "icon": "⭐"
    },
    {
      "id": "s8",
      "num": "08",
      "title": "التصنيفات والفلاتر",
      "icon": "🔎"
    },
    {
      "id": "s9",
      "num": "09",
      "title": "الفيديو والصور",
      "icon": "🎬"
    },
    {
      "id": "s10",
      "num": "10",
      "title": "الطلبات والحجوزات والتواصل",
      "icon": "🧾"
    },
    {
      "id": "s11",
      "num": "11",
      "title": "التحليلات",
      "icon": "📈"
    },
    {
      "id": "s12",
      "num": "12",
      "title": "الصلاحيات والخصوصية والتنظيم",
      "icon": "🔒"
    },
    {
      "id": "s13",
      "num": "13",
      "title": "البنية والتكاملات المقترحة",
      "icon": "🏗️"
    },
    {
      "id": "s14",
      "num": "14",
      "title": "مصفوفة المتطلبات والفجوات",
      "icon": "🗂️"
    },
    {
      "id": "s15",
      "num": "15",
      "title": "المراحل وشروط القبول",
      "icon": "🚦"
    },
    {
      "id": "s16",
      "num": "16",
      "title": "القرارات والأسئلة المفتوحة",
      "icon": "❓"
    },
    {
      "id": "s17",
      "num": "17",
      "title": "مكتبة الأدلة",
      "icon": "📚"
    },
    {
      "id": "s18",
      "num": "18",
      "title": "سجل التغييرات والإصدارات",
      "icon": "📝"
    },
    {
      "id": "s19",
      "num": "19",
      "title": "تحديث المرجع والتحقق",
      "icon": "🔄"
    },
    {
      "id": "s20",
      "num": "20",
      "title": "ملاحظات المراجعة ومعالجتها",
      "icon": "🧾"
    },
    {
      "id": "s21",
      "num": "21",
      "title": "تغطية التكليف والتحقق من اكتماله",
      "icon": "📌"
    },
    {
      "id": "s22",
      "num": "22",
      "title": "ملخص قرار الأماكن",
      "icon": "🧭"
    },
    {
      "id": "s23",
      "num": "23",
      "title": "ما وصل من الأماكن",
      "icon": "📥"
    },
    {
      "id": "s24",
      "num": "24",
      "title": "نتائج مراجعة الحزمة",
      "icon": "🧪"
    },
    {
      "id": "s25",
      "num": "25",
      "title": "معالجة ملاحظات الحزمة",
      "icon": "🛠️"
    },
    {
      "id": "s26",
      "num": "26",
      "title": "مصفوفة إعادة الاستخدام",
      "icon": "🧩"
    },
    {
      "id": "s27",
      "num": "27",
      "title": "تجربة المنتجات",
      "icon": "🛍️"
    },
    {
      "id": "s28",
      "num": "28",
      "title": "تجربة العيادات والمشاغل",
      "icon": "💇"
    },
    {
      "id": "s29",
      "num": "29",
      "title": "معيار الوسائط",
      "icon": "🖼️"
    },
    {
      "id": "s30",
      "num": "30",
      "title": "المشاهدات والإحصاءات",
      "icon": "👁️"
    },
    {
      "id": "s31",
      "num": "31",
      "title": "ربط المتاجر والمشاهير",
      "icon": "🔗"
    },
    {
      "id": "s32",
      "num": "32",
      "title": "خطة تنفيذ الأماكن",
      "icon": "🗺️"
    },
    {
      "id": "s33",
      "num": "33",
      "title": "قرارات أماكن مفتوحة",
      "icon": "❓"
    },
    {
      "id": "s34",
      "num": "34",
      "title": "أدلة حزمة الأماكن",
      "icon": "📦"
    },
    {
      "id": "s35",
      "num": "35",
      "title": "سجل خطة الأماكن",
      "icon": "🗒️"
    },
    {
      "id": "s36",
      "num": "36",
      "title": "التصورات المرجعية",
      "icon": "🎨"
    },
    {
      "id": "s37",
      "num": "37",
      "title": "تصحيح توثيق حزمة المصدر",
      "icon": "📎"
    },
    {
      "id": "s38",
      "num": "38",
      "title": "تفعيل اختبار اكتشفي وخطة الدمج",
      "icon": "🧪"
    },
    {
      "id": "s39",
      "num": "39",
      "title": "مراحل تطوير اكتشفي",
      "icon": "🧭"
    }
  ]
};
