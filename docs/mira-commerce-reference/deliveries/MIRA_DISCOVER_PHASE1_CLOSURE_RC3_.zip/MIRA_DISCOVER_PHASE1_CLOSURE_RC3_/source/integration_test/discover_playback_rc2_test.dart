import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:mirra/core/navigation/mira_route_observer.dart';
import 'package:mirra/features/marketplace/presentation/marketplace_routes.dart';
import 'package:mirra/features/marketplace/presentation/screens/discover_presentation_screen.dart';
import 'package:video_player/video_player.dart';

/// Real [video_player] on a device. Uses Arabic locale and explicit RTL like production.
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('presentation plays the sample clip and stops when covered', (tester) async {
    await tester.pumpWidget(_presentationApp());
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));

    expect(find.textContaining('عينة وسائط معزولة'), findsWidgets);
    expect(find.textContaining('التفاف النص العربي'), findsOneWidget);
    final direction = tester.widget<Directionality>(find.byType(Directionality).first);
    expect(direction.textDirection, TextDirection.rtl);
    // ignore: avoid_print
    print('RC3_MARK rtl=${direction.textDirection} locale=ar');

    await _flingHorizontal(tester);
    await tester.pump(const Duration(milliseconds: 600));
    // ignore: avoid_print
    print('RC3_MARK square');
    await tester.pump(const Duration(seconds: 1));

    await _flingHorizontal(tester);
    await tester.pump(const Duration(milliseconds: 600));
    // ignore: avoid_print
    print('RC3_MARK landscape');

    await _flingHorizontal(tester);
    await tester.pump(const Duration(milliseconds: 400));
    final videoPlayer = await _waitForActivePlayer(tester);
    final controller = videoPlayer.controller;
    await _expectPlaybackProgress(tester, controller);
    // ignore: avoid_print
    print(
      'RC3_MARK video initialized=${controller.value.isInitialized} '
      'playing=${controller.value.isPlaying} '
      'size=${controller.value.size} '
      'position=${controller.value.position} error=${controller.value.errorDescription}',
    );

    await tester.tap(find.text('التفاصيل'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 800));
    // ignore: avoid_print
    print('RC3_MARK details oldPlaying=${controller.value.isPlaying}');
    expect(controller.value.isPlaying, isFalse);
    expect(find.textContaining('ليس شراءً مؤكدًا'), findsOneWidget);

    tester.state<NavigatorState>(find.byType(Navigator)).pop();
    await tester.pump();
    final resumedPlayer = await _waitForActivePlayer(tester);
    final resumedController = resumedPlayer.controller;
    expect(identical(controller, resumedController), isFalse);
    expect(resumedController.value.isPlaying, isTrue);
    // ignore: avoid_print
    print('RC3_MARK returned newController playing=${resumedController.value.isPlaying}');

    await tester.fling(find.byType(PageView).first, const Offset(0, -420), 1200);
    await tester.pump(const Duration(milliseconds: 700));
    await tester.fling(find.byType(PageView).first, const Offset(0, -420), 1200);
    await tester.pump(const Duration(milliseconds: 700));
    // ignore: avoid_print
    print('RC3_MARK vertical');
    expect(find.text('استشارة جلدية'), findsOneWidget);
    final servicePlayer = await _waitForActivePlayer(tester);
    final serviceController = servicePlayer.controller;
    expect(serviceController.value.isPlaying, isTrue);

    await tester.tap(find.text('التفاصيل'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 800));
    expect(serviceController.value.isPlaying, isFalse);
    expect(find.text('الحجز قريباً'), findsOneWidget);

    // Simulated lifecycle (not OS backgrounding on device).
    // ignore: avoid_print
    print('RC3_LIFECYCLE simulated paused/resumed');
    await servicePlayer.controller.play();
    await tester.pump(const Duration(milliseconds: 200));
    expect(serviceController.value.isPlaying, isTrue);
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
    await tester.pump(const Duration(milliseconds: 300));
    expect(serviceController.value.isPlaying, isFalse);
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
    await tester.pump(const Duration(seconds: 1));
    final afterResume = await _waitForActivePlayer(tester);
    expect(afterResume.controller.value.isPlaying, isFalse);

    tester.state<NavigatorState>(find.byType(Navigator)).pop();
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    final afterPop = await _waitForActivePlayer(tester);
    expect(afterPop.controller.value.isPlaying, isTrue);

    await tester.tap(find.text('التفاصيل'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
    await tester.pump(const Duration(milliseconds: 200));
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('الحجز قريباً'), findsOneWidget);
    final covered = find.byType(VideoPlayer);
    if (covered.evaluate().isNotEmpty) {
      for (final player in tester.widgetList<VideoPlayer>(covered)) {
        expect(player.controller.value.isPlaying, isFalse);
      }
    }
    // ignore: avoid_print
    print('RC3_MARK covered-resume-no-play');
  });
}

Widget _presentationApp() {
  return MaterialApp(
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    builder: (context, child) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      );
    },
    navigatorObservers: [miraRouteObserver],
    onGenerateRoute: MarketplaceRoutes.onGenerate,
    home: const DiscoverPresentationScreen(),
  );
}

Future<void> _flingHorizontal(WidgetTester tester) async {
  final views = find.byType(PageView);
  await tester.fling(views.last, const Offset(-280, 0), 1200);
  await tester.pump(const Duration(milliseconds: 500));
}

Future<VideoPlayer> _waitForActivePlayer(WidgetTester tester) async {
  for (var i = 0; i < 30; i++) {
    await tester.pump(const Duration(milliseconds: 500));
    final players = tester.widgetList<VideoPlayer>(find.byType(VideoPlayer)).toList();
    for (final player in players) {
      if (player.controller.value.isInitialized && player.controller.value.isPlaying) {
        return player;
      }
    }
    for (final player in players) {
      if (player.controller.value.isInitialized) {
        return player;
      }
    }
    if (find.text('تعذر تشغيل الفيديو').evaluate().isNotEmpty) {
      fail('video player reported failure before it became ready');
    }
  }
  fail('video player did not become ready');
}

Future<void> _expectPlaybackProgress(WidgetTester tester, VideoPlayerController controller) async {
  expect(controller.value.isInitialized, isTrue);
  expect(controller.value.hasError, isFalse);
  final samples = <Duration>[controller.value.position];
  for (var i = 0; i < 12; i++) {
    await tester.pump(const Duration(milliseconds: 250));
    samples.add(controller.value.position);
  }
  final distinct = samples.toSet();
  final progressed = distinct.length >= 2 || controller.value.isPlaying;
  expect(progressed, isTrue, reason: 'expected playback progress or loop within bounded window');
}
