#!/usr/bin/env python3
"""Compare fact evidence with a MIRA checkout. Absence of the repo is not a package failure."""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True

import argparse
import hashlib
import json
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description="Freshness check for fact evidence. Requires --repo.")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--repo", default="")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    evidence = json.loads((root / "data" / "evidence-index.json").read_text(encoding="utf-8"))
    facts = [row for row in evidence if row.get("claimType") == "fact"]
    print(f"fact_checks={len(facts)}")
    for row in facts:
        print(f"FACT {row.get('id')} {row.get('path')}")
    repo = Path(args.repo).expanduser() if args.repo else None
    if repo is None or not str(args.repo).strip() or not repo.is_dir():
        print("STATUS BLOCKED")
        print("REASON repository path was not provided or does not exist")
        print("package check is independent and is not failed by this status")
        return 2
    mismatches = 0
    for row in facts:
        path = repo / (row.get("path") or "")
        expected = row.get("fileSha256") or ""
        if not path.is_file():
            print(f"MISSING {row.get('id')} {row.get('path')}")
            mismatches += 1
            continue
        actual = sha256_file(path)
        if expected and actual != expected:
            print(f"MISMATCH {row.get('id')} {row.get('path')}")
            mismatches += 1
        elif not expected:
            print(f"UNHASHED {row.get('id')} {row.get('path')}")
            mismatches += 1
        else:
            print(f"MATCH {row.get('id')} {row.get('path')}")
    if mismatches:
        print(f"STATUS FAIL mismatches={mismatches}")
        return 1
    print("STATUS PASS freshness")
    return 0


if __name__ == "__main__":
    sys.exit(main())
