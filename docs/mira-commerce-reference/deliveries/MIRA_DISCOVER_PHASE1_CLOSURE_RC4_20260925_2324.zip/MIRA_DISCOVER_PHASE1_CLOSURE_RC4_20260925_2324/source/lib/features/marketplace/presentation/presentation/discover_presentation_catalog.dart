import '../../data/marketplace_local_catalog.dart';
import '../../domain/entities/catalog_product.dart';
import '../../domain/entities/catalog_service.dart';
import 'presentation_models.dart';

/// Phase-1 slides use existing local catalog ids and isolated sample media.
abstract final class DiscoverPresentationCatalog {
  static PresentationSlide? slideForProduct(String id) {
    for (final slide in slides()) {
      if (slide.product?.id == id) return slide;
    }
    return null;
  }

  static List<PresentationSlide> slides() {
    CatalogProduct? productById(String id) {
      for (final product in MarketplaceLocalCatalog.products) {
        if (product.id == id) return product;
      }
      return null;
    }

    CatalogService? serviceById(String id) {
      for (final service in MarketplaceLocalCatalog.services) {
        if (service.id == id) return service;
      }
      return null;
    }

    final vitamin = productById('p-loreal-vitc');
    final wash = productById('p-neutro-wash');
    final consult = serviceById('s-noor-consult');
    return [
      if (vitamin != null)
        PresentationSlide(
          entityId: vitamin.id,
          partnerId: vitamin.partnerId,
          title: vitamin.nameAr,
          partnerName: vitamin.partnerNameAr,
          kindLabel: 'منتج',
          priceLabel: vitamin.priceLabel,
          product: vitamin,
          layoutNote: PresentationSamples.layoutNote,
          media: const [
            PresentationMedia(kind: PresentationMediaKind.image, assetPath: PresentationSamples.portrait),
            PresentationMedia(kind: PresentationMediaKind.image, assetPath: PresentationSamples.square),
            PresentationMedia(kind: PresentationMediaKind.image, assetPath: PresentationSamples.landscape),
            PresentationMedia(kind: PresentationMediaKind.video, assetPath: PresentationSamples.clip),
          ],
        ),
      if (wash != null)
        PresentationSlide(
          entityId: wash.id,
          partnerId: wash.partnerId,
          title: wash.nameAr,
          partnerName: wash.partnerNameAr,
          kindLabel: 'منتج',
          priceLabel: wash.priceLabel,
          product: wash,
          media: const [
            PresentationMedia(kind: PresentationMediaKind.image, assetPath: PresentationSamples.square),
          ],
        ),
      if (consult != null)
        PresentationSlide(
          entityId: consult.id,
          partnerId: consult.partnerId,
          title: consult.nameAr,
          partnerName: consult.partnerNameAr,
          kindLabel: 'خدمة',
          priceLabel: consult.priceLabel,
          service: consult,
          media: const [
            PresentationMedia(kind: PresentationMediaKind.video, assetPath: PresentationSamples.clip),
          ],
        ),
    ];
  }
}
