import 'package:flutter/material.dart';

import '../../../../core/constants/marketplace_copy.dart';
import '../../../../core/navigation/app_routes.dart';
import '../../../../core/navigation/mira_route_observer.dart';
import '../../../../shared/theme/colors.dart';
import '../../../../shared/theme/typography.dart';
import '../presentation/discover_presentation_catalog.dart';
import '../presentation/presentation_models.dart';
import '../presentation/presentation_video_port.dart';

/// Full-screen Discover presentation. One product or service per page.
class DiscoverPresentationScreen extends StatefulWidget {
  const DiscoverPresentationScreen({
    super.key,
    this.slides,
    this.videoPort,
    this.verticalController,
  });

  final List<PresentationSlide>? slides;
  final PresentationVideoPort? videoPort;
  final PageController? verticalController;

  @override
  State<DiscoverPresentationScreen> createState() => _DiscoverPresentationScreenState();
}

class _DiscoverPresentationScreenState extends State<DiscoverPresentationScreen>
    with WidgetsBindingObserver, RouteAware {
  late final List<PresentationSlide> _slides;
  late final PresentationVideoPort _video;
  late final bool _ownsVideo;
  late final PageController _vertical;
  ModalRoute<dynamic>? _route;
  int _page = 0;
  int _epoch = 0;
  bool _foreground = true;
  bool _covered = false;
  bool _released = false;

  bool get _playable => _foreground && !_covered && !_released;

  @override
  void initState() {
    super.initState();
    _slides = widget.slides ?? DiscoverPresentationCatalog.slides();
    _ownsVideo = widget.videoPort == null;
    _video = widget.videoPort ?? AssetVideoPort();
    _vertical = widget.verticalController ?? PageController();
    WidgetsBinding.instance.addObserver(this);
    _video.addListener(_onVideo);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route == _route || route is! PageRoute<dynamic>) return;
    if (_route != null) miraRouteObserver.unsubscribe(this);
    _route = route;
    miraRouteObserver.subscribe(this, route);
  }

  @override
  void dispose() {
    _released = true;
    WidgetsBinding.instance.removeObserver(this);
    miraRouteObserver.unsubscribe(this);
    _video.removeListener(_onVideo);
    if (widget.verticalController == null) _vertical.dispose();
    _video.release();
    if (_ownsVideo) _video.dispose();
    super.dispose();
  }

  void _onVideo() {
    if (!mounted || _released) return;
    setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final foreground = state == AppLifecycleState.resumed;
    if (foreground == _foreground) return;
    _foreground = foreground;
    if (!foreground) {
      _video.pause();
    }
    _bump();
  }

  @override
  void didPushNext() {
    _covered = true;
    _video.pause();
    _bump();
  }

  @override
  void didPopNext() {
    if (_released) return;
    _covered = false;
    _bump();
  }

  void _bump() {
    if (!mounted || _released) return;
    setState(() => _epoch += 1);
  }

  void _onPage(int index) {
    setState(() => _page = index);
  }

  void _exitPresentation(BuildContext context) {
    final navigator = Navigator.of(context);
    if (navigator.canPop()) {
      navigator.pop();
    } else {
      navigator.pushReplacementNamed(AppRoutes.discover);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1214),
      body: _slides.isEmpty
          ? SafeArea(
              child: Stack(
                children: [
                  const Center(
                    child: Text('لا توجد عروض', style: TextStyle(color: Colors.white)),
                  ),
                  Positioned(
                    top: 8,
                    right: 12,
                    left: 12,
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () => _exitPresentation(context),
                          icon: const Icon(Icons.close, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          : PageView.builder(
              controller: _vertical,
              scrollDirection: Axis.vertical,
              itemCount: _slides.length,
              onPageChanged: _onPage,
              itemBuilder: (context, index) {
                return _PresentationPage(
                  slide: _slides[index],
                  active: index == _page,
                  playable: _playable && index == _page,
                  epoch: _epoch,
                  video: _video,
                );
              },
            ),
    );
  }
}

class _PresentationPage extends StatefulWidget {
  const _PresentationPage({
    required this.slide,
    required this.active,
    required this.playable,
    required this.epoch,
    required this.video,
  });

  final PresentationSlide slide;
  final bool active;
  final bool playable;
  final int epoch;
  final PresentationVideoPort video;

  @override
  State<_PresentationPage> createState() => _PresentationPageState();
}

class _PresentationPageState extends State<_PresentationPage> {
  late final PageController _horizontal;
  int _media = 0;
  PresentationSlot? _held;

  @override
  void initState() {
    super.initState();
    _horizontal = PageController();
    _syncVideo();
  }

  @override
  void didUpdateWidget(covariant _PresentationPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.playable != widget.playable || oldWidget.epoch != widget.epoch || oldWidget.active != widget.active) {
      _syncVideo();
    }
  }

  @override
  void dispose() {
    final held = _held;
    _held = null;
    if (held != null) widget.video.detach(held);
    _horizontal.dispose();
    super.dispose();
  }

  void _syncVideo() {
    if (widget.slide.media.isEmpty) {
      _releaseHeld();
      return;
    }
    final media = widget.slide.media[_media];
    final slot = PresentationSlot(widget.slide.entityId, _media);
    if (!widget.playable || media.kind != PresentationMediaKind.video) {
      _releaseHeld();
      return;
    }
    if (_held != null && !_held!.same(slot)) {
      widget.video.detach(_held!);
    }
    _held = slot;
    widget.video.attach(slot, media.assetPath);
  }

  void _releaseHeld() {
    final held = _held;
    _held = null;
    if (held != null) widget.video.detach(held);
  }

  @override
  Widget build(BuildContext context) {
    final padding = MediaQuery.paddingOf(context);
    final slide = widget.slide;
    return Stack(
      fit: StackFit.expand,
      children: [
        if (slide.media.isEmpty)
          const Center(child: Text('لا وسائط لهذا العرض', style: TextStyle(color: Colors.white)))
        else
          PageView.builder(
            controller: _horizontal,
            itemCount: slide.media.length,
            onPageChanged: (index) {
              setState(() => _media = index);
              _syncVideo();
            },
            itemBuilder: (context, index) {
              return _MediaFrame(
                media: slide.media[index],
                slot: PresentationSlot(slide.entityId, index),
                video: widget.video,
              );
            },
          ),
        Positioned(
          top: padding.top + 8,
          right: 12,
          left: 12,
          child: Row(
            children: [
              IconButton(
                onPressed: () => Navigator.maybePop(context),
                icon: const Icon(Icons.close, color: Colors.white),
              ),
              const Spacer(),
              const Icon(Icons.visibility_outlined, color: Colors.white),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  MarketplaceCopy.viewsUnavailable,
                  style: AppTypography.bodySmall.copyWith(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: DecoratedBox(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x00000000), Color(0xCC1A1214)],
              ),
            ),
            child: Padding(
              padding: EdgeInsets.fromLTRB(16, 28, 16, padding.bottom + 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(slide.kindLabel, style: AppTypography.bodySmall.copyWith(color: AppColors.primaryLight)),
                  Text(slide.title, style: AppTypography.titleLarge.copyWith(color: Colors.white)),
                  Text(slide.partnerName, style: AppTypography.bodyMedium.copyWith(color: Colors.white)),
                  if (slide.priceLabel != null && slide.priceLabel!.isNotEmpty)
                    Text(slide.priceLabel!, style: AppTypography.bodyMedium.copyWith(color: Colors.white)),
                  if (slide.layoutNote != null)
                    Text(slide.layoutNote!, style: AppTypography.bodySmall.copyWith(color: Colors.white)),
                  if (slide.sampleMedia)
                    Text(
                      MarketplaceCopy.isolatedSampleCaption,
                      style: AppTypography.bodySmall.copyWith(color: Colors.white70),
                    ),
                  const SizedBox(height: 8),
                  FilledButton(
                    onPressed: () => _openDetails(context),
                    child: const Text('التفاصيل'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _openDetails(BuildContext context) {
    final product = widget.slide.product;
    final service = widget.slide.service;
    if (product != null) {
      Navigator.pushNamed(context, AppRoutes.productDetail, arguments: product);
    } else if (service != null) {
      Navigator.pushNamed(context, AppRoutes.serviceDetail, arguments: service);
    }
  }
}

class _MediaFrame extends StatefulWidget {
  const _MediaFrame({
    required this.media,
    required this.slot,
    required this.video,
  });

  final PresentationMedia media;
  final PresentationSlot slot;
  final PresentationVideoPort video;

  @override
  State<_MediaFrame> createState() => _MediaFrameState();
}

class _MediaFrameState extends State<_MediaFrame> {
  @override
  void initState() {
    super.initState();
    widget.video.addListener(_rebuild);
  }

  @override
  void didUpdateWidget(covariant _MediaFrame oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.video != widget.video) {
      oldWidget.video.removeListener(_rebuild);
      widget.video.addListener(_rebuild);
    }
  }

  @override
  void dispose() {
    widget.video.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() {
    if (!mounted) return;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final video = widget.video;
    final media = widget.media;
    final slot = widget.slot;
    if (media.kind == PresentationMediaKind.video) {
      final owns = video.activeSlot != null && video.activeSlot!.same(slot);
      if (owns && video.playback == PresentationPlayback.failed) {
        return _Failure(
          message: video.errorText ?? 'تعذر تشغيل الفيديو',
          onRetry: () => video.retry(slot, media.assetPath),
        );
      }
      final view = owns ? video.buildView() : null;
      return ColoredBox(
        color: const Color(0xFF1A1214),
        child: Center(
          child: view ??
              Text(
                owns && video.playback == PresentationPlayback.loading ? 'جاري تجهيز الفيديو' : '',
                style: const TextStyle(color: Colors.white),
              ),
        ),
      );
    }
    return _StillImage(media: media);
  }
}

class _StillImage extends StatefulWidget {
  const _StillImage({required this.media});

  final PresentationMedia media;

  @override
  State<_StillImage> createState() => _StillImageState();
}

class _StillImageState extends State<_StillImage> {
  Object? _error;
  var _attempt = 0;

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return _Failure(
        message: 'تعذر تحميل الصورة',
        onRetry: () => setState(() {
          _error = null;
          _attempt += 1;
        }),
      );
    }
    return ColoredBox(
      color: const Color(0xFF1A1214),
      child: Center(
        child: Image.asset(
          widget.media.assetPath,
          key: ValueKey('${widget.media.assetPath}-$_attempt'),
          fit: BoxFit.contain,
          errorBuilder: (_, error, __) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted && _error == null) setState(() => _error = error);
            });
            return const SizedBox.shrink();
          },
        ),
      ),
    );
  }
}

class _Failure extends StatelessWidget {
  const _Failure({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xFF1A1214),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(message, style: const TextStyle(color: Colors.white)),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
          ],
        ),
      ),
    );
  }
}
