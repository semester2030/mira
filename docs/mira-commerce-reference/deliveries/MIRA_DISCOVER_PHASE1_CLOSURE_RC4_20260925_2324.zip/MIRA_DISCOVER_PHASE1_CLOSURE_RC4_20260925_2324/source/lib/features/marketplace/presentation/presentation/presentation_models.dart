import '../../domain/entities/catalog_product.dart';
import '../../domain/entities/catalog_service.dart';

enum PresentationMediaKind { image, video }

class PresentationMedia {
  const PresentationMedia({
    required this.kind,
    required this.assetPath,
  });

  final PresentationMediaKind kind;
  final String assetPath;
}

/// Links an existing product or service to isolated media. It does not store
/// a second price or stock catalog.
class PresentationSlide {
  const PresentationSlide({
    required this.entityId,
    required this.partnerId,
    required this.title,
    required this.partnerName,
    required this.kindLabel,
    required this.media,
    this.priceLabel,
    this.product,
    this.service,
    this.sampleMedia = true,
    this.layoutNote,
  });

  final String entityId;
  final String partnerId;
  final String title;
  final String partnerName;
  final String kindLabel;
  final String? priceLabel;
  final CatalogProduct? product;
  final CatalogService? service;
  final List<PresentationMedia> media;
  final bool sampleMedia;
  final String? layoutNote;
}

abstract final class PresentationSamples {
  static const portrait = 'assets/marketplace/samples/sample_portrait.png';
  static const square = 'assets/marketplace/samples/sample_square.png';
  static const landscape = 'assets/marketplace/samples/sample_landscape.png';
  static const clip = 'assets/marketplace/samples/sample_clip.mp4';
  static const sourceNote =
      'عينات اختبار مرسومة محليًا: صورة طولية ومربعة وأفقية، وفيديو testsrc متحرك. ليست صور المنتجات.';
  static const layoutNote =
      'عنوان طويل للتحقق من التفاف النص العربي من اليمين إلى اليسار فوق خلفية فاتحة وداكنة دون قصّ الوسائط.';
}
